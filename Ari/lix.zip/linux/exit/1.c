#include<stdio.h>
main()
{ 
  printf("hello...");
  exit(0);
}
