#include<stdio.h>
main()
{
 int x=0;
 (100<x)?:(printf("%d ",x)):exit(0);
 i++;
 main();
}
