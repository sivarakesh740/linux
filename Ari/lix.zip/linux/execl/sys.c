#include<stdio.h>
main()
{
 printf("hi...\n");
 system("ls");
 printf("hello...\n");
}
