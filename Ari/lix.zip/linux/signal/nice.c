#include<stdio.h>
main()
{
  printf("hello world...\n");
  printf("getpid=%d getppid=%d\n",getpid(),getppid()) ;
 return;
}
