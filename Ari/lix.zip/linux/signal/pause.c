#include<stdio.h>
main()
{
 printf("hello..\n");
 pause(2);
 printf("by..\n");
 printf("hello...\n");
}
