#include<stdio.h>
main()
{
   int *p=0;
   printf("%d\n",*p);
}
