#include<stdio.h>
main()
{
 printf("%d\n",10/0);
 return;
}
