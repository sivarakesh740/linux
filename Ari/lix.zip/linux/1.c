#include<stdio.h>
main()
{
 printf("hello..\n");
// raise(1);
 printf("hi..\n");
//  raise(1);
  while(1);
  //raise(1);
}
