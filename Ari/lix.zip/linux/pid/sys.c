#include<stdio.h>
main()
{ 
  printf("hello..\n");
  system("ls");
  system("pwd");
  printf("hi.\n");
  system("./exe");
}

