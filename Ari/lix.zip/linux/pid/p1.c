#include<stdio.h>
main()
{
  printf("in p1 process\n");
  while(1);
}
