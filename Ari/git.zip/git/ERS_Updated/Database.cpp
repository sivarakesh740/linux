#include <iostream>
#include <stdexcept>
#include "Database.h"
#include "Employee.h"

using namespace std;
namespace Records {
	Database::Database() 
	{
	 mNextEmployeeNumber=kFirstEmployeeNumber;

	}

	Employee& Database::addEmployee( string& firstName,  string& lastName)
		 {

		Employee theEmployee;
		theEmployee.setFirstName(firstName);
		theEmployee.setLastName(lastName);
		theEmployee.setEmployeeNumber(mNextEmployeeNumber++);
		theEmployee.hire();
		return theEmployee;
	}

	Employee& Database::getEmployee(int employeeNumber)
        {
		for (auto& employee : mEmployee) {
			if(employee.getEmployeeNumber() == employeeNumber) {
				return employee;
			}
		}

		throw runtime_error("No employee found");
        }

        void Database::displayAll()  {
                for( auto& employee : mEmployee) {
                        employee.display();
                }
        }

        void Database::displayCurrent() {
                for( auto& employee : mEmployee) {
                        if(employee.getIsHired()) {
                                employee.display();
                        }
                }
        }
	}

	Employee& Database::getEmployee( string& firstName, string& lastName)
	{
		int i;
		for (int i=0;i<2;i++){
			if((mEmployee[i].getFirstName()==firstName) && (mEmployee[i].getLastName()==lastName))
			{
				return mEmployee[i];
			}
		}

     
        throw runtime_error("No employee found");
	}

	void Database::displayAll()  {
		for( auto& employee : mEmployee) {
			employee.display();
		}
	}

	void Database::displayCurrent() {
		for( auto& employee : mEmployee) {
			if(employee.getIsHired()) {
				employee.display();
			}
		}
	}

	void Database::displayFormer()  {
		for( auto& employee : mEmployee) {
			if(!employee.getIsHired()) {
				employee.display();
			}
		}
	}
}
