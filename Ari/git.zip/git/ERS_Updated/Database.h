#pragma once
#include <iostream>
#include <vector>
#include "Employee.h"
namespace Records {
	const int kFirstEmployeeNumber = 1000;

	class Database {
		public:
			Database();

			Employee& addEmployee( std::string& firstName,  std::string& lastName);
			Employee& getEmployee(int employeeNumber);
			Employee& getEmployee( std::string& firstName,  std::string& lastName);

			void displayAll() ;
			void displayCurrent() ;
			void displayFormer() ;

		private:
			Employee mEmployee[kFirstEmployeeNumber ];
			int mNextEmployeeNumber;
	};
}
