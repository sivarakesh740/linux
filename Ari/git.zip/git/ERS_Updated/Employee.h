#pragma once
#include <string>

namespace Records {
	const int kDefaultStartingSalary = 30000;

	class Employee {
		public:
			Employee();
			void promote(int raiseAmount = 1000);
			void demote(int demeritAmount = 1000);
			void hire();
			void fire();
			void display() ;

			//Getters and Setters
			void setFirstName( std::string& firstName);
			 std::string& getFirstName() ;

			void setLastName( std::string& lastName);
			 std::string& getLastName() ;

			void setEmployeeNumber(int employeeNumber);
			int getEmployeeNumber();

			void setSalary(int newSalary);
			int getSalary() ;

			bool getIsHired() ;

		private:
			std::string mFirstName;
			std::string mLastName;
			int mEmployeeNumber;
			int mSalary;
			bool mHired;
	};
}
