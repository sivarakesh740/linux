#include <iostream>
#include "Employee.h"

using namespace std;
namespace Records {
	Employee::Employee()
	{
		 mFirstName("");
		 mLastName("");
		 mEmployeeNumber(-1);
		 mSalary(kDefaultStartingSalary);
		 mHired(false);
	}

	void Employee::promote(int raiseAmount) {
		setSalary(getSalary() + raiseAmount);
	}
	
	void Employee::demote(int demeritAmount) {
		setSalary(getSalary() - demeritAmount);
	}

	void Employee::hire() {
		mHired = true;
	}

	void Employee::fire() {
		mHired = false;
	}

	void Employee::display()  {
		cout << "Employee: " << getLastName() << ", " << getFirstName() << endl;
		cout << "--------------------------" << endl;
		cout << (mHired ? "Current Employee" : "Former Employee") << endl;
		cout << "Employee Number: " << getEmployeeNumber() << endl;
		cout << "Salary: $" << getSalary() << endl;
		cout << endl;
	}

	//Getters and Setters
	void Employee::setFirstName( string& firstName) {
		mFirstName = firstName;
	}

	 string Employee::getFirstName()  {
		return mFirstName;
	}

	void Employee::setLastName( string lastName) {
		mLastName = lastName;
	}

	 string Employee::getLastName()  {
		return mLastName;
	}

	void Employee::setEmployeeNumber(int employeeNumber) {
		mEmployeeNumber = employeeNumber;
	}

	int Employee::getEmployeeNumber() {
		return mEmployeeNumber;
	}

	void Employee::setSalary(int newSalary) {
		mSalary = newSalary;
	}

	int Employee::getSalary()  {
		return mSalary;
	}

	bool Employee::getIsHired()  {
		return mHired;
	}
}
