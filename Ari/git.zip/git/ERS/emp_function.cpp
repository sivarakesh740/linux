#include<iostream>
#include"emp_header.h"
#include<cstdio>
using namespace std;
FILE *fp=fopen("emp.txt","w+");// to store the employee data
FILE *f=fopen("updated.txt","w+");// to store the employee data
FILE *s=fopen("previous.txt","w+");// to store the  deleted employee data
int count=1,count1=1,status=0,status1=0;



void Employee::addEmp()  //addind the the employee details to the database
{
	static int i;
	cout<<"/*********************enter the employee "<<++i<<"--***********"<<endl;
	cout<<"enter employee name"<<endl;
	cin>>empName;
	fprintf(fp,"%s ",empName);  //storing the name of the employye into the file
	cout<<"enter employee salary"<<endl;
	cin>>salary;
	fprintf(fp,"%d ",salary);  //storing the salary of the employee
	cout<<"enter employee id"<<endl;
	cin>>empId;
	fprintf(fp,"%d ",empId); //storing the the ID of the employee
	fputc('\n',fp);
}



void Employee::currentEmp()  //to dispaly all the employee details with name ,salary and ID working currently
{
	if(count==1)
	{
		cout<<"name"<<" "<<"salary"<<" "<<"EmpId"<<endl;
		count++;
	}
	rewind(fp);

	while(fscanf(fp,"%s %d %d",empName,&salary,&empId)==3)  //fetching each line and printing it
	{
		cout<<empName<<" "<<salary<<" "<<empId<<endl;
	}
}


void Employee::fireID() //this is the fnction to delete the particular employee for the database
{
	int id;
	cout<<"enter the id to be deleted"<<endl;
	cin>>id;
	rewind(fp);

	while(fscanf(fp,"%s %d %d",empName,&salary,&empId)==3)  //fetching each line to check the ID
	{
		if(id==empId) //IF id found then storing the data of that particular employee in previous file database
		{	++status;
			cout<<"id delted"<<endl;
			fprintf(s,"%s ",empName);
			fprintf(s,"%d ",salary);
			fprintf(s,"%d ",empId);
			fputc('\n',s);
		}
		else
		{
			fprintf(f,"%s ",empName);
			fprintf(f,"%d ",salary);
			fprintf(f,"%d ",empId);
			fputc('\n',f);
		}
	}

	if(status==0)//if ID is not found it will print invalid ID
		cout<<"given id is not availble to delete"<<endl;

	rewind(f);
	fclose(fp);
	fp=fopen("emp.txt","w+");
	while(fscanf(f,"%s %d %d",empName,&salary,&empId)==3)
	{
		fprintf(fp,"%s ",empName);
		fprintf(fp,"%d ",salary);
		fprintf(fp,"%d ",empId);
		fputc('\n',fp);
	}	
}


void Employee::formerEmp() // this function stores all the deleted employees for the database
{
	if(count1==1)
	{
		cout<<"name"<<" "<<"salary"<<" "<<"EmpId"<<endl;
		count++;
	}
	rewind(s);

	while(fscanf(s,"%s %d %d",empName,&salary,&empId)==3)
	{
		cout<<empName<<" "<<salary<<" "<<empId<<endl;
	}
}


void Employee::getID() //this function is used to get particular employee details for the database
{
	status1=0;
	int id;
	cout<<"enter the id to be get the details"<<endl;
	cin>>id;
	rewind(fp);

	while(fscanf(fp,"%s %d %d",empName,&salary,&empId)==3) //reading each line to check the id 
	{	
		if(id==empId)
		{    
			status1++;
			cout<<empName<<" "<<salary<<" "<<empId<<endl;
		}

	}
	if(status1==0)
		cout<<"INVALID ID"<<endl;
}

