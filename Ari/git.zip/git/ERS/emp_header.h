

#include<iostream>
using namespace std;

class Employee
{
private:
	char empName[20];
	int salary;
	int empId;
public:
	void addEmp();
	void currentEmp();
	void fireID();
	void formerEmp();
	void getID();
};

