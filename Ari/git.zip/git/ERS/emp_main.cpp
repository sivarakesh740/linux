#include<iostream>
#include<stdlib.h>
#include"emp_function.cpp"

int main()
{
	int op;
	char ch;
	Employee obj;
	do
	{
		cout<<"enter the option 1->add Employee   2-->current Employee   3-->fireId  4-->former Employee 5-->getid"<<endl;
		try
		{
			cin>>op;	
			if(op>=1 && op<=5)
			{
				switch(op)
				{

					case 1:
						obj.addEmp();	
						break;
					case 2: 
						cout<<"******************** displaying the database ***************************************"<<endl;
						obj.currentEmp();
						break;
					case 3:
						cout<<"*************************** delete function  ********************************************"<<endl;
						obj.fireID();
						break;
					case 4:
						cout<<"!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!prev data!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!"<<endl;
						obj.formerEmp();
						break;
					case 5:
						cout<<"$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$ details of the employee $$$$$$$$$$$$$$$$$$$$$$$$$$$$"<<endl;
						obj.getID();
						break;
                                                
				}
				cout<<"do u want to continue"<<endl;
				cin>>ch;
			}
			else
			{
				throw "inalid option ";
			}	
		}
		catch(const char *p)
		{
			cout<<p<<endl;
		}	


	}while(ch=='y');
}
