#include <iostream> 
using namespace std; 

class access 
{ 
protected: 
 int b_pro = 20; 
public: 
  int c_public = 30; 
}; 

class access_modifier: public access 
{ 
public: 
 void disp() 
 { 
   cout<< "protected: "<< b_pro << endl; 
   cout<< "public: " << c_public << endl; 
 } 
 
}; 

int main() 
{ 
 access_modifier a; 
 a.disp(); 
 
 return 0; 
} 

