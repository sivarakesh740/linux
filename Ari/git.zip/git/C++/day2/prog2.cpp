#include <iostream> 
using namespace std; 

class access 
{ 
/*private: 
 int a_pri = 10; 
protected: 
 int b_pro = 20; */
public: 
 int c_public = 30; 
}; 

int main() 
{ 
 access a; 
 /*cout<< "private: " << a.a_pri; 
 cout<< "protected: "<< a.b_pro; */
 cout<< "public: " << a.c_public; 
 
 return 0; 
} 

