#include<iostream>
using namespace std;
x=1;
int main()
{
  cout<<"x<<"<<x<<endl;
  return 0;
}
