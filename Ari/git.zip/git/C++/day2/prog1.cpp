#include <iostream> 
using namespace std; 

class access 
{ 
 int a = 10; 
 void disp() 
 { 
  cout<< "a: "<< a; 
 } 
 
}; 

int main() 
{ 
 access a; 
 a.disp(); 
 return 0; 
} 
