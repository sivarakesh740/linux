#include <iostream> 
using namespace std; 

class access 
{ 
	public: 
		int a_public = 30; 
}; 

class access_modifier: private access 
{ 

}; 

class inheritance:public access_modifier 
{ 
	public: 
		void disp() 
		{ 
			cout<< access::a_public; 
		} 
}; 
int main() 
{ 
	inheritance a; 
	a.disp(); 

	return 0; 
} 

