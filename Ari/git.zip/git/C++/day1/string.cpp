#include<iostream>
using namespace std;
int main()
{
 string k;
 cout<<"string="<<sizeof(k)<<endl;
 return 0;
	}
