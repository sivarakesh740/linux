  #include<iostream>
  using namespace std;
  int main()
  {
      int x=10,y=20,z;
      int &r1=x;
      int &r2=y;
      z=r1+r2;
      cout<<z<<endl;
      z=r1+r2/2;
      cout<<z<<endl;
  }
