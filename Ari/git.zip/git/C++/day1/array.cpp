#include<iostream>
using namespace std;
int main()
{
	int a[5]={12,9,11,32,45},temp,i;
	for(i=0;i<5-1;i++)
	{
		for(int j=i+1;j<5;j++)
		{
			temp=a[i];
			a[i]=a[j];
			a[j]=temp;
		}
	}
	for( i=0;i<5;i++)
		cout<<a[i]<<" "<<endl;
} 
