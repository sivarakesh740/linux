#include<iostream>
#include<ctime>

using namespace std;

int main()
{
	time_t t;
	struct tm  *ti;
	time(&t);

	ti=localtime(&t);
	cout<<"Time "<<asctime(ti);
	return 0;
}
  
