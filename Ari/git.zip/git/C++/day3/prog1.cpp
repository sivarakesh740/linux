#include<iostream> 
class Test { 
static void fun(int i) {} 
void fun(int i) {} 
}; 

int main() 
{ 
Test t; 
getchar(); 
return 0; 
} 

