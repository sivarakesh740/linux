/******************************************************************************
** Automotive Robotics India Pvt  Limited                                    **
**                                                                           **
**Automotive Robotics India Pvt Limited owns all the rights to this work.This work**
** shall not be copied, reproduced, used, modified or its information        **
** disclosed without the prior written authorization of ARI  Technologies    **
** Limited.                                                                  **
**                                                                           **
**  SRC-MODULE: Eep_ConfigTypes.h                                            **
**                                                                           **
**  TARGET    : All                                                          **
**                                                                           **
**  PRODUCT   : AUTOSAR EEPROM                                               **
**                                                                           **
**  PURPOSE   : To implement API's for EEPROM                                **
**                                                                           **
**  PLATFORM DEPENDANT [yes/no]: yes                                         **
**                                                                           **
**  TO BE CHANGED BY USER [yes/no]: no                                       **
**                                                                           **
******************************************************************************/


/******************************************************************************
**                      Revision History                                     **
*******************************************************************************
** Revision  Date           Changed By             Description                **
*******************************************************************************
** 1.0.0     20-July-2018  M Kumar Yadav       Initial version                *
******************************************************************************/


/******************************************************************************
**                      Include Section                                      **
******************************************************************************/
#include "stm32f4xx.h"
#include "stm32f4xx_i2c.h"
#include "Eep.h"



#ifndef EEP_CONFIGTYPES_H_
#define EEP_CONFIGTYPES_H_


 typedef uint32_t Eep_AddressType;
 typedef Eep_AddressType Eep_LengthType;

/******************************************************************************
**   configuration stucture of the EEPROM Module                             **
**                                                                           **
******************************************************************************/



/********************************************************************************************************
**   configuration stucture  for the default EEPROM device mode after initialization             **                                                                                      **
*********************************************************************************************************/

typedef enum
{
    //    The underlying memory abstraction modules and
    //    drivers are working in slow mode.
    MEMIF_MODE_SLOW,
    // The underlying memory abstraction modules and
    // drivers are working in fast mode.
    MEMIF_MODE_FAST
} MemIf_ModeType;


/********************************************************************************************************
**                configuration stucture  for  EEPROM Module Status                                    **                                                                                                    **
*********************************************************************************************************/

typedef enum
{

    //	The underlying abstraction module or device driver has
    //	not been initialized (yet).
    MEMIF_UNINIT,
    // The underlying abstraction module or device driver is
    // currently idle.
    MEMIF_IDLE,
    
    // The underlying abstraction module or device driver is
    // currently busy.
    MEMIF_BUSY,
    
    //	The underlying abstraction module is busy with internal
    // management operations. The underlying device driver
    // can be busy or idle.
    MEMIF_BUSY_INTERNAL              
} MemIf_StatusType;



/********************************************************************************************************
**              Basic   configuration stucture  of EEPROM Module                                       **                                                                                                    **
*********************************************************************************************************/

typedef struct
{

  // This parameter is the EEPROM device base address//
    uint32_t EepBaseAddress;

  // This parameter is the default EEPROM device mode after initialization//
    MemIf_ModeType EepDefaultMode;

  // This parameter is the number of bytes read within one job processing cycle in fast mode//
    uint32_t EepFastReadBlockSize;

  // This parameter is the number of bytes written within one job processing cycle in fast mode//
   uint32_t EepFastWriteBlockSize;

  // call cycle of the job processing function during write/erase operations. Unit: [s]//
    float	 EepJobCallCycle;

  // This parameter is a reference to a callback function for positive job result//
    void (*Eep_JobEndNotification)(void);

  // This parameter is a reference to a callback function for negative job result//
    void (*Eep_JobErrorNotification)(void);

  // number of bytes read within one job processing cycle in normal mode//
     Eep_LengthType  EepNormalReadBlockSize;

  // Number of bytes written within one job processing cycle in normal mode//
    Eep_LengthType  EepNormalWriteBlockSize;

  // This parameter is the used size of EEPROM device in bytes//
    Eep_LengthType 	EepSize;
		
	// This parameter is the used job status  EEPROM //
	  MemIf_StatusType  status;

  // This parameter is the EEPROM page size, i.e. number of bytes//
    Eep_LengthType  EepPageSize;
	 
	// This parameter is used to initilize the i2c module//
		I2C_InitTypeDef  I2C_InitStructure;
		
}Eep_ConfigType;



/********************************************************************************************************
**              Published   configuration stucture  of  EEPROM Module                                 **                                                                                                    **
*********************************************************************************************************/


typedef struct STag_EepPublishedInformation
{
	uint32_t  EepAllowedWriteCycles;  
	float     EepEraseTime;           
	uint32_t  EepEraseUnitSize;       
	uint8_t   EepEraseValue;
	uint32_t  EepMinimumAddressType;
	uint32_t  EepMinimumLengthType;
	uint32_t  EepReadUnitSize;
	uint32_t  EepSpecifiedEraseCycles;
	uint32_t  EepTotalSize;
	float     EepWriteTime;
	uint32_t  EepWriteUnitSize;
		
}EepPublishedInformation_ConfigType; /**/



/********************************************************************************************************
**                Job Notification configuration stucture  of  EEPROM Module                            **                                                                                                    **
*********************************************************************************************************/

typedef enum
{
    //The job has been finished successfully.
    MEMIF_JOB_OK,
    // The job has not been finished successfully.
    MEMIF_JOB_FAILED,
    //	The job has not yet been finished.
    MEMIF_JOB_PENDING,
    //	The job has been canceled.
    MEMIF_JOB_CANCELED,
    //	The requested block is inconsistent, it may contain
    //	corrupted data.	       
    MEMIF_BLOCK_INCONSISTENT,
    // The requested block has been marked as invalid,
    // the requested operation can not be performed.
    MEMIF_BLOCK_INVALID
    
} MemIf_JobResultType; 

/* EEP_CONFIGTYPES_H_*/
#endif 
