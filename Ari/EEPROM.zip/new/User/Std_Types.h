/******************************************************************************
** Automotive Robotics India Pvt  Limited                                    **
**                                                                           **
**Automotive Robotics India Pvt Limited owns all the rights to this work.This work**
** shall not be copied, reproduced, used, modified or its information        **
** disclosed without the prior written authorization of ARI  Technologies    **
** Limited.                                                                  **
**                                                                           **
**  SRC-MODULE: Std_Types.h                                                  **
**                                                                           **
**  TARGET    : All                                                          **
**                                                                           **
**  PRODUCT   : AUTOSAR EEPROM                                               **
**                                                                           **
**  PURPOSE   : To implement API's for EEPROM                                **
**                                                                           **
**  PLATFORM DEPENDANT [yes/no]: yes                                         **
**                                                                           **
**  TO BE CHANGED BY USER [yes/no]: no                                       **
**                                                                           **
******************************************************************************/


/** @file Std_Types.h
 *  Definitions of General types.
 */
 
 /******************************************************************************
**                      Revision History                                     **
*******************************************************************************
** Revision  Date           Changed By             Description                **
*******************************************************************************
** 1.0.0     14-June-2018  M Kumar Yadav       Initial version                *
******************************************************************************/

/******************************************************************************
**                      Include Section                                      **
******************************************************************************/
#include <string.h>
#include <stdio.h>
#include "Eep_ConfigTypes.h"
#ifndef STD_TYPES_H
#define STD_TYPES_H

/******************************************************************************
**                              Version Imforamtion                          **
******************************************************************************/
#define EEP_SW_MAJOR_VERSION_VALUE   (0x01u)
#define EEP_SW_MAJOR_VERSION         EEP_SW_MAJOR_VERSION_VALUE
#define EEP_SW_MAJOR_VERSION         EEP_SW_MAJOR_VERSION_VALUE
 
#define EEP_SW_MINOR_VERSION_VALUE   (0x00u)
#define EEP_SW_MINOR_VERSION         EEP_SW_MINOR_VERSION_VALUE
#define EEP_SW_MINOR_VERSION         EEP_SW_MINOR_VERSION_VALUE
	
#define EEP_SW_PATCH_VERSION_VALUE   (0x00u)
#define EEP_SW_PATCH_VERSION         EEP_SW_PATCH_VERSION_VALUE
#define EEP_SW_PATCH_VERSION         EEP_SW_PATCH_VERSION_VALUE


/* AUTOSAR Specification Version Information */ 

#define   DET_AR_RELEASE_MAJOR_VERSION      4
#define   DET_AR_RELEASE_MINOR_VERSION      3
#define   DET_AR_RELEASE_REVISION_VERSION   1
#define   DET_MODULE_ID          (uint16_t)15
#define   ONE					        1u
#define   ELEMENT_ZERO			  0u
#define   EEP_JOB_IDLE		    255u


/******************************************************************************
**                              Service IDs                                  **
******************************************************************************/
/* service ID of functionality of EEPROM */

#define EEP_SETMODE_SID						   (uint8_t)0x01
#define EEP_READ_SID						     (uint8_t)0x02
#define EEP_WRITE_SID						     (uint8_t)0x03
#define EEP_ERASE_SID						     (uint8_t)0x04
#define EEP_COMPARE_SID						   (uint8_t)0x05
#define EEP_GETVERSIONINFO_SID			 (uint8_t)0x0A


/*Service ID for DET errors*/

#define EEP_E_PARAM_ADDRESS                   (uint8_t)0x11
#define EEP_E_PARAM_DATA                      (uint8_t)0x12
#define EEP_E_PARAM_LENGTH                    (uint8_t)0x13
#define EEP_E_UNINIT                          (uint8_t)0x20
#define EEP_E_BUSY                            (uint8_t)0x21 
#define EEP_E_PARAM_POINTER                   (uint8_t)0x23  


 #define EEP_MODULE_ID_VALUE	 	    (0x5Au)
 #define EEP_MODULE_ID              EEP_MODULE_ID_VALUE
 #define EEP_MODULE_ID              EEP_MODULE_ID_VALUE
 
#define EEP_INSTANCE_ID_VALUE     (0x01u)
#define EEP_INSTANCE_ID           EEP_INSTANCE_ID_VALUE
#define EEP_INSTANCE_ID           EEP_INSTANCE_ID_VALUE
#define EEP_E_UNINIT              (uint8_t)0x20
#define EEP_E_BUSY                (uint8_t)0x21 
#define EEP_E_PARAM_ADDRESS       (uint8_t)0x11

#define EEP_CONFIG_DATA 
#define EEP_CODE
#define EEP_CONST 

#define EEP_APPL_DATA
#define EEP_RSCAN_PUBLIC_CODE
#define EEP_VAR_NOINIT
#define TRUE                 1u
#define FALSE                0u
#define ELEMENT_ZERO			   0u
#define ELEMENT_ONE 			   1u
#define ELEMENT_TWO 			   2u
#define ZERO					0u
#define ONE						1u
#define TWO						2u
#define FOUR					4u
#define EIGHT					8u
#define EEP_JOB_COMPLETE		240u
#define EEP_JOB_IDLE			  255u

/******************************************************************************
**                     Job Oparetions macros                                 **
******************************************************************************/
 #define EEP_READ_OP		 0x01u
 #define EEP_WRITE_OP    0x02u
 #define EEP_ERASE_OP    0x03u
 #define EEP_COMPARE_OP	 0x04u
 #define EEP_NOTIFICATION_OP	0x05u


/******************************************************************************
**                     Standered macros for i2c module                       **
******************************************************************************/
#define   E2_WREN   0x6		// Write Enable 0000 0110
#define   E2_WRDI   0x4		// Write Disable 0000 0100
#define   E2_RDSR   0x5		// Read Status Register  0000 0101
                                                    // 1 - Read data
#define   E2_WRSR   0x1		// Write Status Register  0000 0001
                                                    // 1 - Write data
#define   E2_READ   0x3		// Read from Memory Array 0000 0011
                                                    // 1  - Write 16-bit address
                                                    // n  - 8 -bit read data
#define  E2_WRITE   0x2		// WRITE  Write to Memory Array  0000 0010
                                                    // 1  Write 16-bit address
                                                    // n  - 8-bit reads
																										

/******************************************************************************
**                    Helper macro for the process function                  **
******************************************************************************/

#define  PROC_SET_STATE(_done,_state) done=(_done);job->state=(_state)
#define  DONE                TRUE
#define  NOT_DONE            FALSE

/******************************************************************************
**                     det checking macro's and i2c module macros            **
******************************************************************************/

#define E_OK 					                0u
#define E_NOT_OK 				             (uint8_t)1u

#define E_NO_DTC_AVAILABLE		    (Std_ReturnType)2u
#define E_SESSION_NOT_ALLOWED	    (Std_ReturnType)4u
#define E_PROTOCOL_NOT_ALLOWED	  (Std_ReturnType)5u
#define E_REQUEST_NOT_ACCEPTED	  (Std_ReturnType)8u
#define E_REQUEST_ENV_NOK		      (Std_ReturnType)9u
#define E_PENDING				          (Std_ReturnType)10u
#define E_COMPARE_KEY_FAILED	    (Std_ReturnType)11u
#define E_FORCE_RCRRP			        (Std_ReturnType)12u

#define STD_HIGH		0x01u
#define STD_LOW			0x00u

#define STD_ACTIVE		0x01u
#define STD_IDLE		  0x00u

#define STD_ON			0x01u
#define STD_OFF			0x00u

/******************************************************************************
**     configuration structure  of the EEPROM driver            	           **
******************************************************************************/

typedef enum
{
    EEP_NONE,EEP_WRITE,EEP_READ ,EEP_Cancel,EEP_GetStatus,EEP_GetJobResult,EEP_GetVersionInfo,
} Eep_JobType;

/* i2c  job state */
typedef enum
{
    JOB_MAIN, JOB_READ_STATUS, JOB_READ_STATUS_RESULT,
} Job_StateType;

//*******************************************************************************//
                //Information about a job//                          
//*******************************************************************************//

typedef struct
{
    uint8_t *targetAddr;
	 /*eeprom address type member*/
      uint32_t  eepAddr;
   /*job oparation type*/
      uint32_t left;
	 /*job state type*/
      Job_StateType state;
      uint16_t chunkSize;
	 /*eeprom pagesize*/
      uint16_t pageSize;
}Eep_JobInfoType;

//*******************************************************************************//
                // Job Oparetion structure//                          
//*******************************************************************************//

typedef struct                                  
{
   //* The configuration*//
     const Eep_ConfigType *config;
   /* Status of driver*/
     MemIf_StatusType status;
   /*job operation result type*/
     MemIf_JobResultType jobResultType;
	 /*job Job Operation Data Type*/
     Eep_JobType  jobType;
   /* What mode we are in ( normal/fast )*/
     MemIf_ModeType  mode;
	 /*job Job Operation Data Type*/
  	 uint8_t *RdDataBufer;
	 /*job Job Operation Data Type*/
	   const uint8_t *ConstDataBufer;
	 /*job Job Operation Data Type*/
	   uint16_t  NextMemoryAddr;
	 /*job Job Operation Data Type*/
	   uint16_t  PageSize;
	 /*job Job Operation Data Type*/
		 uint16_t  PrePageByteOPeration;
	 /*job Job Operation Data Type*/
	   uint16_t  PageOPeration;
	 /*job Job Operation Data Type*/
	   uint16_t  PostPageByteOPeration;
    /*Hold job information*/
     Eep_JobInfoType  *job;
		/*i2c address type */
		uint8_t  I2C_ChipAddr;
}Eep_GlobalType;


#ifndef 	NULL
//lint -esym(960,20.2) // PC-Lint LINT EXCEPTION
#define	NULL	0
#endif


//*******************************************************************************//
                // version Imformation  structure//                          
//*******************************************************************************//
typedef struct
{ 
    uint16_t moduleID;                  
    uint8_t	sw_major_version;    /**< Vendor numbers */
    uint8_t sw_minor_version;    /**< Vendor numbers */
    uint8_t sw_patch_version;    /**< Vendor numbers */
} Std_VersionInfoType;


#endif
