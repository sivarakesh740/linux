/******************************************************************************
** Automotive Robotics India Pvt  Limited                                    **
**                                                                           **
**Automotive Robotics India Pvt Limited owns all the rights to this work.This work**
** shall not be copied, reproduced, used, modified or its information        **
** disclosed without the prior written authorization of ARI  Technologies    **
** Limited.                                                                  **
**                                                                           **
**  SRC-MODULE: Eep.h                                                        **
**                                                                           **
**  TARGET    : All                                                          **
**                                                                           **
**  PRODUCT   : AUTOSAR EEPROM                                               **
**                                                                           **
**  PURPOSE   : To implement API's prototype for EEPROM                      **
**                                                                           **
**  PLATFORM DEPENDANT [yes/no]: yes                                         **
**                                                                           **
**  TO BE CHANGED BY USER [yes/no]: no                                       **
**                                                                           **
******************************************************************************/

#ifndef EEP_H_
#define EEP_H_

/** @tagSettings DEFAULT_ARCHITECTURE=PPC|MPC5645S|MPC5607B  */
/** @reqSettings DEFAULT_SPECIFICATION_REVISION=4.1.2 */

/******************************************************************************
**                      Revision History                                     **
*******************************************************************************
** Revision  Date           Changed By             Description               **
*******************************************************************************
** 1.0.0     20-July-2018   M Kumar Yadav         Initial version            *
******************************************************************************/



/******************************************************************************
**                      Include Section                                      **
******************************************************************************/
#include "Std_Types.h"
#include "MemIfTypes.h"
#include <string.h>
#include "stdio.h"
#include "Eep_ConfigTypes.h"
#include "Std_Types.h"
#include "stm32f4xx.h"


 /*****************************************************************************
**                      Function Prototypes                                  **
******************************************************************************/

/** @req SWS_Eep_00143 */
extern void Eep_Init( const Eep_ConfigType *ConfigPtr );

/** @req SWS_Eep_00147 */
uint32_t Eep_Erase(	Eep_AddressType   EepromAddress,Eep_LengthType  Length );

/** @req SWS_Eep_00146 */
uint32_t Eep_Write (Eep_AddressType EepromAddress,const uint8_t *DataBufferPtr,Eep_LengthType Length);

/*I2C Write Funtion*/																													
uint32_t I2C_WriteOneByte(I2C_TypeDef *I2Cx, uint8_t I2C_Addr,uint8_t addr,uint8_t *buf,uint16_t num);

/** @req SWS_Eep_00149 */
void Eep_Cancel( void );

/** @req SWS_Eep_00150 */
MemIf_StatusType 	Eep_GetStatus(	void );
/** @req SWS_Eep_00151 */

MemIf_JobResultType Eep_GetJobResult( void );

/** @req SWS_Eep_00153 */
void Eep_MainFunction( void );

/** @req SWS_Eep_00145 */
	uint32_t Eep_Read (	Eep_AddressType EepromAddress,uint8_t *TargetAddressPtr,Eep_LengthType Length );
	
/*SWS_Eep_00147*/													
uint32_t Eep_Erase(Eep_AddressType EepromAddress, Eep_LengthType Length);

/** @req SWS_Eep_00148 */
uint32_t Eep_Compare(Eep_AddressType EepromAddress,const uint8_t *DataBufferPtr,Eep_LengthType Length);

/* function to send the proper notification to the upper upon completion of the job of eeprom driver*/


/** @req SWS_Eep_00144 */
void Eep_SetMode( MemIf_ModeType Mode);
	
	
#if ( EEP_VERSION_INFO_API == STD_ON )
/** @req SWS_Eep_00152 */
void Eep_GetVersionInfo( Std_VersionInfoType *versionInfo );
#endif
/* This parameter is the total EEPROM size*/
#define EepTotalSize   1024

/* This parameter is the no. of pages in bits*/
#define PAGESIZE    4

/*****************************************************************************
**                  I2C  job in page wise function Prototypes               **
******************************************************************************/													
/* void Eep_pagewise(uint16_t ulEep_Address, uint16_t ulBlock, 
                   uint16_t *MemCount, uint16_t ulLength);*/
 
 
/*****************************************************************************
**                    configuration  Structure   Prototypes                 **
******************************************************************************/

extern const Eep_ConfigType EepConfigData[];

extern  Std_VersionInfoType Std_VersionIn[];
 
extern  EepPublishedInformation_ConfigType   EepPublishedInformationconfig[]; 

 
#endif /*EEP_H_*/
