/******************************************************************************
** Automotive Robotics India Pvt  Limited                                    **
**                                                                           **
**Automotive Robotics India Pvt Limited owns all the rights to this work.This work**
** shall not be copied, reproduced, used, modified or its information        **
** disclosed without the prior written authorization of ARI  Technologies    **
** Limited.                                                                  **
**                                                                           **
**  SRC-MODULE: MemIfTypes.h                                                 **
**                                                                           **
**  TARGET    : All                                                          **
**                                                                           **
**  PRODUCT   : AUTOSAR EEPROM                                               **
**                                                                           **
**  PURPOSE   : To implement API's for EEPROM                                **
**                                                                           **
**  PLATFORM DEPENDANT [yes/no]: yes                                         **
**                                                                           **
**  TO BE CHANGED BY USER [yes/no]: no                                       **
**                                                                           **
******************************************************************************/
/** @reqSettings DEFAULT_SPECIFICATION_REVISION=4.0.3 */
#ifndef MEMIF_TYPES_H_
#define MEMIF_TYPES_H_


/******************************************************************************
**                      Revision History                                     **
*******************************************************************************
** Revision  Date           Changed By             Description                **
*******************************************************************************
** 1.0.0     20-July-2018   M Kumar Yadav       Initial version               *
******************************************************************************/

/******************************************************************************
**                      Include Section                                      **
******************************************************************************/
/* @req MemIf009 */
/* @req MemIf010 */


#endif /*MEMIF_TYPES_H_*/
