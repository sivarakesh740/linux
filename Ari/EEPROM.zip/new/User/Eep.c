/******************************************************************************
** Automotive Robotics India Pvt  Limited                                    **
**                                                                           **
**Automotive Robotics India Pvt Limited owns all the rights to this work.This work**
** shall not be copied, reproduced, used, modified or its information        **
** disclosed without the prior written authorization of ARI  Technologies   **
** Limited.                                                                  **
**                                                                           **
**  SRC-MODULE: Eep.c                                                        **
**                                                                           **
**  TARGET    : All                                                          **
**                                                                           **
**  PRODUCT   : AUTOSAR EEPROM                                               **
**                                                                           **
**  PURPOSE   : To implement API's for EEPROM                                **
**                                                                           **
**  PLATFORM DEPENDANT [yes/no]: yes                                         **
**                                                                           **
**  TO BE CHANGED BY USER [yes/no]: no                                       **
**                                                                           **
******************************************************************************/

/** @tagSettings DEFAULT_ARCHITECTURE=PPC|STM32f407  */
/** @reqSettings DEFAULT_SPECIFICATION_REVISION=4.1.2 */
/* REQUIREMENTS
 * - EEP060
 *   Only EEP_WRITE_CYCLE_REDUCTION = STD_OFF is supported
 *
 * - EEP075
 *   MEMIF_COMPARE_UNEQUAL does not exist in the MemIf specification 1.2.1(rel 3.0 )
 *   So, it's not supported. It returns MEMIF_JOB_FAILED instead.
 *
 * - EEP084
 *   EepJobCallCycle not used
 *   We are not using interrupts so EEP_USE_INTERRUPTS must be STD_OFF
 */
 
/******************************************************************************
**                      Revision History                                     **
*******************************************************************************
** Revision  Date           Changed By             Description                **
*******************************************************************************
** 1.0.0     20-July-2018   M Kumar Yadav       Initial version               *
******************************************************************************/


/******************************************************************************
**                      Include Section                                      **
******************************************************************************/
#include "MemIfTypes.h"
#include "Eep.h"
#include "24C02.h"
#include "Eep_ConfigTypes.h"
#include "stm32f4xx.h"
#include "stm32f4xx_gpio.h"
#include  "stm32f4xx_i2c.h"
#include "Std_Types.h"
#include <stdlib.h>
#include <string.h>




/* The width in bytes used by this eeprom */
 #define ADDR_LENGTH 	32
/* I2C Adrees*/


/******************************************************************************
**                      Include Section                                      **
******************************************************************************/
/*
 * This header file includes all the standard data types, platform dependent
 * header file and common return types
 */

/******************************************************************************

**                      Global Macro Definitions                              *

******************************************************************************/
 #define  EEP_MEMARRAY_ELEMENT_CNT	  3u
 #define  EEP_I2C_ADDRESS           (uint8_t)0x40005800
 /*****************************************************************************
**                      Function Prototypes                                  **
******************************************************************************/

/******************************************************************************

**                      Global Variable Declarations                          *

*******************************************************************************/
  uint32_t   Eep_GddModuleState;
  uint32_t   Eep_GddJobResult;
  uint32_t   Eep_GusJobStage;
  uint16_t   Eep_GusLddErr;
  uint32_t   Eep_GddMode;
  uint32_t  Eep_GddCancelCmdReceive;

/******************************************************************************

**                      Global Type Definitions                               *

******************************************************************************/
 Eep_GlobalType Eep_JobsOP;
 Eep_GlobalType  Eep_PageSetupJob;
 Eep_GlobalType  EepInitConfiguration;
 


/******************************************************************************

**                      Global Constant Declarations                          *

******************************************************************************/


/******************************************************************************

**                      Global Function Declarations                         **

******************************************************************************/
/******************************************************************************
**                      Job Operation Data Type                              **



                    Function Definitions                                  
/*******************************************************************************/
/******************************************************************************
** Function Name                : Eep_Init
**
** Service ID                   : 0x00
**
** Description                  : Service for EEPROM initialization
**                         
** Sync/Async                   : Synchronous
**
** Re-entrancy                  : Non Reentrant
**
** Input Parameters             : ConfigPtr
**
** Parameter Description        : Config Structure type pointer
**
** InOut Parameters             : None
**
** Output Parameters            : None
**
** Return parameter             : None
**
** Preconditions                : None
**
** Global Variables             : Eep_GddModuleState,EepInitConfiguration,
**                                Eep_GddJobResult
**
** Functions invoked            : I2C_Configuration( )
**
** Registers Used               : None
**
******************************************************************************/

void Eep_Init(const Eep_ConfigType  *ConfigPtr)
		{

				EepInitConfiguration.config = ConfigPtr;
				/* initialize Module State */
				Eep_GddModuleState=MEMIF_BUSY_INTERNAL;
				/* Initializing i2c Module*/
				I2C_Configuration( );
				/* after completing i2c intialization, initialize Module State as IDLE */
				Eep_GddModuleState = MEMIF_IDLE;
				/* initialize Job result */
				Eep_GddJobResult=MEMIF_JOB_OK;
				/*setting slow mode as default eeprom mode*/
				Eep_SetMode(MEMIF_MODE_SLOW);
				/*making the execution state of eep main function as idle*/
				Eep_GusJobStage = EEP_JOB_IDLE;

		}

/******************************************************************************
** Function Name                 : Eep_SetMode
**
** Service ID                    : 0x01
**
** Description                   : Sets the mode
**                         
**
** Sync/Async                    : Synchronous
**
** Re-entrancy                   : Non Reentrant
**
** Input Parameters              : Mode
**
** Parameter Description         : Enum type parameter
**
** InOut Parameters              : None
**
** Output Parameters             : None
**
** Return parameter              : None
**
** Preconditions                 : None
**
** Global Variables              : Eep_GddMode,Eep_GddModuleState
**
** Functions invoked             : None
**
** Registers Used                : None
**
******************************************************************************/

void Eep_SetMode (MemIf_ModeType Mode )
{   

				if(MEMIF_UNINIT == Eep_GddModuleState)
					{

					#if (EEP_DEV_ERROR_DETECT == STD_ON)

					/* Report to DET */
					(void)Det_ReportError(EEP_MODULE_ID, EEP_INSTANCE_ID, EEP_SETMODE_SID, EEP_E_UNINIT);
					#endif
						

					} 
				else
					{
					/* Check if the module is Busy with some other request */
					if(MEMIF_BUSY == Eep_GddModuleState)
					{
					#if (EEP_DEV_ERROR_DETECT == STD_ON)

					/* Report to DET */
					(void)Det_ReportError(EEP_MODULE_ID, EEP_INSTANCE_ID, EEP_SETMODE_SID,EEP_E_BUSY);
					#endif

					}
				else if(MEMIF_BUSY_INTERNAL == Eep_GddModuleState)
					{
					/*Do nothing*/

					}
				/* set mode of eeprom when state is IDLE */
				else if(MEMIF_IDLE == Eep_GddModuleState) 
					{
					/*set the mode of EEPROM*/
					Eep_GddMode=Mode;
					}
				}

}

/******************************************************************************
** Function Name             : Eep_Read
**
** Service ID                : 0x02
**
** Description               : Reads from EEPROM
**                         
**
** Sync/Async                : Asynchronous
**
** Re-entrancy               : Non Reentrant
**
** Input Parameters          : EepromAddress ,Length,DataBufferPtr
**
** Parameter Description     : EepromAddress is of unsigned 32-bit variable,DataBufferPtr is of const buffer,Length is of unsigned 32-bit variable 
**
** InOut Parameters          : None
**
** Output Parameters         : DataBufferPtr
**
** Return parameter          : Std_ReturnType
**
** Preconditions             : None
**
** Global Variables          : Eep_GddModuleState,Eep_GddJobResult
**                        
** Functions invoked         : I2C_Read.
**
** Registers Used            : None
**
******************************************************************************/
uint32_t Eep_Read(Eep_AddressType EepromAddress,uint8_t *DataBufferPtr, Eep_LengthType Length)
  {
					
					uint16_t LddReturnVal;
						uint8_t byte_cnt=0;
					uint8_t data_cnt=0;
					//static	 uint16_t addr=0;
						uint8_t databufsize=PAGESIZE;
					/*Std_ReturnType LddReturnI2CVal;*/
					LddReturnVal = E_OK;
		
					/* Check if the Eep module is initialized */
					if(MEMIF_UNINIT == Eep_GddModuleState)
						{
						#if (EEP_DEV_ERROR_DETECT == STD_ON)
						/* Report to DET */
						(void)Det_ReportError(EEP_MODULE_ID, EEP_INSTANCE_ID, EEP_READ_SID,EEP_E_UNINIT);
						#endif

						/* Set the Return value to not OK */
						LddReturnVal = E_NOT_OK;

					} /* if(Eep_GddModuleState == MEMIF_UNINIT) */
					else
						{
						/* Check if the module is Busy with some other request */
						if(MEMIF_BUSY == Eep_GddModuleState)
						{
						#if (EEP_DEV_ERROR_DETECT == STD_ON)	
						/* Report to DET */
						(void)Det_ReportError(EEP_MODULE_ID, EEP_INSTANCE_ID, EEP_READ_SID, EEP_E_BUSY);
						#endif
						/* Set the Return value to not OK */
						LddReturnVal = E_NOT_OK;
						}/* if(Eep_GddModuleState == MEMIF_BUSY) */
					/* if(Eep_GddModuleState == MEMIF_BUSY_INTERNAL) */
						
					else if(MEMIF_BUSY_INTERNAL == Eep_GddModuleState)
						{
						/* Set the Return value to E_OK */
						LddReturnVal = E_OK;
						}
						else
						{
						/* Do Nothing */
						}
					/* Check if NULL Pointer is passed */
					if(NULL == DataBufferPtr)
						{
						#if (EEP_DEV_ERROR_DETECT == STD_ON)
						/* Report to DET */
						(void)Det_ReportError(EEP_MODULE_ID, EEP_INSTANCE_ID, EEP_READ_SID,EEP_E_PARAM_DATA);
						#endif
						/* Set the Return value to not OK */
						LddReturnVal = E_NOT_OK;
					  } /* if(DataBufferPtr == NULL_PTR) */

					/* check for Return value to E_OK */
					if(E_NOT_OK != LddReturnVal)
						{

						/* Check if address is in range */
						if( EepromAddress <= (EepTotalSize - ONE) )
						{

						if((Length>=ONE) && (EepTotalSize-EepromAddress))
						{	
							//Eep_GddModuleState = MEMIF_BUSY;
							//Eep_GddJobResult = MEMIF_JOB_PENDING;
							for(byte_cnt=0,data_cnt=0;byte_cnt<Length;(byte_cnt+=PAGESIZE),data_cnt++)
							{
								/*if(Eep_GddJobResult == MEMIF_JOB_CANCELED)
								{
									//Eep_GddModuleState = MEMIF_IDLE;
									LddReturnVal = E_NOT_OK;
									return LddReturnVal;
								}*/
                if(Length % PAGESIZE !=0)	
								{
									databufsize = Length % PAGESIZE;
								}
								if(data_cnt == Length/PAGESIZE)
								{
									//delay_us(1);
									I2C_Read(I2C2,0XA0,EepromAddress,DataBufferPtr,databufsize);
								}
								else
								{
									//delay_us(1);
									I2C_Read(I2C2,0XA0,EepromAddress,DataBufferPtr,PAGESIZE);
									EepromAddress=EepromAddress + PAGESIZE;
									DataBufferPtr = DataBufferPtr + PAGESIZE;
								}
             }
						  return(LddReturnVal);
						}
					  else
					 {
						#if (EEP_DEV_ERROR_DETECT == STD_ON)
						/* Report to DET */
						(void)Det_ReportError(EEP_MODULE_ID,EEP_INSTANCE_ID,EEP_READ_SID,EEP_E_PARAM_LENGTH);
						#endif
						LddReturnVal = E_NOT_OK;
					}	
					}
					else
					{   
						#if (EEP_DEV_ERROR_DETECT == STD_ON)
						/* Report to DET */
						(void)Det_ReportError(EEP_MODULE_ID, EEP_INSTANCE_ID, EEP_READ_SID,EEP_E_PARAM_ADDRESS);
						#endif 
						/* Set the Return value to not OK */
						LddReturnVal = E_NOT_OK;
					}
					}/*if(E_NOT_OK != LddReturnVal)*/
					else
					{
					/* Do Nothing */
					}
					}/*end of else*/
					/* Return the Std_ReturnType */
					I2C_Read(I2C2,0XA0,0,DataBufferPtr,sizeof(DataBufferPtr));
					return(LddReturnVal);
}
	


/******************************************************************************
** Function Name                 : Eep_Write
**
** Service ID                    : 0x03
**
** Description                   : Writes to EEPROM
**                         
** Sync/Async                    : Asynchronous
**
** Re-entrancy                   : Non Reentrant
**
** Input Parameters              : EepromAddress ,Length ,DataBufferPtr
**
** Parameter Description         : EepromAddress is of unsigned 32-bit variable,DataBufferPtr is of const buffer,Length is of unsigned 32-bit variable 
**
** InOut Parameters              : None
**
** Output Parameters             : None
**
** Return parameter              : Std_ReturnType
**
** Preconditions                 : None
**
** Global Variables              : Eep_GddModuleState,Eep_GddJobResult,
**                        
** Functions invoked             : I2C_Write().
**
** Registers Used                : None
**
******************************************************************************/

uint32_t Eep_Write (Eep_AddressType EepromAddress,const uint8_t *DataBufferPtr,Eep_LengthType Length)
 {
				uint16_t  LddReturnVal;
				//static	 uint16_t addr=0;
					 uint8_t byte_cnt=0;
				 uint8_t data_cnt=0;
					uint8_t databufsize=PAGESIZE;
				LddReturnVal = E_OK;
				if(MEMIF_UNINIT == Eep_GddModuleState)
				{
					#if (EEP_DEV_ERROR_DETECT == STD_ON)	
					/* Report to DET */
					(void)Det_ReportError(EEP_MODULE_ID, EEP_INSTANCE_ID, EEP_WRITE_SID,EEP_E_UNINIT);
					#endif 
					/* Set the Return value to not OK */
					LddReturnVal = E_NOT_OK;
				} /* if(Eep_GddModuleState == MEMIF_UNINIT) */
				else
				{
						/* Check if the module is Busy with some other request */
						if(MEMIF_BUSY == Eep_GddModuleState)
						{
							#if (EEP_DEV_ERROR_DETECT == STD_ON)
							/* Report to DET */
							(void)Det_ReportError(EEP_MODULE_ID, EEP_INSTANCE_ID,EEP_WRITE_SID,EEP_E_BUSY);
							#endif 
							/* Set the Return value to not OK */
							LddReturnVal = E_NOT_OK;
						} /*if(Eep_GddModuleState == MEMIF_BUSY) */
						/* if(Eep_GddModuleState == MEMIF_BUSY_INTERNAL) */
						else if(MEMIF_BUSY_INTERNAL == Eep_GddModuleState)
						{
						LddReturnVal = E_OK;
						}
						else
						{
						/* Do Nothing */
						}
						/* Check if NULL Pointer is passed */
						if(NULL == DataBufferPtr)
						{
							#if (EEP_DEV_ERROR_DETECT == STD_ON)
							/* Report to DET */
							(void)Det_ReportError(EEP_MODULE_ID, EEP_INSTANCE_ID,EEP_WRITE_SID,EEP_E_PARAM_DATA);
							#endif
							/* Set the Return value to not OK */
							LddReturnVal = E_NOT_OK;
						} /* if(DataBufferPtr == NULL_PTR) */
						else
						{
						/* Do Nothing */
						}
						/* Check for Return value is E_OK */
						if(E_NOT_OK != LddReturnVal)
						{      
							if(E_OK == LddReturnVal)
							{
							/* Check if address is in range */
							if( EepromAddress <= (EepTotalSize  - ONE) )
							{
							if((Length>=ONE) &&(Length<=( EepTotalSize-EepromAddress)))
							{
							/*Set Busy Flag for bus Busy */
							//Eep_GddModuleState = MEMIF_BUSY;
							//Eep_GddJobResult = MEMIF_JOB_PENDING;
							for(byte_cnt=0,data_cnt=0;byte_cnt<Length;byte_cnt += PAGESIZE,data_cnt++)
							{
								/*if(Eep_GddJobResult == MEMIF_JOB_CANCELED)
								{

								LddReturnVal = E_NOT_OK;
								//Eep_GddModuleState = MEMIF_IDLE;
								return LddReturnVal;
								}	*/											 
								if(Length % PAGESIZE !=0)	
								{
								databufsize = Length % PAGESIZE;
								}
								if(data_cnt == (Length/PAGESIZE))
								{
								 //delay_us(1);
								I2C_Write( I2C2,0XA0,EepromAddress,(uint8_t*)DataBufferPtr,databufsize);
								}
								else
								{
								//delay_us(1); 
								I2C_Write( I2C2,0XA0,EepromAddress,(uint8_t*)DataBufferPtr,PAGESIZE);

								EepromAddress =EepromAddress+PAGESIZE;
								DataBufferPtr = DataBufferPtr + PAGESIZE;

								}
							}
							return(LddReturnVal);
							}
							else
							{
								#if (EEP_DEV_ERROR_DETECT == STD_ON)    
								/* Report to DET */
								(void)Det_ReportError(EEP_MODULE_ID, EEP_INSTANCE_ID,EEP_WRITE_SID,EEP_E_PARAM_LENGTH);
								#endif
								LddReturnVal = E_NOT_OK;
							}	
							}
							else
							{
								#if (EEP_DEV_ERROR_DETECT == STD_ON)     
								/* Report to DET */
								(void)Det_ReportError(EEP_MODULE_ID, EEP_INSTANCE_ID,EEP_WRITE_SID,EEP_E_PARAM_ADDRESS);
								#endif
								LddReturnVal = E_NOT_OK;
								/*Eep_GddJobResult = MEMIF_JOB_FAILED; */
							}
						}/*end of if(E_OK == LddReturnVal)*/
						else 
						{
						/* Do Nothing */
						}

						}     /*end of if(E_NOT_OK != LddReturnVal)*/
				}       /* End of "else" for if(Eep_GddModuleState != Eep_INIT) */
				/* Return the Std_ReturnType */   
			//	I2C_Write(I2C2,0XA0);
					return(LddReturnVal);
}


/******************************************************************************
** Function Name              : Eep_Erase
**
** Service ID                 : 0x04
**
** Description                : Erase to EEPROM
**                         
** Sync/Async                 : Asynchronous
**
** Re-entrancy                : Non Reentrant
**
** Input Parameters           : EepromAddress ,Length 
**
** Parameter Description      : EepromAddress is of unsigned 32-bit variable,Length is of unsigned 32-bit variable
**  
** InOut Parameters           : None
**
** Output Parameters          : None
**
** Return parameter           : Std_ReturnType
**
** Preconditions              : None
**
** Global Variables           : Eep_GddModuleState,Eep_GddJobResult
**                         
** Functions invoked          : I2C_Write
**
** Registers Used             : None                             						  
******************************************************************************/

uint32_t  Eep_Erase(Eep_AddressType EepromAddress,Eep_LengthType Length)
 {
			uint16_t LddReturnVal;
			// uint16_t Eep_MemCountArray[EEP_MEMARRAY_ELEMENT_CNT];

			uint8_t databufsize=PAGESIZE;
			uint8_t buf[PAGESIZE]={0XFF,0XFF,0XFF,0XFF};	 
			//static uint16_t addr=0; 
			uint8_t byte_cnt=0;
			uint8_t data_cnt=0;
			LddReturnVal = E_OK;

			/* Check if the Eep module is initialized */
			if(MEMIF_UNINIT == Eep_GddModuleState)
			{
				#if (EEP_DEV_ERROR_DETECT == STD_ON)
				/* Report to DET */
				(void)Det_ReportError(EEP_MODULE_ID, EEP_INSTANCE_ID, EEP_ERASE_SID,EEP_E_UNINIT);
				#endif
				/* Set the Return value to not OK */
				LddReturnVal = E_NOT_OK;

			} /* if(Eep_GddModuleState == MEMIF_UNINIT) */
			else
			{
					/* Check if the module is Busy with some other request */
					if(MEMIF_BUSY == Eep_GddModuleState)
					{
						#if (EEP_DEV_ERROR_DETECT == STD_ON)
						/* Report to DET */
						(void)Det_ReportError(EEP_MODULE_ID, EEP_INSTANCE_ID,EEP_ERASE_SID,EEP_E_BUSY);
						#endif
						/* Set the Return value to not OK */
					LddReturnVal = E_NOT_OK;
					} /* if(Eep_GddModuleState == MEMIF_BUSY) */
					/* if(Eep_GddModuleState == MEMIF_BUSY_INTERNAL) */
					else if(MEMIF_BUSY_INTERNAL == Eep_GddModuleState)
					{
						/* Set the Return value to E_OK */
						LddReturnVal = E_OK;
					}
					else
					{
					/* Do Nothing */
					}
					/* check for Return value to E_OK */
					if(E_NOT_OK != LddReturnVal)
					{
						/* Check if address is in range */
						if( EepromAddress <=EepTotalSize  - ONE) 
						{	
							if(( Length <= (EepTotalSize-EepromAddress))&& (Length >= ONE))
							{	
									/*Set Busy Flag for bus Busy */
									Eep_GddModuleState = MEMIF_BUSY;
									/*Setting job result as pending*/
									Eep_GddJobResult = MEMIF_JOB_PENDING;
									for(byte_cnt=0,data_cnt=0;byte_cnt < Length;byte_cnt+=PAGESIZE,data_cnt++)
									{
									if(Length %PAGESIZE !=0)
									{
									databufsize = Length % PAGESIZE;
									}
									if(data_cnt == (Length/PAGESIZE) )
									{
									I2C_Write( I2C2,0XA0,EepromAddress,buf,databufsize);
									}
									else
									{
									I2C_Write( I2C2,0XA0,EepromAddress,buf,PAGESIZE);
									EepromAddress=EepromAddress+ PAGESIZE;
									}
									}		      
			        }
							else
							{
								#if (EEP_DEV_ERROR_DETECT == STD_ON)        
								/* Report to DET */
								(void)Det_ReportError(EEP_MODULE_ID, EEP_INSTANCE_ID,EEP_ERASE_SID,EEP_E_PARAM_LENGTH);
								#endif
								/*setting return value as E_NOT_OK*/
								LddReturnVal = E_NOT_OK;
								/* set Job Result as job failed*/
								/*Eep_GddJobResult = MEMIF_JOB_FAILED;*/ 
							}
						}
						else
						{   
							#if (EEP_DEV_ERROR_DETECT == STD_ON)       
							/* Report to DET */
							(void)Det_ReportError(EEP_MODULE_ID, EEP_INSTANCE_ID,EEP_ERASE_SID,EEP_E_PARAM_ADDRESS);
							#endif
							/*setting return value as E_NOT_OK*/
							LddReturnVal = E_NOT_OK;
							/* set Job Result as job failed*/
							/*Eep_GddJobResult = MEMIF_JOB_FAILED; */
						}

					}/*if(E_NOT_OK != LddReturnVal)*/
					else
					{
					/* Do Nothing */
					}
			} /*end of else*/
			/* Return the Std_ReturnType */
			return(LddReturnVal);
}



/******************************************************************************
** Function Name                : Eep_Compare
**
** Service ID                   : 0x05
**
** Description                  : function to take new Compares job for eeprom driver 
**                         
**
** Sync/Async                   : Asynchronous
**
** Re-entrancy                  : Non Reentrant
**
** Input Parameters             : EepromAddress ,Length ,DataBufferPtr
**
** Parameter Description        : EepromAddress is of unsigned 32-bit variable,DataBufferPtr is of const buffer,Length is of unsigned 32-bit variable 
**
** InOut Parameters             : None
**
** Output Parameters            : None
**
** Return parameter             : Std_ReturnType
**
** Preconditions                : None
**
** Global Variables             : Eep_GddModuleState,Eep_GddJobResult
**                         
** Functions invoked            : I2C_Read 
**
** Registers Used               : None
**
******************************************************************************/
 extern uint8_t readDataBufferPtr[1];
uint32_t Eep_Compare(Eep_AddressType EepromAddress,const uint8_t *Buffer,Eep_LengthType Length)
{
		uint16_t LddReturnVal;

		//static uint8_t addr = 0;
		uint8_t byte_cnt=0;
		uint8_t data_cnt=0;
		static  uint8_t cmp_byte;
		uint8_t databufsize = PAGESIZE;
	 
		uint8_t *buffer =readDataBufferPtr;
		LddReturnVal = E_OK;
		if(MEMIF_UNINIT == Eep_GddModuleState)
		{
			#if (EEP_DEV_ERROR_DETECT == STD_ON)	 
			/* Report to DET */
			(void)Det_ReportError(EEP_MODULE_ID, EEP_INSTANCE_ID, EEP_COMPARE_SID,EEP_E_UNINIT);
			#endif
			/* Set the Return value to not OK */
			LddReturnVal = E_NOT_OK;
		} /* if(Eep_GddModuleState == MEMIF_UNINIT) */
		else
		{
			/* Check if the module is Busy with some other request */
			if(MEMIF_BUSY == Eep_GddModuleState)
			{
				#if (EEP_DEV_ERROR_DETECT == STD_ON)
				/* Report to DET */
				(void)Det_ReportError(EEP_MODULE_ID,EEP_INSTANCE_ID,EEP_COMPARE_SID,EEP_E_BUSY);
				#endif
				/* Set the Return value to not OK */
				LddReturnVal = E_NOT_OK;

			} /* if(Eep_GddModuleState == MEMIF_BUSY) */
			/* if(Eep_GddModuleState == MEMIF_BUSY_INTERNAL) */

			else if(MEMIF_BUSY_INTERNAL == Eep_GddModuleState)
			{
			LddReturnVal = E_OK;
			}
			else
			{
			/* Do Nothing */
			}
			/* Check if NULL Pointer is passed */
			if(NULL== Buffer)
			{
				#if (EEP_DEV_ERROR_DETECT == STD_ON)
				/* Report to DET */
				(void)Det_ReportError(EEP_MODULE_ID, EEP_INSTANCE_ID, EEP_COMPARE_SID,EEP_E_PARAM_DATA);
				#endif
				/*Set the Return value to not OK */
				LddReturnVal = E_NOT_OK;
			} /* if(DataBufferPtr == NULL_PTR) */
			else
			{
			/* Do Nothing */
			}
			/* Check for Return value is E_OK */
			if(E_NOT_OK != LddReturnVal)
			{        
				if(E_OK == LddReturnVal)
				{
					/* Check if address is in range */
					if(EepromAddress <=EepTotalSize - ONE)
					{
					if((Length <=(EepTotalSize-EepromAddress))&& (Length >= ONE))
					{		
					/*Set Busy Flag for bus Busy */
					Eep_GddModuleState = MEMIF_BUSY;
					Eep_GddJobResult = MEMIF_JOB_PENDING;
					for(byte_cnt=0,data_cnt=0;byte_cnt<Length;byte_cnt+=PAGESIZE,data_cnt++)
					{
						/*if(Eep_GddJobResult == MEMIF_JOB_CANCELED)
						{
							//Eep_GddModuleState = MEMIF_IDLE;
							LddReturnVal = E_NOT_OK;
							return LddReturnVal;
						} */   
						if(Length % PAGESIZE !=0)
						{
						databufsize = Length % PAGESIZE;
						}
						if(data_cnt==(Length/PAGESIZE))
						{
							I2C_Read(I2C2,0XA0,EepromAddress,(uint8_t *)buffer,databufsize);

							for(cmp_byte=0; buffer[cmp_byte];cmp_byte++)
							{
							//delay_us(1);
							if(Buffer[cmp_byte]!=buffer[cmp_byte])
							{
							LddReturnVal = E_NOT_OK;
							return LddReturnVal;
							}
							}
						}
						else
						{
							I2C_Read(I2C2,0XA0,EepromAddress,(uint8_t *)buffer,PAGESIZE);
							for(cmp_byte=0;buffer[cmp_byte];cmp_byte++)
							{
					          //delay_us(1);
								if(Buffer[cmp_byte]!=buffer[cmp_byte])
								{
									LddReturnVal = E_NOT_OK;
									return LddReturnVal;

								}
							}	
						}
						EepromAddress = EepromAddress + PAGESIZE;
						buffer= buffer+PAGESIZE;
						Buffer=Buffer+PAGESIZE;
					}	
					return LddReturnVal;
					}
					else
					{
						#if (EEP_DEV_ERROR_DETECT == STD_ON)     
						/* Report to DET */
						(void)Det_ReportError(EEP_MODULE_ID,EEP_INSTANCE_ID,EEP_COMPARE_SID,EEP_E_PARAM_LENGTH);
						#endif
						LddReturnVal = E_NOT_OK;	
					}	
					}																	
					else
					{
						#if (EEP_DEV_ERROR_DETECT == STD_ON)         
						/* Report to DET */
						(void)Det_ReportError(EEP_MODULE_ID, EEP_INSTANCE_ID,EEP_COMPARE_SID,EEP_E_PARAM_ADDRESS);
						#endif
						LddReturnVal = E_NOT_OK;
					}
				}/*end of if(E_OK == LddReturnVal)*/
				else 
				{
				/* Do Nothing */
				}		
			}  /*end of if(E_NOT_OK != LddReturnVal)*/
		}
									return LddReturnVal;

	}

	
  
/******************************************************************************
** Function Name         : Eep_Cancel
**
** Service ID            : 0x06
**
** Description           : Cancels a running job
**                         
** Sync/Async            : Synchronous
**
** Re-entrancy           : Non Reentrant
**
** Input Parameters      : None
**
** InOut Parameters      : None
**
** Output Parameters     : None
**
** Return parameter      : None
**
** Preconditions         : None
**
** Global Variables      : Eep_GddModuleState,Eep_GddJobResult,
**                         Eep_GddCancelCmdReceive
**
** Functions invoked     : None
**
** Registers Used        : None
**
******************************************************************************/
void Eep_Cancel(void )
{
		switch(Eep_GddModuleState)
		{
			case MEMIF_BUSY_INTERNAL: 
			/* Report to DET */
			break;
			case MEMIF_IDLE:
			/* Report to DET */ 
			break;
			case MEMIF_BUSY:
			/* Invoke the driver function to Cancel the ongoing operation */
			/* Indicate that the previously ongoing job has been Cancelled */
			if(Eep_GddJobResult == MEMIF_JOB_PENDING)
			{
			Eep_GddJobResult = MEMIF_JOB_CANCELED;
			}
			/* Set the module status so that it can accept new jobs */
			Eep_GddModuleState = MEMIF_IDLE; 
			/*Setting the global flag for indicating that cancel cmd is 
			recived that is used in eep internal module handling*/
			Eep_GddCancelCmdReceive = STD_ON; 
			break;
			default:
			/* Report to DET */
			break;
		}/*End Of Switch*/
} /* end of Eep_Cancel */



/******************************************************************************
** Function Name         : Eep_GetStatus
**
** Service ID            : 0x07
**
** Description           : Returns the EEPROM status
**                         
**
** Sync/Async            : Synchronous
**
** Re-entrancy           : Reentrant
**
** Input Parameters      : None
**
** InOut Parameters      : None
**
** Output Parameters     : None
**
** Return parameter      : MemIf_StatusType
**
** Preconditions         : None
**
** Global Variables      : Eep_GddModuleState
**
** Functions invoked     : None
**
** Registers Used        : None
**
******************************************************************************/
MemIf_StatusType Eep_GetStatus (void )
  {	
		/*local variable for returning module status*/
		MemIf_StatusType LddReturnValue;
		/*assign the global state variable to the local variable */
		LddReturnValue = Eep_GddModuleState;
		return (LddReturnValue);

  }

/******************************************************************************
** Function Name            : Eep_GetVersionInfo
**
** Service ID               : 0x0a
**
** Description              : Service to get the version information of 
**                           this module
     
** Sync/Async              : Synchronous
**
** Re-entrancy             : Reentrant
**
** Input Parameters        : versioninfo 
**
** Parameter Description   : Structure Type pointer
**
** InOut Parameters        : None
**
** Output Parameters       : None
**
** Return parameter        : None
**
** Preconditions           : None
**
** Global Variables        : versioninfo
**
** Functions invoked       : None
**
** Registers Used          : None
**
******************************************************************************/
/* enabling or disabling the version info API dependepending upon the
 preconfigured MACRO */
	
void Eep_GetVersionInfo (Std_VersionInfoType *versioninfo)
{	 
	if(NULL== versioninfo)
	{
		#if (EEP_DEV_ERROR_DETECT == STD_ON) 
		/* Report to DET */
		(void)Det_ReportError(EEP_MODULE_ID, EEP_INSTANCE_ID,EEP_GETVERSIONINFO_SID,EEP_E_PARAM_POINTER);
		#endif	

	}
	else
	{
			/* Copy the vendor Id */
			// versioninfo->vendorID = (uint16_t)EEP_VENDOR_ID;
			/* Copy the module Id */
			versioninfo->moduleID = (uint16_t)EEP_MODULE_ID;
			/* Copy Software Major Version */
			versioninfo->sw_major_version = EEP_SW_MAJOR_VERSION;
			/* Copy Software Minor Version */
			versioninfo->sw_minor_version = EEP_SW_MINOR_VERSION;
			/* Copy Software Patch Version */
			versioninfo->sw_patch_version = EEP_SW_PATCH_VERSION;
	}

}


/******************************************************************************
** Function Name         : Eep_NotificationJobOperation
**
** Service ID            : NA
**
** Description           : function to send the proper notification to the 
**						             upper upon completion of the job of eeprom driver.
**
** Sync/Async            : Synchronous
**
** Re-entrancy           : Reentrant
**
** Input Parameters      : None
**
** InOut Parameters      : None
**
** Output Parameters     : None
**
** Return parameter      : None
**
** Preconditions         : None
**
** Global Variables      : Eep_GusLddErr,Eep_GddJobResult,Eep_GddModuleState
**						             Eep_JobsOP
**
** Functions invoked     : Eep_Local_JobErrorNotification,
**						             Eep_Local_JobEndNotification
**
** Registers Used        : None
**
******************************************************************************/



/******************************************************************************
** Function Name         : Eep_MainFunction
**
** Service ID            : 0x09
**
** Description           : function to complete  read/write jobs of Eep driver
**
** Sync/Async            : Synchronous
**
** Re-entrancy           : Reentrant
**
** Input Parameters      : None
**
** InOut Parameters      : None
**
** Output Parameters     : None
**
** Return parameter      : None
**
** Preconditions         : None
**
** Global Variables      : Eep_GusLddErr 
**							            
**                           
** Functions invoked     :  Eep_Write(), Eep_Read(),Eep_Erase,Eep_Compare
**
** Registers Used        : None
**
******************************************************************************/
uint8_t readDataBufferPtr[1];
//uint8_t DataBufferPtr[7]={0x65,0x23,0x34,0x45,0x56,0x67,0x78};
uint8_t a;
extern uint8_t *res=&a;
uint8_t byte_cnt;
uint8_t buf[5]={0x55,0x23,0x23,0x45,0x46};

void Eep_MainFunction(void)
{
		switch( Eep_JobsOP.jobType)
		{
			/*Curent job operation is write*/
			case EEP_WRITE_OP:
			{
				
				Eep_GusLddErr =  Eep_Write(0X10,res,1);	
				break;
			}
			/*Curent job operation is read*/
			case EEP_READ_OP:
			{
				Eep_GusLddErr = 	Eep_Read(0X10,readDataBufferPtr,1);
				break;
			}
			/*Curent job operation is read*/
			case EEP_ERASE_OP:
			{
				Eep_GusLddErr = Eep_Erase(0x10,5);
				break;
			}
			case  EEP_COMPARE_OP:
			{
				Eep_GusLddErr=Eep_Compare(0X10,buf,5);
				break;
			}
			/*Curent job operation is job notification*/
			default:
			{
			}
		}
}

