/************************************************************
 * PROJECT: ESS_IP_UDS_Implementation_Project
 *
 * FILE NAME : Uds.h
 *
 * TARGET PLATFORM : STM32f107
 *
 * BUILD ENVIRONMENT : RealView MDK-ARM  Version: 4.20 
 *
 * DISCRIPTION : Header file for implementation of Unified Diagnostic Services 
 *
 * VERSION : v1.0
 *
 * PLATFORM DEPENDANT [yes/no] : no
 *
 * TO BE CHANGED BY THE USER [yes/no] : no
 *	
 * CREATED BY: Chirag Juneja
 *
 * LICENSE: ARIPL SOFTWARE LICENSE
 ************************************************************/
 
#ifndef _Usd_h_
#define _Usd_h_

/*---------------------------------------- Includes ----------------------------------------*/

#include "stm32f4xx.h"
//#include "SysTick/systick.h" 
#include "Uds_type.h"
#include "DEL.h"
#include "Cantp.h"
#include "Can.h"
#include "Rsa.h"
#include "Tim_api.h"
#include "Tim_Cfg.h"

/*------------------------------ Function Declarations ------------------------------*/

void UDS_SessionTimerInit(void);
void UDS_SessionTimerUpdate(void);
void UDS_SessionInit(uint8_t newsession);
void UDS_SessionControlHandler(uint8_t* Uds_ServiceRequestBuffer);
void UDS_EcuResetHandler(uint8_t* Uds_ServiceRequestBuffer);
void UDS_ClearDiagnosticInfoHandler(uint8_t* Uds_ServiceRequestBuffer);
void UDS_ReadDTCInfoHandler(uint8_t* Uds_ServiceRequestBuffer);
void UDS_ReadDataByIdHandler(uint8_t* Uds_ServiceRequestBuffer);
void UDS_ReadMemoryByAddressHandler(uint8_t* Uds_ServiceRequestBuffer);
void UDS_SecurityAccessHandler(uint8_t* Uds_ServiceRequestBuffer);
void UDS_CommunicationControlHandler(uint8_t* Uds_ServiceRequestBuffer);
void UDS_ReadDataByPeriodicIDHandler(uint8_t* Uds_ServiceRequestBuffer);
void UDS_DynamicallyDefinedDataIDHandler(uint8_t* Uds_ServiceRequestBuffer);
void UDS_WriteDataByIDHandler(uint8_t* Uds_ServiceRequestBuffer);
void UDS_WriteMemoryByAddressHandler(uint8_t* Uds_ServiceRequestBuffer);
void UDS_TesterPresentHandler(uint8_t* Uds_ServiceRequestBuffer);
void AccessTimingParameterHandler(uint8_t* Uds_ServiceRequestBuffer);
void ControlDTCSettingsHandler(uint8_t* Uds_ServiceRequestBuffer);
void ResponseOnEventHandler(uint8_t* Uds_ServiceRequestBuffer);
void UDS_ServiceRequest(uint8_t* Uds_ServiceRequestBuffer);
void UDS_TxNegativeResponseMessage(uint8_t service, uint8_t NRC);
void UDS_Routine_control(uint8_t* Uds_ServiceRequestBuffer);
void UDS_Request_Download(uint8_t* Uds_ServiceRequestBuffer,uint8_t* up_buff);
void UDS_Request_Upload(uint8_t* Uds_ServiceRequestBuffer);
void UDS_TransferData(uint8_t* Uds_ServiceRequestBuffer);
void UDS_RequestTransferExit(uint8_t* Uds_ServiceRequestBuffer);
void UDS_Init(void);

#endif
