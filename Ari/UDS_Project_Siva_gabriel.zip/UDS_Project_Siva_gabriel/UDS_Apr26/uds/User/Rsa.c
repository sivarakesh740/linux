/************************************************************
 * PROJECT: ESS_IP_UDS_Implementation_Project
 *
 * FILE NAME : rsa.c
 *
 * TARGET PLATFORM : STM32f107
 *
 * BUILD ENVIRONMENT : RealView MDK-ARM  Version: 4.20
 *
 * DISCRIPTION : To implement Encryption and Decryption on Data
 *
 * VERSION : v1.0
 *
 * PLATFORM DEPENDANT [yes/no] : no
 *
 * TO BE CHANGED BY THE USER [yes/no] : no
 *
 * CREATED BY : Sumanth Boppana
 *
 * MODIFIED BY : Chirag Juneja 	
 *
 * LICENSE: ARIPL SOFTWARE LICENSE
 ************************************************************/

/*----------------------------------------  Includes ----------------------------------------*/  
#include "Rsa.h"

#define PRIME1 53
#define	PRIME2 47
#define SHIFT_BYTE 8
#define FIRSTFACTOR 2
#define KEY_PAIR_REMAINDER 1
#define D_KEY_MIN 2

/*----------------------------------------  Global Variables ----------------------------------------*/
static uint16_t primeProduct, E_key, D_key;

/**************************************************************************
 * Function : RSA_encryptData
 * Description : Encrypt the given data (used in CAPL)
 * Parameters : Data
 * Parameter Description : Data to be encrypted
 * Return Type : uint32_t
 * Return Parameter : E_data
 * Global Variables Used : E_key, primeProduct
 * Function Invoked : None
 **************************************************************************/

uint32_t RSA_encryptData(uint32_t Data){
	uint32_t counter;
	uint32_t E_data;
	E_data = 1;
	for(counter = 0; counter < E_key; counter++){
		E_data = E_data*Data;
		E_data = E_data % primeProduct;
	}
	return E_data;
}


/**************************************************************************
 * Function : RSA_decryptData
 * Description : Dencrypt the Encrypted data
 * Parameters : E_data
 * Parameter Description : Encrypted data
 * Return Type : uint32_t
 * Return Parameter : D_data 
 * Global Variables Used : D_Key, primeProduct
 * Function Invoked : None
 **************************************************************************/
uint32_t RSA_decryptData(uint32_t E_data){
	
	uint32_t counter;
	uint32_t D_data;	
	D_data = 1;
	for(counter = 0; counter < D_key; counter++){
		D_data = D_data * E_data;
		D_data = D_data % primeProduct;
	}
	return D_data;
}

/**************************************************************************
 * Function : RSA_generateKeyPair
 * Description : genterate public and private keys
 * Parameters : None
 * Parameter Description : None
 * Return Type : uint32_t
 * Return Parameter : publicKey
 * Global Variables Used : E_key, D_Key, primeProduct
 * Function Invoked : prime, decryption_key
 **************************************************************************/
uint32_t RSA_generateKeyPair(){
	
	uint32_t counter,phi,publicKey;

	primeProduct = PRIME1*PRIME2;
	phi = (PRIME1-1)*(PRIME2-1);

	for(counter = FIRSTFACTOR; counter < phi; counter++){
		
		if(phi % counter == 0)continue; // e and phi should be co-primes
		if(primeProduct % counter == 0)continue;// e and n should be co-primes

		E_key = counter;		
		D_key = D_KEY_MIN;

		while((D_key*E_key)%phi != KEY_PAIR_REMAINDER)D_key++;
		break;
	}
	publicKey = (primeProduct<<SHIFT_BYTE<<SHIFT_BYTE) + E_key;
	return publicKey;
}
