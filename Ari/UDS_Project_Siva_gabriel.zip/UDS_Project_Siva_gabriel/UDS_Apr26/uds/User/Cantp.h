#ifndef _cantp_h_
#define _cantp_h_
#include "Uds.h"
#include "stm32f4xx.h"
#include "Uds_type.h"


/*------------------------------ Macros ------------------------------*/
#define SINGLE_FRAME 0x00
#define FIRST_FRAME  0x10
#define FLOW_CONTROL_FRAME 0x30
#define CONSECUTIVE_FRAME  0x20

/*------------------------------ Function Declarations ------------------------------*/
void CanTp_Rx(CanRxMsg* RxMessage);
void CanTp_Tx(uint8_t* Uds_ResponseBufferPtr);
void CanTp_singleFrameHandler(CanRxMsg* RxMessage);
void CanTp_controlFlowFrameHandler(CanRxMsg* RxMessagePtr);
void CanTp_firstFrameRxHandler(CanRxMsg* RxMessagePtr);
void CanTp_consecutiveFrameHandler(CanRxMsg* RxMessagePtr);

void CanTp_multiFrameTxHandler(uint8_t* ResponseBufferPtr);
void CanTp_TxControlFlow(void);
#endif
