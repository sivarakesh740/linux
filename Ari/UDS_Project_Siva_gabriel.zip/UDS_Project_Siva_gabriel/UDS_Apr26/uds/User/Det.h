/*===========================================================================*/
/* Project      =Gen 3 AUTOSAR Project                    */
/* Module       = Det.h                                                      */
/* Version      = V1.0.0                                                     */
/*===========================================================================*/

/******************************************************************************
 **                      Revision History                                    **
 ******************************************************************************
 ** Revision  Date	          By                 Description                 **
 ******************************************************************************													 
 ** 1.0.0     20-July-18     M Kumar Ydav       Initial version             **
 *****************************************************************************/

#ifndef DET_H
#define DET_H

/******************************************************************************
**                      Include Section                                      **
******************************************************************************/
/*
 * This header file includes all the standard data types, platform dependent
 * header file and common return types
 */


/******************************************************************************
**                      Version Information                                  **
******************************************************************************/
/* AUTOSAR Specification Version Information */

/******************************************************************************
**                                Macros                                     **
******************************************************************************/
#define DET_ARRAY_SIZE                    10
#define Det_GucReportCount                10

/******************************************************************************
**                      Global Data Types                                    **
******************************************************************************/
/*
 * Defining the structure to store the parameters of Det Report Error function
 */
typedef struct
{  /* It will store the ModuleId of the reporting module */
   uint16_t ModuleId;

   /* It will store the index based InstanceId of the reporting module */
   uint8_t InstanceId;

   /* It will store the ApiId of the reporting function */
   uint8_t ApiId;

   /* It will store the ErrorId of the reporting error */
   uint8_t ErrorId;
}tDet_Error;


/******************************************************************************
**                      Function Prototypes                                  **
******************************************************************************/

/*extern Std_ReturnType Det_ReportError(uint16 ModuleId, uint8 InstanceId,
  uint8 ApiId, uint8 ErrorId);*/



/******************************************************************************
**                      End of File                                          **
******************************************************************************/
#endif 
