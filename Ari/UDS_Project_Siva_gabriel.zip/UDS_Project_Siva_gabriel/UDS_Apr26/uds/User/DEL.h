/************************************************************
 * PROJECT: ESS_IP_UDS_Implementation_Project
 *
 * FILE NAME : DEL.h
 *
 * TARGET PLATFORM : STM32f107
 *
 * BUILD ENVIRONMENT : RealView MDK-ARM  Version: 4.20 
 *
 * DISCRIPTION : Header file for Data Extraction Layer used in UDS
 *
 * VERSION : v1.0
 *
 * PLATFORM DEPENDANT [yes/no] : no
 *
 * TO BE CHANGED BY THE USER [yes/no] : no
 *	
 * CREATED BY: Chirag Juneja
 *
 * LICENSE: ARIPL SOFTWARE LICENSE
 ************************************************************/

#ifndef DEL_h
#define DEL_h

/*---------------------------------------- Includes ----------------------------------------*/

#include "stm32f4xx.h"
#include "Uds_type.h"
//#include "Eep.h"

/*---------------------------------------- Macros ----------------------------------------*/

#define ECU_SERIAL_NUMBER_DATA_ID 0xF18Cu
#define ENGINE_PARAMETERS_DATA_ID 0x0110u
#define ECU_SOFTWARE_VERSION_DATA_ID 0xF188u
#define ENGINE_INJECTION_DATA_ID 0x0589u

/*---------------------------------------- Typedef ----------------------------------------*/

/**************************************************************************
 * DataType : IdentifierMap
 * Description : Holds the parameters used to fetch data corresponding to identifer
 * Elements Type: uint16_t, uint8_t
 * Elements Discription: identifier, size of the data, memoryAddress of the data
 **************************************************************************/
typedef struct {
	uint16_t id;
	uint8_t size;
	uint8_t address;
}IdentifierMap;

void DEL_identifierInit(void);
uint8_t* DEL_fetchIdentifierData(uint8_t address, uint8_t size, uint8_t* fetchPointer);
uint8_t* DEL_ReadDataById(uint16_t DataId, uint8_t* fetchPointer);
uint8_t DEL_setIdentifierData(uint8_t address, uint8_t size, uint8_t* dataBufferPointer);
uint8_t DEL_WriteDataById(uint16_t dataId, uint8_t dataLength, uint8_t* dataPointer);
void DEL_MemoryInit(void);
void DEL_ReadMemoryByAddress(uint16_t address,uint8_t size,uint8_t* fetchPointer);
uint8_t DEL_WriteMemoryByAddress(uint16_t address, uint8_t size, uint8_t* dataPointer);


#endif
