/************************************************************
 * PROJECT: ESS_IP_UDS_Implementation_Project
 *
 * FILE NAME : rsa.h
 *
 * TARGET PLATFORM : STM32f107
 *
 * BUILD ENVIRONMENT : RealView MDK-ARM  Version: 4.20
 *
 * DISCRIPTION : Header file for RSA algorithm
 *
 * VERSION : v1.0
 *
 * PLATFORM DEPENDANT [yes/no] : no
 *
 * TO BE CHANGED BY THE USER [yes/no] : no
 *
 * CREATED BY : Sumanth Boppana
 *
 * MODIFIED BY : Chirag Juneja
 *
 * LICENSE: ARIPL SOFTWARE LICENSE
 ************************************************************/
 

#ifndef _Rsa_h_
#define _Rsa_h_

/*----------------------------------------  Includes ----------------------------------------*/ 

#include "Std_Types.h"

/*----------------------------------------  Function Declarations ----------------------------------------*/ 

uint32_t RSA_encryptData(uint32_t Data);
uint32_t RSA_decryptData(uint32_t E_data);
uint32_t RSA_generateKeyPair(void);

#endif
