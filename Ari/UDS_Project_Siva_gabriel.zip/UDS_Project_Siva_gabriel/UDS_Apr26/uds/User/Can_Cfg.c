
#include "Can_Cfg.h"


Can_ConfigType CntrConfig1 = {


	CAN_PROCESS_TYPE_POLLING,
	0,
	CAN_CTRL_1,
	CAN_PROCESS_TYPE_INTERRUPT,
	CAN_PROCESS_TYPE_POLLING,
	CAN_PROCESS_TYPE_POLLING,
	CAN_PROCESS_TYPE_POLLING,
	0,
	0,
	0,
	1000,
	0,
	13,
	5,
	0,
	0

};


Can_ConfigType CntrConfig2 = {


	CAN_PROCESS_TYPE_POLLING,
	0,
	CAN_CTRL_2,
	CAN_PROCESS_TYPE_POLLING,
	CAN_PROCESS_TYPE_POLLING,
	CAN_PROCESS_TYPE_POLLING,
	CAN_PROCESS_TYPE_POLLING,
	0,
	0,
	0,
	1000,
	0,
	13,
	5,
	0,
	0

};
char str[10]="AA";
Can_PduType Can_buf ={
100,
	2,
	str
//	0
};
