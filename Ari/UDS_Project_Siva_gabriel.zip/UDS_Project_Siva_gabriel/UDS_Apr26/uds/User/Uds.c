/************************************************************
 * PROJECT: ESS_IP_UDS_Implementation_Project
 *
 * FILE NAME : Uds.c
 *
 * TARGET PLATFORM : STM32f107
 *
 * BUILD ENVIRONMENT : RealView MDK-ARM  Version: 4.20 
 *
 * DISCRIPTION : To implement Universal Diagnostic Services 
 *
 * VERSION : v1.0
 *
 * PLATFORM DEPENDANT [yes/no] : no
 *
 * TO BE CHANGED BY THE USER [yes/no] : no
 *	
 * CREATED BY: Chirag Juneja
 *
 * LICENSE: ARIPL SOFTWARE LICENSE
 ************************************************************/


/*---------------------------------------- Includes ----------------------------------------*/

#include "Uds.h"
#include <stdio.h> 

/*---------------------------------------- Global Variables ----------------------------------------*/
uint8_t Uds_ResponseBuffer[64];
static uint8_t* Uds_ResponseBufferPtr = Uds_ResponseBuffer;
static volatile Uds_DiagnosticSession Session;
static volatile uint8_t S3_ServerTimer;
static volatile uint8_t Uds_SessionTimer=0;
static uint32_t Uds_TimeFactor;
static volatile uint8_t Uds_SecurityStatus;
static uint32_t Uds_UnlockCode = 65;
uint8_t del=0xFF;
static uint8_t up_buff[10];
static uint8_t req_downlaod=0;
static uint8_t req_upload=0;
static uint8_t size=0;
static uint8_t transferdone=0;

/**************************************************************************
 * Function : UDS_SessionTimerInit
 * Description : Initiate the Session Timer
 * Parameters : None
 * Parameter Description : None
 * Return Type : void 
 * Return Parameter : None
 * Global Variables Used : Uds_SessionTimer, Uds_TimeFactor, S3_ServerTimer
 * Function Invoked : RCC_GetClocksFreq, SysTick_CLKSourceConfig, SysTick_ITConfig, SysTick_SetReload,SysTick_CounterCmd
 **************************************************************************/
void UDS_SessionTimerInit(){
	TIM_Init(TIM_7);	
	
	// Start the Timer
	/* initialize the counter *//*
	RCC_ClocksTypeDef RCC_ClocksStatus;
	RCC_GetClocksFreq(&RCC_ClocksStatus);
  Uds_TimeFactor = RCC_ClocksStatus.HCLK_Frequency / 8000; 
	SysTick_CLKSourceConfig(SysTick_CLKSource_HCLK_Div8);
	SysTick_ITConfig(ENABLE);*/
	
	/* set session timer *//*
	SysTick_SetReload(Uds_TimeFactor*1000);			// set timer for 1 second
	SysTick_CounterCmd(SysTick_Counter_Clear);		// clear current count
	SysTick_CounterCmd(SysTick_Counter_Enable);		// start the timer
	*/
	TIM_counterms(TIM_7,1000);
	S3_ServerTimer=TRUE;		// session timer is active
	Uds_SessionTimer=0;			// reset session timer 
}

/**************************************************************************
 * Function : UDS_SessionTimerUpdate
 * Description : Update the Session Timer
 * Parameters : None
 * Parameter Description : None
 * Return Type : void 
 * Return Parameter : None
 * Global Variables Used : Uds_SessionTimer, Uds_TimeFactor, S3_ServerTimer
 * Function Invoked : SysTick_ITConfig,SysTick_SetReload,SysTick_CounterCmd,CanTp_Tx,UDS_SessionInit
 **************************************************************************/
void UDS_SessionTimerUpdate(){

if(S3_ServerTimer==TRUE){	
	if(Uds_SessionTimer==4){
		//SysTick_ITConfig(DISABLE);
		Uds_SessionTimer=0;
		S3_ServerTimer=FALSE;
		Uds_ResponseBufferPtr[0] = 0x03;
		Uds_ResponseBufferPtr[1] = 0x10;
		Uds_ResponseBufferPtr[2] = Session.currentSession;
		Uds_ResponseBufferPtr[3] = 0xFF; 
		CanTp_Tx(Uds_ResponseBufferPtr);	
		UDS_SessionInit(DEFAULT_SESSION);
		TIM_Cmd(TIM_7->TIM_Type, DISABLE);
	}
	else{
/*		SysTick_SetReload(Uds_TimeFactor*1000);
		SysTick_CounterCmd(SysTick_Counter_Clear);
		SysTick_CounterCmd(SysTick_Counter_Enable);	*/
		Uds_SessionTimer++;
		
	}
}
}
/**************************************************************************
 * Function : TIM3_IRQHandler
 * Description : SysTick Interrupt Handler
 * Parameters : None
 * Parameter Description : None
 * Return Type : void 
 * Return Parameter : None
 * Global Variables Used : 
 * Function Invoked : UDS_SessionTimerUpdate
 **************************************************************************/
void TIM7_IRQHandler(void){
	TIM_3->ITFlag = SET;
	TIM_ClearITPendingBit(TIM7, TIM_IT_Update);
	UDS_SessionTimerUpdate();
}

/**************************************************************************
 * Function : UDS_SessionInit
 * Description : Initialize Diagnostic Session
 * Parameters : newSession
 * Parameter Description : Session to be initialized  
 * Return Type : void 
 * Return Parameter : None
 * Global Variables Used : Session, Uds_SessionTimer,S3_ServerTimer,Uds_SecurityStatus
 * Function Invoked : UDS_SessionTimerInit
 **************************************************************************/

void UDS_SessionInit(uint8_t newSession){
	
	switch(newSession){
		
			case DEFAULT_SESSION : 
				Session.currentSession = newSession;
				Session.diagnosticSessionControl = ENABLE;
				Session.ecuReset = DISABLE;
				Session.securityAccess = DISABLE;
				Session.communicationControl = DISABLE;
				Session.testerPreset = ENABLE;
				Session.accessTimingParameters = DISABLE;
				Session.controlDTCSettings = DISABLE;
				Session.responseOnEvent = DISABLE; 			// implemenation specific
				Session.readDataByIdentifier = DISABLE; // requires security access
				Session.readMemoryByAddress = DISABLE; 	// requires secutiry access 
				Session.readDataByIdentifierPeriodic = DISABLE;
				Session.dynamicallyDefineDataIdentifier = ENABLE;
				Session.writeDataByIdentifier = DISABLE;
				Session.writeMemoryByAddress = DISABLE;
				Session.clearDiagnosticInformation = ENABLE;
				Session.readDTCInformation = ENABLE;
				Uds_SessionTimer = 0;
				S3_ServerTimer = FALSE;
				Uds_SecurityStatus = LOCKED;
				break;
			
			case EXTENDED_DIAGNOSTIC_SESSION :
				Session.currentSession = newSession;
				Session.diagnosticSessionControl = ENABLE;
				Session.ecuReset = ENABLE;
				Session.securityAccess = ENABLE;
				Session.communicationControl = ENABLE;
				Session.testerPreset = ENABLE;
				Session.accessTimingParameters = ENABLE;
				Session.controlDTCSettings = ENABLE;
				Session.responseOnEvent = ENABLE; 			// implemenation specific
				Session.readDataByIdentifier = ENABLE; // requires security access
				Session.readMemoryByAddress = ENABLE; 	// requires secutiry access 
				Session.readDataByIdentifierPeriodic = ENABLE;
				Session.dynamicallyDefineDataIdentifier = ENABLE;
				Session.writeDataByIdentifier = ENABLE;
				Session.writeMemoryByAddress = ENABLE;
				Session.clearDiagnosticInformation = ENABLE;
				Session.readDTCInformation = ENABLE;
				Uds_SecurityStatus = LOCKED;
				UDS_SessionTimerInit();
				break;

			case PROGRAMMING_SESSION :
				Session.currentSession = newSession;
				Session.diagnosticSessionControl = ENABLE;
				Session.ecuReset = ENABLE;
				Session.securityAccess = ENABLE;
				Session.communicationControl = DISABLE;
				Session.testerPreset = ENABLE;
				Session.accessTimingParameters = DISABLE;
				Session.controlDTCSettings = ENABLE;
				Session.responseOnEvent = ENABLE; 			// implemenation specific
				Session.readDataByIdentifier = ENABLE; // requires security access
				Session.readMemoryByAddress = ENABLE; 	// requires secutiry access 
				Session.readDataByIdentifierPeriodic = ENABLE;
				Session.dynamicallyDefineDataIdentifier = ENABLE;
				Session.writeDataByIdentifier = ENABLE;
				Session.writeMemoryByAddress = ENABLE;
				Session.clearDiagnosticInformation = ENABLE;
				Session.readDTCInformation = ENABLE;
				Uds_SecurityStatus = LOCKED;
				UDS_SessionTimerInit();
				break;

			case SAFTEY_SYSTEM_DIAGNOSTIC_SESSION :
				Session.currentSession = newSession;
				Session.diagnosticSessionControl = ENABLE;
				Session.ecuReset = ENABLE;
				Session.securityAccess = ENABLE;
				Session.communicationControl = ENABLE;
				Session.testerPreset = ENABLE;
				Session.accessTimingParameters = ENABLE;
				Session.controlDTCSettings = ENABLE;
				Session.responseOnEvent = ENABLE; 			// implemenation specific
				Session.readDataByIdentifier = ENABLE; // requires security access
				Session.readMemoryByAddress = ENABLE; 	// requires secutiry access 
				Session.readDataByIdentifierPeriodic = ENABLE;
				Session.dynamicallyDefineDataIdentifier = ENABLE;
				Session.writeDataByIdentifier = ENABLE;
				Session.writeMemoryByAddress = ENABLE;
				Session.clearDiagnosticInformation = ENABLE;
				Session.readDTCInformation = ENABLE;
				Uds_SecurityStatus = LOCKED;
				UDS_SessionTimerInit();
				break;
			
			default:
				Session.currentSession = newSession;
				Session.diagnosticSessionControl = ENABLE;
				Session.ecuReset = ENABLE;
				Session.securityAccess = DISABLE;
				Session.communicationControl = DISABLE;
				Session.testerPreset = ENABLE;
				Session.accessTimingParameters = DISABLE;
				Session.controlDTCSettings = DISABLE;
				Session.responseOnEvent = DISABLE; 			// implemenation specific
				Session.readDataByIdentifier = DISABLE; // requires security access
				Session.readMemoryByAddress = DISABLE; 	// requires secutiry access 
				Session.readDataByIdentifierPeriodic = DISABLE;
				Session.dynamicallyDefineDataIdentifier = ENABLE;
				Session.writeDataByIdentifier = DISABLE;
				Session.writeMemoryByAddress = DISABLE;
				Session.clearDiagnosticInformation = ENABLE;
				Session.readDTCInformation = ENABLE;
				//SysTick_ITConfig(DISABLE);
				Uds_SessionTimer=0;
				S3_ServerTimer=FALSE;
				Uds_SecurityStatus = LOCKED;
				break;
		}
}
/**************************************************************************
 * Function : UDS_SessionControlHandler 
 * Description : Diagnostic Session Control Service Handler 
 * Parameters : Uds_ServiceRequestBuffer 
 * Parameter Description : pointer to request message buffer  
 * Return Type : void 
 * Return Parameter : None 
 * Global Variables Used : None
 * Function Invoked : UDS_SessionInit, UDS_TxNegativeResponseMessage, CanTp_Tx 
 **************************************************************************/
void UDS_SessionControlHandler(uint8_t* Uds_ServiceRequestBuffer)
{
	uint8_t messageLength = Uds_ServiceRequestBuffer[0];
	uint8_t SessionType = Uds_ServiceRequestBuffer[2];
	if(messageLength==2){
		switch(SessionType){
			
			case DEFAULT_SESSION : 
				UDS_SessionInit(SessionType);
				Uds_ResponseBufferPtr[0] = 0x02;
				Uds_ResponseBufferPtr[1] = UDS_SID_DIAGNOSTIC_SESSION_CONTROL+UDS_POSITIVE_RESPONSE_MASK;
				Uds_ResponseBufferPtr[2] = SessionType;
				CanTp_Tx(Uds_ResponseBufferPtr);
				break;
			
			case EXTENDED_DIAGNOSTIC_SESSION :
				UDS_SessionInit(SessionType);
				Uds_ResponseBufferPtr[0] = 0x02;
				Uds_ResponseBufferPtr[1] = UDS_SID_DIAGNOSTIC_SESSION_CONTROL+UDS_POSITIVE_RESPONSE_MASK;
				Uds_ResponseBufferPtr[2] = SessionType;
				CanTp_Tx(Uds_ResponseBufferPtr);
				break;

			case PROGRAMMING_SESSION :
				UDS_SessionInit(SessionType);
				Uds_ResponseBufferPtr[0] = 0x02;
				Uds_ResponseBufferPtr[1] = UDS_SID_DIAGNOSTIC_SESSION_CONTROL+UDS_POSITIVE_RESPONSE_MASK;
				Uds_ResponseBufferPtr[2] = SessionType;
				CanTp_Tx(Uds_ResponseBufferPtr);
				break;

			case SAFTEY_SYSTEM_DIAGNOSTIC_SESSION :
				UDS_SessionInit(SessionType);
				Uds_ResponseBufferPtr[0] = 0x02;
				Uds_ResponseBufferPtr[1] = UDS_SID_DIAGNOSTIC_SESSION_CONTROL+UDS_POSITIVE_RESPONSE_MASK;
				Uds_ResponseBufferPtr[2] = SessionType;
				CanTp_Tx(Uds_ResponseBufferPtr);
				break;
			
			default:
				UDS_TxNegativeResponseMessage(UDS_SID_DIAGNOSTIC_SESSION_CONTROL, NRC_SUB_FUNCTION_NOT_SUPPORTED);	
				break;
		}
	}else UDS_TxNegativeResponseMessage(UDS_SID_DIAGNOSTIC_SESSION_CONTROL, NRC_INVALID_FORMAT);	
}

/**************************************************************************
 * Function : UDS_EcuResetHandler
 * Description : ECU Reset Service Handler
 * Parameters : Uds_ServiceRequestBuffer
 * Parameter Description : pointer to request message buffer  
 * Return Type : void 
 * Return Parameter : None 
 * Global Variables Used : Uds_SecurityStatus, Session.ecuReset
 * Function Invoked : UDS_TxNegativeResponseMessage, CanTp_Tx, NVIC_SystemReset, delay_init, delay_ms 
 **************************************************************************/

void UDS_EcuResetHandler(uint8_t* Uds_ServiceRequestBuffer){
	
	uint8_t messageLength = Uds_ServiceRequestBuffer[0];
	uint8_t ResetType = Uds_ServiceRequestBuffer[2];
	
	if(messageLength==2){
		if(Session.ecuReset){
		
			if(Uds_SecurityStatus){
		
				switch(ResetType){
	
					case HARD_RESET :	
						Uds_ResponseBufferPtr[0] = 0x03;
						Uds_ResponseBufferPtr[1] = UDS_SID_ECU_RESET+UDS_POSITIVE_RESPONSE_MASK;
						Uds_ResponseBufferPtr[2] = ResetType;
						Uds_ResponseBufferPtr[3] = ECU_POWER_DOWN_TIME;
						CanTp_Tx(Uds_ResponseBufferPtr);
						TIM_Init(TIM_5);
						TIM_delayms(TIM_5,1);
						NVIC_SystemReset();
						break;
			
					default : 
						UDS_TxNegativeResponseMessage(UDS_SID_ECU_RESET, NRC_SUB_FUNCTION_NOT_SUPPORTED);	
						break;
				}
			}else UDS_TxNegativeResponseMessage(UDS_SID_ECU_RESET, NRC_SECURITY_ACCESS_DENIED);
		}else UDS_TxNegativeResponseMessage(UDS_SID_ECU_RESET, NRC_SERVICE_NOT_SUPPORTED);
	}else UDS_TxNegativeResponseMessage(UDS_SID_ECU_RESET, NRC_INVALID_FORMAT);
}


// *******************  UDS   clear   DTC  ************* 

void UDS_ClearDiagnosticInfoHandler(uint8_t* Uds_ServiceRequestBuffer)
{
	uint8_t caseno=0;	
	uint8_t messageLength = Uds_ServiceRequestBuffer[0];
	uint8_t clear = Uds_ServiceRequestBuffer[2];
	
	if(messageLength==3)
		{
		if(Session.clearDiagnosticInformation)
			{
			if(!del)
				{
            //caseno++; 

        switch(caseno)
					{

					case  UDS_SID_CLEAR_DIAGNOSTIC_INFO :
               		Uds_ResponseBufferPtr[0] = 0x01;
                	Uds_ResponseBufferPtr[1] = UDS_SID_CLEAR_DIAGNOSTIC_INFO+UDS_POSITIVE_RESPONSE_MASK;
		            //  Uds_ResponseBufferPtr[2] = UDS_SID_CLEAR_DIAGNOSTIC_INFO;
									CanTp_Tx(Uds_ResponseBufferPtr);
                break;		
				          
			      }	
					//default : UDS_TxNegativeResponseMessage(UDS_SID_CLEAR_DIAGNOSTIC_INFO, NRC_REQUEST_OUT_OF_RANGE); break;
			 }
			else UDS_TxNegativeResponseMessage(UDS_SID_CLEAR_DIAGNOSTIC_INFO, NRC_REQUEST_OUT_OF_RANGE);
		}else UDS_TxNegativeResponseMessage(UDS_SID_CLEAR_DIAGNOSTIC_INFO, NRC_SERVICE_NOT_SUPPORTED);
	}else UDS_TxNegativeResponseMessage(UDS_SID_CLEAR_DIAGNOSTIC_INFO, NRC_INVALID_FORMAT);					
}


// ************  READ UDS DTC    **************

void UDS_ReadDTCInfoHandler(uint8_t* Uds_ServiceRequestBuffer)
{
    uint8_t *RecordData;	
  	uint8_t messageLength = Uds_ServiceRequestBuffer[0];
		uint8_t subfun = Uds_ServiceRequestBuffer[2];
	  //uint16_t RecordId = (Uds_ServiceRequestBuffer[2]<<8)+Uds_ServiceRequestBuffer[3];  ;

	if(messageLength==3)
		{
			if(subfun == 0x01)
			{
				//if(RecordData != null)
					//{
						switch(subfun)
							{
			   case NODTC_STATUS :
						Uds_ResponseBufferPtr[0] = 0x03;
						Uds_ResponseBufferPtr[1] = UDS_SID_READ_DTC_INFO + UDS_POSITIVE_RESPONSE_MASK;
						Uds_ResponseBufferPtr[2] = subfun;
				    Uds_ResponseBufferPtr[3] = 0x00;
						CanTp_Tx(Uds_ResponseBufferPtr);
						break;
			
			    	}
				//}
			}else UDS_TxNegativeResponseMessage(UDS_SID_READ_DTC_INFO, NRC_SUB_FUNCTION_NOT_SUPPORTED);
	}else UDS_TxNegativeResponseMessage(UDS_SID_READ_DTC_INFO, NRC_INVALID_FORMAT);

}

/**************************************************************************
 * Function : UDS_ReadDataById
 * Description : Read Data By Id Service Handler
 * Parameters : Uds_ServiceRequestBuffer
 * Parameter Description : pointer to request message buffer  
 * Return Type : void 
 * Return Parameter : None 
 * Global Variables Used : Uds_SecurityStatus, Session.readDataByIdentifier
 * Function Invoked : UDS_TxNegativeResponseMessage, CanTp_Tx, 
 **************************************************************************/

void UDS_ReadDataById(uint8_t* Uds_ServiceRequestBuffer){
	uint8_t *RecordData;	
	uint8_t messageLength = Uds_ServiceRequestBuffer[0];
	uint16_t counter;
	uint16_t RecordId = (Uds_ServiceRequestBuffer[2]<<8)+Uds_ServiceRequestBuffer[3];  ;

	if(messageLength==3){
		if(Session.readDataByIdentifier){
			if(Uds_SecurityStatus){
				RecordData = DEL_ReadDataById(RecordId, RecordData);
				if(RecordData != null){
				
					Uds_ResponseBufferPtr[0] = RecordData[0]+0x03;
					Uds_ResponseBufferPtr[1] = UDS_SID_READ_DATA_BY_ID + UDS_POSITIVE_RESPONSE_MASK;
					Uds_ResponseBufferPtr[2] = RecordId >> 8;
					Uds_ResponseBufferPtr[3] = RecordId & 0xFF;
					
					for(counter=0;counter<RecordData[0];counter++)Uds_ResponseBufferPtr[4+counter]=RecordData[counter+1];
					CanTp_Tx(Uds_ResponseBufferPtr);
				
				} else UDS_TxNegativeResponseMessage(UDS_SID_READ_DATA_BY_ID, NRC_REQUEST_OUT_OF_RANGE);
			}else UDS_TxNegativeResponseMessage(UDS_SID_READ_DATA_BY_ID, NRC_SECURITY_ACCESS_DENIED);
		}else UDS_TxNegativeResponseMessage(UDS_SID_READ_DATA_BY_ID, NRC_SERVICE_NOT_SUPPORTED);
	}else UDS_TxNegativeResponseMessage(UDS_SID_READ_DATA_BY_ID, NRC_INVALID_FORMAT);
}

/**************************************************************************
 * Function : UDS_ReadMemoryByAddressHandler
 * Description : Read Memory by Address Service Handler
 * Parameters : Uds_ServiceRequestBuffer
 * Parameter Description : pointer to request message buffer  
 * Return Type : void 
 * Return Parameter : None 
 * Global Variables Used : Uds_SecurityStatus, Session.readDataByIdentifier
 * Function Invoked : UDS_TxNegativeResponseMessage, CanTp_Tx, 
 **************************************************************************/

void UDS_ReadMemoryByAddressHandler(uint8_t* Uds_ServiceRequestBuffer){
	uint8_t messageLength = Uds_ServiceRequestBuffer[0];
	uint16_t counter;
	uint16_t address;
	uint8_t addressLength = Uds_ServiceRequestBuffer[2] & 0x0F;
	uint8_t dataSizeLength= Uds_ServiceRequestBuffer[2] >> 4;
	uint8_t *fetchPointer;
	uint8_t fetchBuffer[32]={0};
	uint8_t size = Uds_ServiceRequestBuffer[5];
	fetchPointer=fetchBuffer;
	
	if(messageLength == 5){
		if(Session.readMemoryByAddress){
			if(Uds_SecurityStatus){
				if((addressLength == 2) && (dataSizeLength == 1)){
			
				address = (Uds_ServiceRequestBuffer[3]<<8) + Uds_ServiceRequestBuffer[4];
				if(size <= 20 && address < 0x40u && address+size<=0x40u){
					DEL_ReadMemoryByAddress(address,size,fetchPointer);
	
					if(fetchPointer!= null){
				
						Uds_ResponseBufferPtr[0] = size+0x01;
						Uds_ResponseBufferPtr[1] = UDS_SID_READ_MEMORY_BY_ADDRESS + UDS_POSITIVE_RESPONSE_MASK;
				
						for(counter=0; counter<size; counter++)Uds_ResponseBufferPtr[0x02u+counter] = fetchPointer[counter];
						CanTp_Tx(Uds_ResponseBufferPtr);
						}else UDS_TxNegativeResponseMessage(UDS_SID_READ_MEMORY_BY_ADDRESS, NRC_GENERAL_PROGRAMMING_FALIURE);
					} else UDS_TxNegativeResponseMessage(UDS_SID_READ_MEMORY_BY_ADDRESS, NRC_REQUEST_OUT_OF_RANGE);
				} else UDS_TxNegativeResponseMessage(UDS_SID_READ_MEMORY_BY_ADDRESS, NRC_REQUEST_OUT_OF_RANGE);
			}else UDS_TxNegativeResponseMessage(UDS_SID_READ_MEMORY_BY_ADDRESS, NRC_SECURITY_ACCESS_DENIED);
		}else UDS_TxNegativeResponseMessage(UDS_SID_READ_MEMORY_BY_ADDRESS, NRC_SERVICE_NOT_SUPPORTED);
	}else UDS_TxNegativeResponseMessage(UDS_SID_READ_MEMORY_BY_ADDRESS, NRC_INVALID_FORMAT);
}

/**************************************************************************
 * Function : UDS_SecurityAccessHandler
 * Description : Secuiry Access Handler to Unlock the ECU
 * Parameters : Uds_ServiceRequestBuffer
 * Parameter Description : pointer to request message buffer  
 * Return Type : void 
 * Return Parameter : None
 * Global Variables Used : Uds_SessionTimer, Uds_TimeFactor, S3_ServerTimer
 * Function Invoked : RCC_GetClocksFreq, SysTick_CLKSourceConfig, SysTick_ITConfig, SysTick_SetReload,SysTick_CounterCmd
 **************************************************************************/

void UDS_SecurityAccessHandler(uint8_t* Uds_ServiceRequestBuffer){
	uint8_t messageLength = Uds_ServiceRequestBuffer[0];
	uint8_t subfunction = Uds_ServiceRequestBuffer[2];
	static uint8_t seedSent = FALSE;
	uint32_t seed;
	uint32_t key;
	
	if(Session.securityAccess){
		switch(subfunction){
			case REQUEST_SEED :
				if(messageLength==2){
					Uds_ResponseBufferPtr[0] = 0x06;
					Uds_ResponseBufferPtr[1] = UDS_SID_SECURITY_ACCESS + UDS_POSITIVE_RESPONSE_MASK;
					Uds_ResponseBufferPtr[2] = subfunction;
			
					if(Uds_SecurityStatus){
						Uds_ResponseBufferPtr[3] = 0x00;
						Uds_ResponseBufferPtr[4] = 0x00;
						Uds_ResponseBufferPtr[5] = 0x00;
						Uds_ResponseBufferPtr[6] = 0x00;
					}
					else{
						seed = RSA_generateKeyPair();
						Uds_ResponseBufferPtr[3] = (seed>>24)&0xFF;
						Uds_ResponseBufferPtr[4] = (seed>>16)&0xFF;
						Uds_ResponseBufferPtr[5] = (seed>>8)&0xFF;
						Uds_ResponseBufferPtr[6] = (seed)&0xFF;
						seedSent = TRUE;
					}
					CanTp_Tx(Uds_ResponseBufferPtr);
				}else UDS_TxNegativeResponseMessage(UDS_SID_SECURITY_ACCESS, NRC_INVALID_FORMAT); 
				break;
			
			case SEND_KEY : 
				if(messageLength==0x06){
					if(seedSent){
						key = (Uds_ServiceRequestBuffer[3]<<24)+(Uds_ServiceRequestBuffer[4]<<16)+(Uds_ServiceRequestBuffer[5]<<8)+Uds_ServiceRequestBuffer[6];
						if(RSA_decryptData(key) == Uds_UnlockCode)
							{
							Uds_ResponseBufferPtr[0] = 0x02;
							Uds_ResponseBufferPtr[1] = UDS_SID_SECURITY_ACCESS + UDS_POSITIVE_RESPONSE_MASK;
							Uds_ResponseBufferPtr[2] = subfunction;
							seedSent = FALSE;
							Uds_SecurityStatus = UNLOCKED;
							CanTp_Tx(Uds_ResponseBufferPtr);
							
						}else UDS_TxNegativeResponseMessage(UDS_SID_SECURITY_ACCESS, NRC_INVALID_KEY);
					}else UDS_TxNegativeResponseMessage(UDS_SID_SECURITY_ACCESS, NRC_REQUEST_SEQUENCE_ERROR); 
				}else UDS_TxNegativeResponseMessage(UDS_SID_SECURITY_ACCESS, NRC_INVALID_FORMAT);
				seedSent=FALSE;
				break;			
				
			default : UDS_TxNegativeResponseMessage(UDS_SID_SECURITY_ACCESS, NRC_SUB_FUNCTION_NOT_SUPPORTED); break;
		}
	}else UDS_TxNegativeResponseMessage(UDS_SID_SECURITY_ACCESS, NRC_SERVICE_NOT_SUPPORTED);
}

/**************************************************************************
 * Function : UDS_SessionTimerInit
 * Description : Initiate the Session Timer
 * Parameters : None
 * Parameter Description : None
 * Return Type : void 
 * Return Parameter : None
 * Global Variables Used : Uds_SessionTimer, Uds_TimeFactor, S3_ServerTimer
 * Function Invoked : RCC_GetClocksFreq, SysTick_CLKSourceConfig, SysTick_ITConfig, SysTick_SetReload,SysTick_CounterCmd
 **************************************************************************/

void UDS_CommunicationControlHandler(uint8_t* Uds_ServiceRequestBuffer){
	uint8_t messageLength = Uds_ServiceRequestBuffer[0];
	uint8_t subfunction = Uds_ServiceRequestBuffer[2];
	uint8_t communicationType = Uds_ServiceRequestBuffer[3];
	if(messageLength==3){
		if(Session.communicationControl){
			if(communicationType==NORMAL_COMMUNICAITON){
				switch(subfunction){
					
					case ENABLE_RX_AND_TX :
						Can_SetTransmissionAccess(ENABLE);
						Uds_ResponseBufferPtr[0] = 0x02;
						Uds_ResponseBufferPtr[1] = UDS_SID_COMMUNICATION_CONTROL + UDS_POSITIVE_RESPONSE_MASK;
						Uds_ResponseBufferPtr[2] = subfunction;
						CanTp_Tx(Uds_ResponseBufferPtr);
						break;
			
					case ENABLE_RX_AND_DISABLE_TX : 
						Uds_ResponseBufferPtr[0] = 0x02;
						Uds_ResponseBufferPtr[1] = UDS_SID_COMMUNICATION_CONTROL + UDS_POSITIVE_RESPONSE_MASK;
						Uds_ResponseBufferPtr[2] = subfunction;
						CanTp_Tx(Uds_ResponseBufferPtr);
						Can_SetTransmissionAccess(DISABLE);
						break;
				
					default : UDS_TxNegativeResponseMessage(UDS_SID_COMMUNICATION_CONTROL, NRC_SUB_FUNCTION_NOT_SUPPORTED); break;
			
				}
			}else UDS_TxNegativeResponseMessage(UDS_SID_COMMUNICATION_CONTROL, NRC_REQUEST_OUT_OF_RANGE);
		}else UDS_TxNegativeResponseMessage(UDS_SID_COMMUNICATION_CONTROL, NRC_SERVICE_NOT_SUPPORTED);
	}else UDS_TxNegativeResponseMessage(UDS_SID_COMMUNICATION_CONTROL, NRC_INVALID_FORMAT);
}

/**************************************************************************
 * Function : UDS_SessionTimerInit
 * Description : Initiate the Session Timer
 * Parameters : None
 * Parameter Description : None
 * Return Type : void 
 * Return Parameter : None
 * Global Variables Used : Uds_SessionTimer, Uds_TimeFactor, S3_ServerTimer
 * Function Invoked : RCC_GetClocksFreq, SysTick_CLKSourceConfig, SysTick_ITConfig, SysTick_SetReload,SysTick_CounterCmd
 **************************************************************************/

void UDS_WriteDataByIDHandler(uint8_t* Uds_ServiceRequestBuffer){
	uint8_t counter;
	uint8_t messageLength = Uds_ServiceRequestBuffer[0];
	uint16_t dataId = (Uds_ServiceRequestBuffer[2]<<8) + Uds_ServiceRequestBuffer[3];
	uint8_t dataBuffer[20];
	uint8_t* dataPointer = dataBuffer;
	uint8_t dataLength = messageLength-3;
	uint8_t NRC;
	
	if(Session.readDataByIdentifier){
		if(Uds_SecurityStatus){
			for(counter=0;counter<dataLength;counter++)dataPointer[counter] = Uds_ServiceRequestBuffer[counter+4];
			NRC = DEL_WriteDataById(dataId, dataLength, dataPointer);
			if(!NRC){
				Uds_ResponseBufferPtr[0] = 0x03;
				Uds_ResponseBufferPtr[1] = UDS_SID_WRITE_DATA_BY_ID + UDS_POSITIVE_RESPONSE_MASK;				
				Uds_ResponseBufferPtr[2] = dataId>>8;
				Uds_ResponseBufferPtr[3] = dataId & 0xFF;
				CanTp_Tx(Uds_ResponseBufferPtr);
			}else UDS_TxNegativeResponseMessage(UDS_SID_WRITE_DATA_BY_ID, NRC);
		}else UDS_TxNegativeResponseMessage(UDS_SID_WRITE_DATA_BY_ID, NRC_SECURITY_ACCESS_DENIED);
	}else UDS_TxNegativeResponseMessage(UDS_SID_WRITE_DATA_BY_ID, NRC_SERVICE_NOT_SUPPORTED);	
} 

/**************************************************************************
 * Function : UDS_SessionTimerInit
 * Description : Initiate the Session Timer
 * Parameters : None
 * Parameter Description : None
 * Return Type : void 
 * Return Parameter : None
 * Global Variables Used : Uds_SessionTimer, Uds_TimeFactor, S3_ServerTimer
 * Function Invoked : RCC_GetClocksFreq, SysTick_CLKSourceConfig, SysTick_ITConfig, SysTick_SetReload,SysTick_CounterCmd
 **************************************************************************/

void UDS_WriteMemoryByAddressHandler(uint8_t* Uds_ServiceRequestBuffer){
	uint8_t messageLength = Uds_ServiceRequestBuffer[0];
	uint8_t counter;
	uint8_t addressLength = Uds_ServiceRequestBuffer[2]&0x0F;
	uint8_t dataSizeLength = Uds_ServiceRequestBuffer[2]>>4;
	uint16_t address = (Uds_ServiceRequestBuffer[3]<<8) + Uds_ServiceRequestBuffer[4];
	uint8_t size = Uds_ServiceRequestBuffer[5];
	uint8_t dataBuffer[16];
	uint8_t* dataPointer = dataBuffer;
	
	if(messageLength==size+4){
		if(Session.writeMemoryByAddress){
			if(Uds_SecurityStatus){
				if((addressLength == 2) && (dataSizeLength == 1) && (size<=20)){

					for(counter=0;counter<size;counter++)dataBuffer[counter]=Uds_ServiceRequestBuffer[6+counter];
	
					if(DEL_WriteMemoryByAddress(address,size,dataPointer)){
				
						Uds_ResponseBufferPtr[0] = 0x04;
						Uds_ResponseBufferPtr[1] = UDS_SID_WRITE_MEMORY_BY_ADDRESS + UDS_POSITIVE_RESPONSE_MASK;
						Uds_ResponseBufferPtr[2] = address >> 8;
						Uds_ResponseBufferPtr[3] = address & 0xFF;
						Uds_ResponseBufferPtr[4] = size;
						CanTp_Tx(Uds_ResponseBufferPtr);
				
					}else UDS_TxNegativeResponseMessage(UDS_SID_WRITE_MEMORY_BY_ADDRESS, NRC_GENERAL_PROGRAMMING_FALIURE);
				}else UDS_TxNegativeResponseMessage(UDS_SID_WRITE_MEMORY_BY_ADDRESS, NRC_REQUEST_OUT_OF_RANGE);
			}else UDS_TxNegativeResponseMessage(UDS_SID_WRITE_MEMORY_BY_ADDRESS, NRC_SECURITY_ACCESS_DENIED);
		}else UDS_TxNegativeResponseMessage(UDS_SID_WRITE_MEMORY_BY_ADDRESS, NRC_SERVICE_NOT_SUPPORTED);
	}else UDS_TxNegativeResponseMessage(UDS_SID_WRITE_MEMORY_BY_ADDRESS, NRC_INVALID_FORMAT);
}

/**************************************************************************
 * Function : UDS_SessionTimerInit
 * Description : Initiate the Session Timer
 * Parameters : None
 * Parameter Description : None
 * Return Type : void 
 * Return Parameter : None
 * Global Variables Used : Uds_SessionTimer, Uds_TimeFactor, S3_ServerTimer
 * Function Invoked : RCC_GetClocksFreq, SysTick_CLKSourceConfig, SysTick_ITConfig, SysTick_SetReload,SysTick_CounterCmd
 **************************************************************************/
void UDS_TesterPresentHandler(uint8_t* Uds_ServiceRequestBuffer)
{
	uint8_t messageLength = Uds_ServiceRequestBuffer[0];
	uint8_t subfunction = Uds_ServiceRequestBuffer[2];
	
	if(messageLength==2)
	{
	  switch(subfunction)
		 {
			    case ZERO_SUB_FUNCTION:
				      Uds_ResponseBufferPtr[0] = 0x02;
			      	Uds_ResponseBufferPtr[1] = UDS_SID_TESTER_PRESENT + UDS_POSITIVE_RESPONSE_MASK;
				      Uds_ResponseBufferPtr[2] = subfunction;
	       			CanTp_Tx(Uds_ResponseBufferPtr);
				      break;
			default:
       				UDS_TxNegativeResponseMessage(UDS_SID_TESTER_PRESENT, NRC_SUB_FUNCTION_NOT_SUPPORTED);
				      break;
			}
	}else UDS_TxNegativeResponseMessage(UDS_SID_TESTER_PRESENT, NRC_INVALID_FORMAT);
}


/**************************************************************************
 * Function : UDS_SessionTimerInit
 * Description : Initiate the Session Timer
 * Parameters : None
 * Parameter Description : None
 * Return Type : void 
 * Return Parameter : None
 * Global Variables Used : Uds_SessionTimer, Uds_TimeFactor, S3_ServerTimer
 * Function Invoked : RCC_GetClocksFreq, SysTick_CLKSourceConfig, SysTick_ITConfig, SysTick_SetReload,SysTick_CounterCmd
 **************************************************************************/

void UDS_Routine_control(uint8_t* Uds_ServiceRequestBuffer)
{
	uint8_t messagelength = Uds_ServiceRequestBuffer[0];
	uint8_t subfunction = Uds_ServiceRequestBuffer[2];
	uint8_t R1=Uds_ServiceRequestBuffer[3];
	uint8_t R2=Uds_ServiceRequestBuffer[4];
	
	if(messagelength==0x04)
		{
			if(subfunction==0x03)
				{
					if(((RID1==R1) && (RID2==R2)))
				   {
		            Uds_ResponseBufferPtr[0]=0x04;
		            Uds_ResponseBufferPtr[1]=UDS_SID_ROUTINE_CONTROL	+ UDS_POSITIVE_RESPONSE_MASK;
		            Uds_ResponseBufferPtr[2]=REQUEST_FOR_RESULTS;
	              Uds_ResponseBufferPtr[3]=RID1;
		            Uds_ResponseBufferPtr[4]=RID2;
		            CanTp_Tx(Uds_ResponseBufferPtr);	
	         }  
	          else UDS_TxNegativeResponseMessage(UDS_SID_ROUTINE_CONTROL, NRC_REQUEST_OUT_OF_RANGE);
	       }
			     else UDS_TxNegativeResponseMessage(UDS_SID_ROUTINE_CONTROL,NRC_SUB_FUNCTION_NOT_SUPPORTED);
	   }
	   	else	UDS_TxNegativeResponseMessage(UDS_SID_ROUTINE_CONTROL,NRC_INVALID_FORMAT);
}


/**************************************************************************
 * Function : UDS_SessionTimerInit
 * Description : Initiate the Session Timer
 * Parameters : None
 * Parameter Description : None
 * Return Type : void 
 * Return Parameter : None
 * Global Variables Used : Uds_SessionTimer, Uds_TimeFactor, S3_ServerTimer
 * Function Invoked : RCC_GetClocksFreq, SysTick_CLKSourceConfig, SysTick_ITConfig, SysTick_SetReload,SysTick_CounterCmd
 **************************************************************************/
uint8_t Upload_buffer(uint8_t* upload_buf_size)
{
				up_buff[0]=upload_buf_size[0];
	      up_buff[1]=upload_buf_size[1];
				up_buff[2]=upload_buf_size[2];
			  up_buff[3]=upload_buf_size[3];
				up_buff[4]=upload_buf_size[4];
	      up_buff[5]=upload_buf_size[5];

}

void UDS_Request_Upload(uint8_t* Uds_ServiceRequestBuffer)
{
	   // static uint8_t req_upload=0;
		  uint8_t messagelength = Uds_ServiceRequestBuffer[0];
	    uint8_t cmp =0;
	    uint8_t enyp =0;
	    uint8_t count =0;
	    uint8_t byte=0;
      uint8_t address=0;
	    uint8_t size=0;
	
	if((UNLOCKED)==1)
	{
  	if(!req_upload)
		{
		   if(0x00u == Uds_ServiceRequestBuffer[2])
		   {	
		      if(messagelength>0x03)
			    {
				   /* Calculate the address */
				    cmp = (Uds_ServiceRequestBuffer[3] & 0x0Fu);
				    enyp = (Uds_ServiceRequestBuffer[3] >> 0x04u);
				
				    if(messagelength == (0x03u+cmp+enyp))
				    {
				     	for(count=cmp,byte=1;count>0u;count--,byte++)
				      {
				           		address |= (Uds_ServiceRequestBuffer[3+byte]<<((count-1)*8));
						
				      }
					     /* Calculate the size */
					     for(count=enyp,byte=1;count>0u;count--,byte++)
					     {
						           size |= (Uds_ServiceRequestBuffer[3+byte+cmp]<<((count-1)*8));
					     }
							 
                    req_upload =0x01u;
							 
			  	          Uds_ServiceRequestBuffer[0]=0x05;
							      
		                Uds_ServiceRequestBuffer[1]=UDS_SID_REQUEST_UPLOAD + UDS_POSITIVE_RESPONSE_MASK;
							 
			              Uds_ServiceRequestBuffer[2]=0x02;
							 
			              Uds_ServiceRequestBuffer[3]=0x14;
							 
							      Uds_ServiceRequestBuffer[4]=0x40;
							  
							      Uds_ServiceRequestBuffer[5]=0x44;
							 
							      Upload_buffer(Uds_ServiceRequestBuffer);
							 
							      CanTp_Tx(Uds_ServiceRequestBuffer);
					
				   }else  UDS_TxNegativeResponseMessage(UDS_SID_REQUEST_UPLOAD, NRC_REQUEST_OUT_OF_RANGE);
				
		     }else UDS_TxNegativeResponseMessage(UDS_SID_REQUEST_UPLOAD,NRC_INVALID_FORMAT);
			
	     }else UDS_TxNegativeResponseMessage(UDS_SID_REQUEST_UPLOAD,UPLOAD_DOWNLOAD_NOT_ACCEPTED);		
		
	   }else UDS_TxNegativeResponseMessage(UDS_SID_REQUEST_UPLOAD, NRC_SECURITY_ACCESS_DENIED);			
   }
}



void UDS_Request_Download(uint8_t* Uds_ServiceRequestBuffer,uint8_t *up_buff )
{
	   // static uint8_t req_downlaod=0;
		  uint8_t messagelength = Uds_ServiceRequestBuffer[0];
	    uint8_t cmp =0;
	    uint8_t enyp =0;
	    uint8_t count =0;
	    uint8_t byte=0;
      uint8_t address=0;
	    uint8_t size=0;
	
	if((UNLOCKED)==1)
	{
  	if(!req_downlaod)
		{
		   if(0x00u == Uds_ServiceRequestBuffer[2])
		   {	
		      if(messagelength>0x03)
			    {
				 // Calculate the address 
				    cmp = (Uds_ServiceRequestBuffer[3] & 0x0Fu);
				    enyp = (Uds_ServiceRequestBuffer[3] >> 0x04u);
				
				    if(messagelength == (0x03u+cmp+enyp))
				    {
				     	for(count=cmp,byte=1;count>0u;count--,byte++)
				      {
				           		address |= (Uds_ServiceRequestBuffer[3+byte]<<((count-1)*8));
						
				      }
					    //  Calculate the size 
					     for(count=enyp,byte=1;count>0u;count--,byte++)
					     {
						           size |= (Uds_ServiceRequestBuffer[3+byte+cmp]<<((count-1)*8));
					     }
							 
                    req_downlaod =0x01u;
							 
			  	          Uds_ServiceRequestBuffer[0]=up_buff[0];
							      
		                Uds_ServiceRequestBuffer[1]=UDS_SID_REQUEST_DOWNLOAD + UDS_POSITIVE_RESPONSE_MASK;
							 
			              Uds_ServiceRequestBuffer[2]=up_buff[2];
							 
			              Uds_ServiceRequestBuffer[3]=up_buff[3];
							 
							      Uds_ServiceRequestBuffer[4]=up_buff[4];
							 
							       Uds_ServiceRequestBuffer[5]=up_buff[5];
							 
							      CanTp_Tx(Uds_ServiceRequestBuffer);
					
				   }else  UDS_TxNegativeResponseMessage(UDS_SID_REQUEST_DOWNLOAD, NRC_REQUEST_OUT_OF_RANGE);
				
		     }else UDS_TxNegativeResponseMessage(UDS_SID_REQUEST_DOWNLOAD,NRC_INVALID_FORMAT);
			
	     }else UDS_TxNegativeResponseMessage(UDS_SID_REQUEST_DOWNLOAD,UPLOAD_DOWNLOAD_NOT_ACCEPTED);		
		
	   }else UDS_TxNegativeResponseMessage(UDS_SID_REQUEST_DOWNLOAD, NRC_SECURITY_ACCESS_DENIED);			
   }
}


void UDS_TransferData(uint8_t* Uds_ServiceRequestBuffer)
{
	static uint8_t blockseqcnt=0x01u;
	static uint8_t memorysize=0x00u;
	static uint8_t data[64][64];
	uint8_t cnt;
	uint8_t messagelength = Uds_ServiceRequestBuffer[0];
  if(messagelength==0x02)
   {		
	   if((req_downlaod != 0u) || (req_upload != 0u))
	  {
		  if(transferdone == 0u)
		  {
			if(req_downlaod)
			{
				if(blockseqcnt == Uds_ServiceRequestBuffer[2])
				{
					memorysize += messagelength-0x02u;
		
					for(cnt=0;cnt<messagelength;cnt++)
					{
						data[blockseqcnt][cnt]=Uds_ServiceRequestBuffer[3+cnt];
					
					}
					transferdone=01u;
					
					if(memorysize <= size)
					{
						/* Send the response */
						Uds_ServiceRequestBuffer[0] = 0x02u;
						Uds_ServiceRequestBuffer[1] = UDS_SID_TRANSFER_DATA + UDS_POSITIVE_RESPONSE_MASK;
						Uds_ServiceRequestBuffer[2] = blockseqcnt;
						CanTp_Tx(Uds_ServiceRequestBuffer);
					}
				}else UDS_TxNegativeResponseMessage(UDS_SID_TRANSFER_DATA, WRONG_BLOCK_SEQUENCE_COUNTER);
			}
	  }else UDS_TxNegativeResponseMessage(UDS_SID_TRANSFER_DATA, NRC_REQUEST_SEQUENCE_ERROR);
	}
 }else UDS_TxNegativeResponseMessage(UDS_SID_TRANSFER_DATA, NRC_INVALID_FORMAT);	
}	


void UDS_RequestTransferExit(uint8_t* Uds_ServiceRequestBuffer)
{
	uint8_t messagelength = Uds_ServiceRequestBuffer[0];
	uint8_t exit_buff=0x00;
	
	if(messagelength==0x02)
	{
	if((req_downlaod) && (req_upload))
		{
			req_downlaod=0;
			req_upload=0;
	    
			Uds_ServiceRequestBuffer[0] = 0x02u;
			Uds_ServiceRequestBuffer[1] = UDS_SID_REQUEST_TRANSFER_EXIT + UDS_POSITIVE_RESPONSE_MASK;
			Uds_ServiceRequestBuffer[2] = exit_buff;
			CanTp_Tx(Uds_ServiceRequestBuffer);
		}else UDS_TxNegativeResponseMessage(UDS_SID_REQUEST_TRANSFER_EXIT, NRC_REQUEST_SEQUENCE_ERROR);
		
	}else UDS_TxNegativeResponseMessage(UDS_SID_REQUEST_TRANSFER_EXIT, NRC_INVALID_FORMAT);
}

/**************************************************************************
 * Function : UDS_SessionTimerInit
 * Description : Initiate the Session Timer
 * Parameters : None
 * Parameter Description : None
 * Return Type : void 
 * Return Parameter : None
 * Global Variables Used : Uds_SessionTimer, Uds_TimeFactor, S3_ServerTimer
 * Function Invoked : RCC_GetClocksFreq, SysTick_CLKSourceConfig, SysTick_ITConfig, SysTick_SetReload,SysTick_CounterCmd
 **************************************************************************/
 


void UDS_ServiceRequest(uint8_t* Uds_ServiceRequestBuffer){
	
	uint8_t service = Uds_ServiceRequestBuffer[1];
	  if(S3_ServerTimer)
		    UDS_SessionTimerInit();
	 
	switch(service)
		{
		
		case UDS_SID_DIAGNOSTIC_SESSION_CONTROL  : UDS_SessionControlHandler(Uds_ServiceRequestBuffer);	break; // security access not required
		
		case UDS_SID_ECU_RESET                   : UDS_EcuResetHandler(Uds_ServiceRequestBuffer);break;	// security access required
		
		case UDS_SID_CLEAR_DIAGNOSTIC_INFO       : UDS_ClearDiagnosticInfoHandler(Uds_ServiceRequestBuffer);break;
		
		case UDS_SID_READ_DTC_INFO               : UDS_ReadDTCInfoHandler(Uds_ServiceRequestBuffer);break;
		
		case UDS_SID_READ_DATA_BY_ID             : UDS_ReadDataById(Uds_ServiceRequestBuffer); break;
		
		case UDS_SID_READ_MEMORY_BY_ADDRESS      : UDS_ReadMemoryByAddressHandler(Uds_ServiceRequestBuffer); break;
		
		case UDS_SID_SECURITY_ACCESS             : UDS_SecurityAccessHandler(Uds_ServiceRequestBuffer);break;
		
		case UDS_SID_COMMUNICATION_CONTROL       : UDS_CommunicationControlHandler(Uds_ServiceRequestBuffer);break;
		
		case UDS_SID_READ_DATA_BY_PERIODIC_ID    : break;	
		
		case UDS_SID_DYNAMICALLY_DEFINED_DATA_ID : break;
		
		case UDS_SID_WRITE_DATA_BY_ID            : UDS_WriteDataByIDHandler(Uds_ServiceRequestBuffer); break;
		
		case UDS_SID_WRITE_MEMORY_BY_ADDRESS     : UDS_WriteMemoryByAddressHandler(Uds_ServiceRequestBuffer); break;
		
		case UDS_SID_TESTER_PRESENT              : UDS_TesterPresentHandler(Uds_ServiceRequestBuffer); break;
		
		case UDS_SID_ACCESS_TIMING_PARAMETER     : break;
		
		case UDS_SID_CONTROL_DTC_SETTING         : break;
		
		case UDS_SID_RESPONSE_ON_EVENT           : break;
		
		case UDS_SID_ROUTINE_CONTROL						 : UDS_Routine_control(Uds_ServiceRequestBuffer); break;
		
		case UDS_SID_REQUEST_DOWNLOAD            : UDS_Request_Download(Uds_ServiceRequestBuffer,up_buff);break;
																						 
		case UDS_SID_REQUEST_UPLOAD							 : UDS_Request_Upload(Uds_ServiceRequestBuffer);break;
		
		case UDS_SID_TRANSFER_DATA							 : UDS_TransferData(Uds_ServiceRequestBuffer);break;
		
		case UDS_SID_REQUEST_TRANSFER_EXIT       : UDS_RequestTransferExit(Uds_ServiceRequestBuffer);break;
		
		default: UDS_TxNegativeResponseMessage(service, NRC_SERVICE_NOT_SUPPORTED);
			
	}
}



/**************************************************************************
 * Function : UDS_SessionTimerInit
 * Description : Initiate the Session Timer
 * Parameters : None
 * Parameter Description : None
 * Return Type : void 
 * Return Parameter : None
 * Global Variables Used : Uds_SessionTimer, Uds_TimeFactor, S3_ServerTimer
 * Function Invoked : RCC_GetClocksFreq, SysTick_CLKSourceConfig, SysTick_ITConfig, SysTick_SetReload,SysTick_CounterCmd
 **************************************************************************/
void UDS_TxNegativeResponseMessage(uint8_t service, uint8_t NRC){
	Uds_ResponseBufferPtr[0] = 0x03;
	Uds_ResponseBufferPtr[1] = UDS_NEGATIVE_RESPONSE_ID;
	Uds_ResponseBufferPtr[2] = service;
	Uds_ResponseBufferPtr[3] = NRC;
	CanTp_Tx(Uds_ResponseBufferPtr);
}
/**************************************************************************
 * Function : UDS_Init
 * Description : Initiate the UDS Services 
 * Parameters : None
 * Parameter Description : None
 * Return Type : void 
 * Return Parameter : None
 * Global Variables Used : Uds_SecurityStatus
 * Function Invoked : UDS_SessionInit
 **************************************************************************/
void UDS_Init(void){
	UDS_SessionInit(DEFAULT_SESSION);
	Uds_SecurityStatus = LOCKED;
	DEL_identifierInit();
	DEL_MemoryInit();
	S3_ServerTimer=FALSE;
}

/*---------------------------------------- End Of File ----------------------------------------*/
