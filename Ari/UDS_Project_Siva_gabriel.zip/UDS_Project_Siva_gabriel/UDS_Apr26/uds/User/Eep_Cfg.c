/******************************************************************************
** Automotive Robotics India Pvt  Limited                                    **
**                                                                           **
**Automotive Robotics India Pvt Limited owns all the rights to this work.This work**
** shall not be copied, reproduced, used, modified or its information        **
** disclosed without the prior written authorization of ARI  Technologies    **
** Limited.                                                                  **
**                                                                           **
**  SRC-MODULE: Eep_Cfg.c                                                    **
**                                                                           **
**  TARGET    : All                                                          **
**                                                                           **
**  PRODUCT   : AUTOSAR EEPROM                                               **
**                                                                           **
**  PURPOSE   : To implement API's for EEPROM                                **
**                                                                           **
**  PLATFORM DEPENDANT [yes/no]: yes                                         **
**                                                                           **
**  TO BE CHANGED BY USER [yes/no]: no                                       **
**                                                                           **
******************************************************************************/

/* Configured for:
 * Microchip AT24C01A (1k bytes pages)
 */
/******************************************************************************
**                      Revision History                                     **
*******************************************************************************
** Revision  Date           Changed By             Description                **
*******************************************************************************
** 1.0.0     20-July-2018   M Kumar Yadav         Initial version             *
******************************************************************************/

/******************************************************************************
**                      Include Section                                      **
******************************************************************************/

#include "stm32f10x.h"

#include <string.h>
#include <stdio.h>
#include "Eep.h"
#include "Det.h"
#include "Eep_ConfigTypes.h"
#include "Std_Types.h"

#define E2_M9525		    1
#define E2_25LC512KB		1

const Eep_ConfigType EepConfigData[] = 
{
    {

 // This parameter is the EEPROM device base address(EepBaseAddress).//
      7,
	// This parameter is the default EEPROM device mode after initialization(EepDefaultMode).//
		  
    MEMIF_MODE_SLOW,
	 // This parameter is the number of bytes read within one job processing cycle in fast mode//
		
   #if (E2_CHIP  == E2_25LC512KB)
   // This parameter is the number of bytes read within one job processing cycle in fast mode
   32,
    // This parameter is the number of bytes written within one job processing cycle in fast mode
   32,
#elif (E2_CHIP  == E2_M9525)
	 // This parameter is the number of bytes read within one job processing cycle in fast mode
    64,
	 // This parameter is the number of bytes written within one job processing cycle in fast mode
    64,
#endif
	// call cycle of the job processing function during write/erase operations. Unit: [s]//
	  0.01,
	// This parameter is a reference to a callback function for positive job result//
    0,
  // This parameter is a reference to a callback function for negative job result//
	  0,
  // number of bytes read within one job processing cycle in normal mode.//
	  0,
	// Number of bytes written within one job processing cycle in normal mode.//
	  0,
	// This parameter is the used size of EEPROM device in bytes.//
	  4096,
	// This parameter is the EEPROM page size, i.e. number of bytes
    51200,
	//  uint32_t I2C_ClockSpeed//
	  10000,
	//uint16_t I2C_Mode//
	  0x0000,
	  //uint16_t I2C_DutyCycle//
		0xBFFF,
		//uint16_t I2C_OwnAddress1
		0x30,
		 //uint16_t I2C_Ack
		0x0400,
		  // uint16_t I2C_AcknowledgedAddress
		 0x4000,
    }
};

Std_VersionInfoType Std_VersionIn[]=
{
      15,/**< Module  numbers */
    	 4,   /**< Vendor numbers */
       1,   /**< Vendor numbers */
       4,    /**< Vendor numbers */
};


