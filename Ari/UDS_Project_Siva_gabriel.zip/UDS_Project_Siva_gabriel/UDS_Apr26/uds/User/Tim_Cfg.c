/************************************************************
 * PROJECT: ESS_IP_UDS_Implementation_Project
 *
 * FILE NAME : Tim_Cfg.c
 *
 * TARGET PLATFORM : STM32f107
 *
 * BUILD ENVIRONMENT : RealView MDK-ARM  Version: 4.20 
 *
 * DISCRIPTION : Initialization for Timer structures(Configure the Timers)
 *
 * VERSION : v1.0
 *
 * PLATFORM DEPENDANT [yes/no] : yes
 *
 * TO BE CHANGED BY THE USER [yes/no] : no
 *	
 * CREATED BY: Chirag Juneja
 *
 * LICENSE: ARIPL SOFTWARE LICENSE
 ************************************************************/
 
/*---------------------------------------- Includes ----------------------------------------*/

#include "Tim_Cfg.h"


/*---------------------------------------- Global Variables ----------------------------------------*/


Timer Timer_2 = {
	
	TIM2,
	TIM2_IRQn,
	RCC_APB1Periph_TIM2,
	RESET,
	{
		TIM_MS_PRESCALER-1,
		TIM_CounterMode_Up,
		TIM_MS_PERIOD-1, 
		TIM_CKD_DIV1,
		TIM_MS_REPITITION_COUNT
	}
};

Timer* TIM_2 = &Timer_2;

Timer Timer_3 = {
	
	TIM3,
	TIM3_IRQn,
	RCC_APB1Periph_TIM3,
	RESET,
	{
		TIM_MS_PRESCALER-1,
		TIM_CounterMode_Up,
		TIM_MS_PERIOD-1, 
		TIM_CKD_DIV1,
		TIM_MS_REPITITION_COUNT
	}
};

Timer* TIM_3 = &Timer_3;

Timer Timer_4 = {
	
	TIM4,
	TIM4_IRQn,
	RCC_APB1Periph_TIM4,
	RESET,
	{
		TIM_MS_PRESCALER-1,
		TIM_CounterMode_Up,
		TIM_MS_PERIOD-1, 
		TIM_CKD_DIV1,
		TIM_MS_REPITITION_COUNT
	}
};

Timer* TIM_4 = &Timer_4;

Timer Timer_5 = {
	
	TIM5,
	TIM5_IRQn,
	RCC_APB1Periph_TIM5,
	RESET,
	{
		TIM_MS_PRESCALER-1,
		TIM_CounterMode_Up,
		TIM_MS_PERIOD-1, 
		TIM_CKD_DIV1,
		TIM_MS_REPITITION_COUNT
	}
};

Timer* TIM_5 = &Timer_5;
/*
Timer Timer_6 = {
	
	TIM6,
	TIM6_IRQn,
	RCC_APB1Periph_TIM6,
	RESET,
	{
		TIM_MS_PRESCALER-1,
		TIM_CounterMode_Up,
		TIM_MS_PERIOD-1, 
		TIM_CKD_DIV1,
		TIM_MS_REPITITION_COUNT
	}
};

Timer* TIM_6 = &Timer_6;
*/
Timer Timer_7 = {
	
	TIM7,
	TIM7_IRQn,
	RCC_APB1Periph_TIM7,
	RESET,
	{
		TIM_MS_PRESCALER-1,
		TIM_CounterMode_Up,
		TIM_MS_PERIOD-1, 
		TIM_CKD_DIV1,
		TIM_MS_REPITITION_COUNT
	}
};

Timer* TIM_7 = &Timer_7;
