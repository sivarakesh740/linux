/*********************************************************************************************************
*
* File                : CanTp_Timer.h
* Hardware Environment: 
* Build Environment   : RealView MDK-ARM  Version: 4.20
* Version             : V1.0
* By                  : Anirudh Tadepally
*
*                                
*
*********************************************************************************************************/

#ifndef __CANTPTIMER_H
#define __CANTPTIMER_H 

/* Includes ------------------------------------------------------------------*/	   
#include "stm32f4xx.h"
#include "stm32f4xx_tim.h"

/* Private function prototypes -----------------------------------------------*/
void CanTp_delay_init(void);
void CanTp_delay_us(u32 Nus);
void CanTp_delay_ms(uint16_t nms);

#endif
/*********************************************************************************************************
      END FILE
*********************************************************************************************************/







