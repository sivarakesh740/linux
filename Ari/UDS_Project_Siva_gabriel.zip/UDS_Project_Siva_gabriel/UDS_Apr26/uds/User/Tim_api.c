/************************************************************
 * PROJECT: ESS_IP_UDS_Implementation_Project
 *
 * FILE NAME : Tim_api.c
 *
 * TARGET PLATFORM : STM32f107
 *
 * BUILD ENVIRONMENT : RealView MDK-ARM  Version: 4.20 
 *
 * DISCRIPTION : API to use General Purpose and Basic Timer of STM32f107
 *
 * VERSION : v1.0
 *
 * PLATFORM DEPENDANT [yes/no] : yes
 *
 * TO BE CHANGED BY THE USER [yes/no] : no
 *	
 * CREATED BY: Chirag Juneja
 *
 * LICENSE: ARIPL SOFTWARE LICENSE
 ************************************************************/
 
/*---------------------------------------- Includes ----------------------------------------*/

#include "Tim_api.h"
#include "Tim_Cfg.h"

/*---------------------------------------- Function Definations ----------------------------------------*/

/**************************************************************************
 * Function : TIM_Init
 * Description : Initialize the General Purpose/Basic Timer 
 * Parameters : TIM_x 
 * Parameter Description : Timer to be initialized
 * Return Type : void 
 * Return Parameter : None
 * Global Variables Used : None
 * Function Invoked : RCC_APB1PeriphClockCmd, NVIC_Init, TIM_InternalClockConfig, TIM_ClearITPendingBit
 **************************************************************************/
 
void TIM_Init(Timer* TIM_x){
	
		
	NVIC_InitTypeDef NVIC_InitStructure;
	
	RCC_APB1PeriphClockCmd(TIM_x->Clock, ENABLE);
	
	/* Enable Interrupt handler for Timer */
	
	NVIC_InitStructure.NVIC_IRQChannel = TIM_x->IRQHandler; 	// TIMx interrupt 
	NVIC_InitStructure.NVIC_IRQChannelPreemptionPriority = 0; 	// Preemptive priority level 0   
	NVIC_InitStructure.NVIC_IRQChannelSubPriority = 3; 			// From the priority level 3   
	NVIC_InitStructure.NVIC_IRQChannelCmd = ENABLE; 			// The IRQ channel is enabled   
	NVIC_Init(&NVIC_InitStructure);
	
	TIM_InternalClockConfig(TIM_x->TIM_Type); 		// Set clock source of the timer as Internal Clock
	TIM_ClearITPendingBit(TIM_x->TIM_Type, TIM_IT_Update);		// Clear Interrupt Flag of the Timer
}	

/**************************************************************************
 * Function : TIM_delayms
 * Description : Generate a delay in milliseconds
 * Parameters : TIM_x, Nms 
 * Parameter Description : Timer to be initialized, delay in milliseconds
 * Return Type : void 
 * Return Parameter : None
 * Global Variables Used : None
 * Function Invoked : TIM_TimeBaseInit, TIM_ClearFlag, TIM_ITConfig, TIM_ClearITPendingBit, TIM_Cmd
 **************************************************************************/

void TIM_delayms(Timer* TIM_x,uint16_t Nms){
	
	TIM_x->ITFlag = RESET;		
	/* Configure the Timer */
	TIM_x->TIM_Setup.TIM_Prescaler = (TIM_MS_PRESCALER * Nms)-1;
	TIM_x->TIM_Setup.TIM_Period = (TIM_MS_PERIOD)-1;
	TIM_TimeBaseInit(TIM_x->TIM_Type, &TIM_x->TIM_Setup);
	
	TIM_ClearFlag(TIM_x->TIM_Type,TIM_FLAG_Update);			//  Clear the Update flag of the timer
	TIM_ITConfig(TIM_x->TIM_Type, TIM_IT_Update, ENABLE); 	// set interrupt event
	
	TIM_ClearITPendingBit(TIM_x->TIM_Type, TIM_IT_Update);				// Clear Interrupt Flag of the Timer
	TIM_Cmd(TIM_x->TIM_Type, ENABLE); 						// Start the Timer
	while(!TIM_x->ITFlag);
}

void TIM_counterms(Timer* TIM_x,uint16_t Nms){
	TIM_x->ITFlag = RESET;		
	/* Configure the Timer */
	TIM_x->TIM_Setup.TIM_Prescaler = (TIM_MS_PRESCALER * Nms)-1;
	TIM_x->TIM_Setup.TIM_Period = (TIM_MS_PERIOD)-1;
	TIM_TimeBaseInit(TIM_x->TIM_Type, &TIM_x->TIM_Setup);
	
	TIM_ClearFlag(TIM_x->TIM_Type,TIM_FLAG_Update);			//  Clear the Update flag of the timer
	TIM_ITConfig(TIM_x->TIM_Type, TIM_IT_Update, ENABLE); 	// set interrupt event
	
	TIM_ClearITPendingBit(TIM_x->TIM_Type, TIM_IT_Update);				// Clear Interrupt Flag of the Timer
	TIM_Cmd(TIM_x->TIM_Type, ENABLE); 						// Start the Timer
}

/**************************************************************************
 * Function : TIM_delayus
 * Description : Generate a delay in microseconds
 * Parameters : TIM_x, Nus 
 * Parameter Description : Timer to be initialized, delay in microseconds
 * Return Type : void 
 * Return Parameter : None
 * Global Variables Used : None
 * Function Invoked : TIM_TimeBaseInit, TIM_ClearFlag, TIM_ITConfig, TIM_ClearITPendingBit, TIM_Cmd
 **************************************************************************/

void TIM_delayus(Timer* TIM_x,uint16_t Nus){
	
	TIM_x->ITFlag = RESET;
	
	TIM_x->TIM_Setup.TIM_Prescaler = (TIM_US_PRESCALER * Nus)-1;
	TIM_x->TIM_Setup.TIM_Period = (TIM_US_PERIOD)-1;
	TIM_TimeBaseInit(TIM_x->TIM_Type, &TIM_x->TIM_Setup);
	
	TIM_ClearFlag(TIM_x->TIM_Type,TIM_FLAG_Update);			//  Clear the Update flag of the timer
	TIM_ITConfig(TIM_x->TIM_Type, TIM_IT_Update, ENABLE); 	// set interrupt event
	
	TIM_ClearITPendingBit(TIM_x->TIM_Type, TIM_IT_Update);				// Clear Interrupt Flag of the Timer	
	TIM_Cmd(TIM_x->TIM_Type, ENABLE); 						// Start the Timer
	while(!TIM_x->ITFlag);
	
}

/**************************************************************************
 * Function : TIM2_IRQHandler
 * Description : Inerrupt Handler for TIM2
 * Parameters : None
 * Parameter Description : None
 * Return Type : void 
 * Return Parameter : None
 * Global Variables Used : None
 * Function Invoked : TIM_ClearITPendingBit
 **************************************************************************/

void TIM2_IRQHandler(void){
	TIM_2->ITFlag = SET;
	TIM_ClearITPendingBit(TIM2, TIM_IT_Update);
}

/**************************************************************************
 * Function : TIM3_IRQHandler
 * Description : Inerrupt Handler for TIM3
 * Parameters : None
 * Parameter Description : None
 * Return Type : void 
 * Return Parameter : None
 * Global Variables Used : None
 * Function Invoked : TIM_ClearITPendingBit
 **************************************************************************/

void TIM3_IRQHandler(void){
	TIM_3->ITFlag = SET;
	TIM_ClearITPendingBit(TIM3, TIM_IT_Update);
}

/**************************************************************************
 * Function : TIM4_IRQHandler
 * Description : Inerrupt Handler for TIM4
 * Parameters : None
 * Parameter Description : None
 * Return Type : void 
 * Return Parameter : None
 * Global Variables Used : None
 * Function Invoked : TIM_ClearITPendingBit
 **************************************************************************/

void TIM4_IRQHandler(void){
	TIM_4->ITFlag = SET;
	TIM_ClearITPendingBit(TIM4, TIM_IT_Update);
}

/**************************************************************************
 * Function : TIM5_IRQHandler
 * Description : Inerrupt Handler for TIM5
 * Parameters : None
 * Parameter Description : None
 * Return Type : void 
 * Return Parameter : None
 * Global Variables Used : None
 * Function Invoked : TIM_ClearITPendingBit
 **************************************************************************/

void TIM5_IRQHandler(void){
	TIM_5->ITFlag = SET;
	TIM_ClearITPendingBit(TIM5, TIM_IT_Update);
}

/**************************************************************************
 * Function : TIM6_IRQHandler
 * Description : Inerrupt Handler for TIM6
 * Parameters : None
 * Parameter Description : None
 * Return Type : void 
 * Return Parameter : None
 * Global Variables Used : None
 * Function Invoked : TIM_ClearITPendingBit
 **************************************************************************/
/*
void TIM6_IRQHandler(void){
	TIM_6->ITFlag = SET;
	TIM_ClearITPendingBit(TIM6, TIM_IT_Update);
}
*/
/**************************************************************************
 * Function : TIM7_IRQHandler
 * Description : Inerrupt Handler for TIM7
 * Parameters : None
 * Parameter Description : None
 * Return Type : void 
 * Return Parameter : None
 * Global Variables Used : None
 * Function Invoked : TIM_ClearITPendingBit
 **************************************************************************/
/*
void TIM7_IRQHandler(void){
	TIM_7->ITFlag = SET;
	TIM_ClearITPendingBit(TIM7, TIM_IT_Update);
}
*/







