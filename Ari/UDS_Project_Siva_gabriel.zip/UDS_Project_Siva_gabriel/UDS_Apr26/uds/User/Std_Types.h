/************************************************************
 * PROJECT: ESS_IP_UDS_Implementation_Project
 *
 * FILE NAME : Std_Types.h
 *
 * TARGET PLATFORM : STM32f107
 *
 * BUILD ENVIRONMENT : RealView MDK-ARM  Version: 4.20 
 *
 * DISCRIPTION : To implement Universal Diagnostic Services 
 *
 * VERSION : v1.0
 *
 * PLATFORM DEPENDANT [yes/no] : no
 *
 * TO BE CHANGED BY THE USER [yes/no] : no
 *	
 * CREATED BY: Chirag Juneja
 *
 * LICENSE: ARIPL SOFTWARE LICENSE
 ************************************************************/
 
#ifndef STD_TYPES_H
#define STD_TYPES_H

/*---------------------------------------- Includes ----------------------------------------*/

#include <stdint.h>

/*---------------------------------------- Booleans ----------------------------------------*/

/* E_OK, E_NOT_OK *//*
#ifndef STATUSTYPEDEFINED
#define STATUSTYPEDEFINED
#define E_OK (0x00u)
#endif
#define E_NOT_OK (0x01u)
*/
/* Pyhical States STD_HIGH,STD_LOW */
#define STD_HIGH (0x01u)
#define STD_LOW (0x00u)

/* STD_ACTIVE, STD_IDLE */
#define STD_ACTIVE (0x01u)
#define STD_IDLE (0x00u)

/* STD_ON, STD_OFF*/
#define STD_ON (0x01u)
#define STD_OFF (0x00u)


/*---------------------------------------- Typedef ----------------------------------------*/

/**************************************************************************
 * DataType : Std_ReturnType
 * Description : 	This type can be used as standard API return type 
 *							 	which is shared between the RTE and the BSW modules
 * Elements Type: uint8_t
 * Elements Discription: Return type of a function
 **************************************************************************/
//typedef uint8_t Std_ReturnType;

/**************************************************************************
 * DataType : Std_VersionInfoType
 * Description : This type shall be used to request the version of a BSW module
 * Elements Type: uint16_t
 * Elements Discription: Software Version
 **************************************************************************/
 /*
typedef struct{
	
	uint16_t 	vendorID;					// vender id
	uint16_t 	moduleID;					// module id
	uint16_t 	sw_major_version; // software version
	uint16_t 	sw_minor_version;	// software sub version
	uint16_t 	sw_patch_version;	// software patch version
	
} Std_VersionInfoType;
*/
/**************************************************************************
 * DataType : bool
 * Description : boolean to hold true of false
 * Elements Type: enum
 * Elements Discription: boolean states (true/false)
 **************************************************************************/
typedef enum {false = 0, true=!false}bool;

#endif
