#include "stm32f4xx.h"
#include "can.h"
//#include "EcuM_Cbk.h"
//#include "osek_os.h"
//#include "CanIf_Cbk.h"


#if(CAN_DEV_ERROR_DETECT == STD_ON)
//#include "Det.h"
#endif

#if ( CAN_DEV_ERROR_DETECT == STD_ON )
#define VALIDATE(_exp,_api,_err )                   \
    if( !(_exp) ) {                                 \
        Det_ReportError(MODULE_ID_CAN,0,_api,_err); \
        return E_NOT_OK;                          \
    }
#else
#define VALIDATE(_exp,_api,_err )
#endif
///////////////////////////////////////////////////////////////////////////////////
		#if ( CAN_DEV_ERROR_DETECT == STD_ON )
#define VALIDATE(_exp,_api,_err )                   \
    if( !(_exp) ) {                                 \
        Det_ReportError(MODULE_ID_CAN,0,_api,_err); \
        return E_NOT_OK;                          \
    }
#define VALIDATE_NO_RV(_exp,_api,_err )             \
    if( !(_exp) ) {                                 \
        Det_ReportError(MODULE_ID_CAN,0,_api,_err); \
        return;                                     \
    }
#define DET_REPORTERROR(_x,_y,_z,_q) Det_ReportError(_x, _y, _z, _q)
#else
#define VALIDATE(_exp,_api,_err )
#define VALIDATE_NO_RV(_exp,_api,_err )
#define DET_REPORTERROR(_x,_y,_z,_q)
#endif
Can_GlobalType Can_Global;
uint8_t BaudRate_Defined = 0x00;
uint8_t BR_SJW;
uint8_t BR_BS1;
uint8_t BR_BS2;
uint16_t BR;		
static uint8_t TransmissionAccess = ENABLE;
		
typedef CAN_TypeDef CAN_HW_t;
/* ####################### FUNCTIONs ########################### */
static uint32_t McuE_GetSystemClock(void)
{
    RCC_ClocksTypeDef clk;
    RCC_GetClocksFreq(&clk);
    return clk.SYSCLK_Frequency;
    //return clk.PCLK1_Frequency;
}

static CAN_HW_t * GetController(int unit)
{
	return ((CAN_HW_t *)(CAN1_BASE + unit*0x400));
}


// Uses 25.4.5.1 Transmission Abort Mechanism
static void Can_AbortTx( CAN_HW_t *canHw, Can_UnitType *canUnit ) {
	// Disable Transmit irq

	// check if mb's empty

	// Abort all pending mb's

	// Wait for mb's being emptied
	
	CAN_CancelTransmit(CAN2,1);
	CAN_CancelTransmit(CAN2,2);
	CAN_CancelTransmit(CAN2,3);

	
}


void Can_Init( const Can_ConfigType* config )
{
	
	CAN_FilterInitTypeDef  CAN_FilterInitStructure;

	GPIO_InitTypeDef  GPIO_InitStructure;\
	CAN_TypeDef* CANx =CAN2;
	uint32_t clock;
	uint8_t tq;
	uint8_t tqSync;
	uint8_t tq1;
	uint8_t tq2;
	uint8_t InitStatus = CAN_InitStatus_Failed;
	uint32_t wait_ack = 0x00000000;
	CAN_InitTypeDef        CAN_InitStructure;

	#if(CAN_DEV_ERROR_DETECT == STD_ON)
		if(CAN_UNINIT != Can_Global.driverState)
		{
			//Det_ReportError(MODULE_ID_CAN,0,CAN_INIT_SERVICE_ID,CAN_E_TRANSITION);
			return;
		}
		if(NULL == config)
		{
			//Det_ReportError(MODULE_ID_CAN,0,CAN_INIT_SERVICE_ID,CAN_E_PARAM_POINTER);
			return;
		}
	#endif
	Can_Global.config = config;
	Can_Global.driverState = CAN_READY;	
	
  
	/* CAN GPIOs configuration **************************************************/
	  /* Enable GPIO clock */
  RCC_AHB1PeriphClockCmd(RCC_AHB1Periph_GPIOB, ENABLE);

  /* Connect CAN pins to AF9 */
  GPIO_PinAFConfig(GPIOB, GPIO_PinSource12, GPIO_AF_CAN2);
  GPIO_PinAFConfig(GPIOB, GPIO_PinSource6, GPIO_AF_CAN2); 
  
  /* Configure CAN RX and TX pins */
  GPIO_InitStructure.GPIO_Pin = GPIO_Pin_12 | GPIO_Pin_6;
  GPIO_InitStructure.GPIO_Mode = GPIO_Mode_AF;
  GPIO_InitStructure.GPIO_Speed = GPIO_Speed_50MHz;
  GPIO_InitStructure.GPIO_OType = GPIO_OType_PP;
  GPIO_InitStructure.GPIO_PuPd  = GPIO_PuPd_UP;
  GPIO_Init(GPIOB, &GPIO_InitStructure);

  /* CAN configuration ********************************************************/  
  /* Enable CAN clock */
  RCC_APB1PeriphClockCmd(RCC_APB1Periph_CAN2, ENABLE);

	//CAN_StructInit(&CAN_InitStructure);
	clock = 42000000;//McuE_GetSystemClock()/2;
	tqSync = config->CanControllerPropSeg + 1;
	tq1 = config->CanControllerSeg1 + 1;
	tq2 = config->CanControllerSeg2 + 1;
	tq = tqSync + tq1 + tq2;

	
	//CAN_StructInit(&CAN_InitStructure);

	/* CAN cell init */
	CAN_InitStructure.CAN_TTCM=DISABLE;
	CAN_InitStructure.CAN_ABOM=DISABLE;
	CAN_InitStructure.CAN_AWUM=DISABLE;
	CAN_InitStructure.CAN_NART=DISABLE;
	CAN_InitStructure.CAN_RFLM=DISABLE;
	CAN_InitStructure.CAN_TXFP=DISABLE;
	if(config->Can_Loopback){
	  CAN_InitStructure.CAN_Mode=CAN_Mode_LoopBack;
	}else{
	  CAN_InitStructure.CAN_Mode=CAN_Mode_Normal;
	}

	if(BaudRate_Defined==0x01)
	{
		tqSync = BR_SJW + 1;
		tq1 = BR_BS1 + 1;
		tq2 = BR_BS2 + 1;
		tq = tqSync + tq1 + tq2;
		CAN_InitStructure.CAN_SJW=BR_SJW;
		CAN_InitStructure.CAN_BS1=BR_BS1;
		CAN_InitStructure.CAN_BS2=BR_BS2;
		CAN_InitStructure.CAN_Prescaler= clock/(BR*1000*tq);
	}
	else
	{
		tqSync = config->CanControllerPropSeg + 1;
		tq1 = config->CanControllerSeg1 + 1;
		tq2 = config->CanControllerSeg2 + 1;
		tq = tqSync + tq1 + tq2;
		CAN_InitStructure.CAN_SJW=config->CanControllerPropSeg;
		CAN_InitStructure.CAN_BS1=config->CanControllerSeg1;
		CAN_InitStructure.CAN_BS2=config->CanControllerSeg2;
		CAN_InitStructure.CAN_Prescaler= clock/(config->CanControllerBaudRate*1000*tq);
	}

	if(CANINITOK != CAN_Init(CANx,&CAN_InitStructure))
	{
	//return E_NOT_OK;
	}

  /* Enable FIFO 0 message pending Interrupt */
  CAN_ITConfig(CAN2, CAN_IT_FMP0, ENABLE);
	
	  /* CAN filter init */
  CAN_FilterInitStructure.CAN_FilterNumber = 14;
  CAN_FilterInitStructure.CAN_FilterMode = CAN_FilterMode_IdMask;
  CAN_FilterInitStructure.CAN_FilterScale = CAN_FilterScale_32bit;
  CAN_FilterInitStructure.CAN_FilterIdHigh = 0x0000;
  CAN_FilterInitStructure.CAN_FilterIdLow = 0x0000;
  CAN_FilterInitStructure.CAN_FilterMaskIdHigh = 0x0000;
  CAN_FilterInitStructure.CAN_FilterMaskIdLow = 0x0000;
  CAN_FilterInitStructure.CAN_FilterFIFOAssignment = 0;
  CAN_FilterInitStructure.CAN_FilterActivation = ENABLE;
  CAN_FilterInit(&CAN_FilterInitStructure);
	
	
	
	
if( config->CanRxProcessing == CAN_PROCESS_TYPE_INTERRUPT ) {
	 /* Turn on the rx interrupt */
	CAN_ITConfig(CAN2, CAN_IT_FMP0, ENABLE);
	}
	if( config->CanTxProcessing == CAN_PROCESS_TYPE_INTERRUPT ) {
	/* Turn on the tx interrupt mailboxes */
	CAN_ITConfig(CAN2, CAN_IT_TME, ENABLE);
	}

	// BusOff here represents all errors and warnings
	if( config->CanBusOffProcessing == CAN_PROCESS_TYPE_INTERRUPT ) {
	/* Turn on the bus off/tx warning/rx warning and error and rx  */
	CAN_ITConfig(CAN2, CAN_IT_BOF | CAN_IT_ERR | CAN_IT_WKU, ENABLE);
	}

		

}

void Can_Init_1( const Can_ConfigType* config )
{
	GPIO_InitTypeDef  GPIO_InitStructure;
	CAN_FilterInitTypeDef  CAN_FilterInitStructure;
	CAN_TypeDef* CANx =CAN1;
	uint32_t clock;
	uint8_t tq;
	uint8_t tqSync;
	uint8_t tq1;
	uint8_t tq2;
	uint8_t InitStatus = CAN_InitStatus_Failed;
	uint32_t wait_ack = 0x00000000;
	CAN_InitTypeDef        CAN_InitStructure;

	#if(CAN_DEV_ERROR_DETECT == STD_ON)
		if(CAN_UNINIT != Can_Global.driverState)
		{
			//Det_ReportError(MODULE_ID_CAN,0,CAN_INIT_SERVICE_ID,CAN_E_TRANSITION);
			return;
		}
		if(NULL == config)
		{
			//Det_ReportError(MODULE_ID_CAN,0,CAN_INIT_SERVICE_ID,CAN_E_PARAM_POINTER);
			return;
		}
	#endif
	Can_Global.config = config;
	Can_Global.driverState = CAN_READY;	
	
  
	/* CAN GPIOs configuration **************************************************/
	  /* Enable GPIO clock */
  RCC_AHB1PeriphClockCmd(RCC_AHB1Periph_GPIOB, ENABLE);

  /* Connect CAN pins to AF9 */
  GPIO_PinAFConfig(GPIOB, GPIO_PinSource8, GPIO_AF_CAN2);
  GPIO_PinAFConfig(GPIOB, GPIO_PinSource9, GPIO_AF_CAN2); 
  
  /* Configure CAN RX and TX pins */
  GPIO_InitStructure.GPIO_Pin = GPIO_Pin_8 | GPIO_Pin_9;
  GPIO_InitStructure.GPIO_Mode = GPIO_Mode_AF;
  GPIO_InitStructure.GPIO_Speed = GPIO_Speed_50MHz;
  GPIO_InitStructure.GPIO_OType = GPIO_OType_PP;
  GPIO_InitStructure.GPIO_PuPd  = GPIO_PuPd_UP;
  GPIO_Init(GPIOB, &GPIO_InitStructure);

  /* CAN configuration ********************************************************/  
  /* Enable CAN clock */
  RCC_APB1PeriphClockCmd(RCC_APB1Periph_CAN1, ENABLE);

	//CAN_StructInit(&CAN_InitStructure);
	clock = 42000000;//McuE_GetSystemClock()/2;
	tqSync = config->CanControllerPropSeg + 1;
	tq1 = config->CanControllerSeg1 + 1;
	tq2 = config->CanControllerSeg2 + 1;
	tq = tqSync + tq1 + tq2;

	
	//CAN_StructInit(&CAN_InitStructure);

	/* CAN cell init */
	CAN_InitStructure.CAN_TTCM=DISABLE;
	CAN_InitStructure.CAN_ABOM=DISABLE;
	CAN_InitStructure.CAN_AWUM=DISABLE;
	CAN_InitStructure.CAN_NART=DISABLE;
	CAN_InitStructure.CAN_RFLM=DISABLE;
	CAN_InitStructure.CAN_TXFP=DISABLE;
	if(config->Can_Loopback){
	  CAN_InitStructure.CAN_Mode=CAN_Mode_LoopBack;
	}else{
	  CAN_InitStructure.CAN_Mode=CAN_Mode_Normal;
	}

	if(BaudRate_Defined==0x01)
	{
		CAN_InitStructure.CAN_SJW=BR_SJW;
		CAN_InitStructure.CAN_BS1=BR_BS1;
		CAN_InitStructure.CAN_BS2=BR_BS2;
		CAN_InitStructure.CAN_Prescaler= clock/(BR*1000*tq);
	}
	else
	{
		CAN_InitStructure.CAN_SJW=config->CanControllerPropSeg;
		CAN_InitStructure.CAN_BS1=config->CanControllerSeg1;
		CAN_InitStructure.CAN_BS2=config->CanControllerSeg2;
		CAN_InitStructure.CAN_Prescaler= clock/(config->CanControllerBaudRate*1000*tq);
	}

	if(CANINITOK != CAN_Init(CANx,&CAN_InitStructure))
	{
	//return E_NOT_OK;
	}
  /* CAN filter init */
  CAN_FilterInitStructure.CAN_FilterNumber = 14;
  CAN_FilterInitStructure.CAN_FilterMode = CAN_FilterMode_IdMask;
  CAN_FilterInitStructure.CAN_FilterScale = CAN_FilterScale_32bit;
  CAN_FilterInitStructure.CAN_FilterIdHigh = 0x0000;
  CAN_FilterInitStructure.CAN_FilterIdLow = 0x0000;
  CAN_FilterInitStructure.CAN_FilterMaskIdHigh = 0x0000;
  CAN_FilterInitStructure.CAN_FilterMaskIdLow = 0x0000;
  CAN_FilterInitStructure.CAN_FilterFIFOAssignment = 0;
  CAN_FilterInitStructure.CAN_FilterActivation = ENABLE;
  CAN_FilterInit(&CAN_FilterInitStructure);
  

  /* Enable FIFO 0 message pending Interrupt */
  CAN_ITConfig(CAN2, CAN_IT_FMP0, ENABLE);
	
	
if( config->CanRxProcessing == CAN_PROCESS_TYPE_INTERRUPT ) {
	 /* Turn on the rx interrupt */
	CAN_ITConfig(CAN2, CAN_IT_FMP0, ENABLE);
	}
	if( config->CanTxProcessing == CAN_PROCESS_TYPE_INTERRUPT ) {
	/* Turn on the tx interrupt mailboxes */
	CAN_ITConfig(CAN2, CAN_IT_TME, ENABLE);
	}

	// BusOff here represents all errors and warnings
	if( config->CanBusOffProcessing == CAN_PROCESS_TYPE_INTERRUPT ) {
	/* Turn on the bus off/tx warning/rx warning and error and rx  */
	CAN_ITConfig(CAN2, CAN_IT_BOF | CAN_IT_ERR | CAN_IT_WKU, ENABLE);
	}

}

#if(CAN_VERSIONINFO_API	== STD_ON)
	

void Eep_GetVersionInfo (Std_VersionInfoType* versioninfo)
{	
    
	if(NULL == versioninfo)
	{
	    #if (CAN_DEV_ERROR_DETECT == STD_ON)
		   
	   /* Report to DET */
	   //(void)Det_ReportError(CAN_MODULE_ID, CAN_INSTANCE_ID, CAN_GETVERSIONINFO_SID,CAN_E_PARAM_POINTER);
        #endif	
		
	}
	else
	{
	/* Copy the vendor Id */
    versioninfo->vendorID = (uint16_t)CAN_VENDOR_ID;
    /* Copy the module Id */
    versioninfo->moduleID = (uint16_t)CAN_MODULE_ID;
    /* Copy Software Major Version */
    versioninfo->sw_major_version = CAN_SW_MAJOR_VERSION;
    /* Copy Software Minor Version */
    versioninfo->sw_minor_version = CAN_SW_MINOR_VERSION;
    /* Copy Software Patch Version */
    versioninfo->sw_patch_version = CAN_SW_PATCH_VERSION;
	}
 
}

#endif

void Can_DeInit( void )
{
	Can_Global.config = 0;//NULL
	Can_Global.driverState = CAN_UNINIT;
	Can_Global.canUnit->state = CANIF_CS_UNINIT;
	CAN_DeInit(CAN2);
}

void Can_DisableControllerInterrupts( uint8_t Controller )
{
	  /* Turn off the tx interrupt mailboxes */
	   CAN_ITConfig(CAN2, CAN_IT_TME, DISABLE);

	   /* Turn off the bus off/tx warning/rx warning and error and rx  */
	   CAN_ITConfig(CAN2, CAN_IT_FMP0 | CAN_IT_BOF | CAN_IT_ERR | CAN_IT_WKU, DISABLE);

}

void Can_EnableControllerInterrupts( uint8_t Controller )
{
	  /* Turn off the tx interrupt mailboxes */
	   CAN_ITConfig(CAN2, CAN_IT_TME, ENABLE);

	   /* Turn off the bus off/tx warning/rx warning and error and rx  */
	   CAN_ITConfig(CAN2, CAN_IT_FMP0 | CAN_IT_BOF | CAN_IT_ERR | CAN_IT_WKU, ENABLE);
	  
}


Std_ReturnType Can_GetControllerErrorState( uint8_t ControllerId, Can_ErrorStateType* ErrorStatePtr )
{
	if(CAN2->ESR & 0x0002)
	{
		*ErrorStatePtr = CAN_ERRORSTATE_PASSIVE;
	}else if(CAN2->ESR & 0x0004)
	{
		*ErrorStatePtr = CAN_ERRORSTATE_BUSOFF;
	}else
	{
		*ErrorStatePtr = CAN_ERRORSTATE_ACTIVE;
	}
	if(CAN_UNINIT != Can_Global.driverState)
		{
			
			return E_OK;
		}
		else{
			return E_NOT_OK;
		}
	
}
Std_ReturnType Can_GetControllerMode( uint8_t Controller, Can_ControllerStateType* ControllerModePtr )
{
	*ControllerModePtr= Can_Global.canUnit->state;
	if(CAN_UNINIT != Can_Global.driverState)
	{
		
		return E_OK;
	}
	else{
		return E_NOT_OK;
	}
}

Std_ReturnType Can_Write( Can_HwHandleType Hth, const Can_PduType* pduInfo )
{
	

	  Std_ReturnType rv = E_OK;
	  CAN_HW_t *canHw;
	  const Can_HardwareObjectType *hohObj;
	 
	 CanTxMsg TxMessage;

  TxMessage.StdId = pduInfo->id;
//TxMessage.ExtId = 0x00;
    TxMessage.RTR = CAN_RTR_DATA;
	TxMessage.IDE = CAN_ID_STD;
   //  TxMessage.DLC = 1;

	  //TxMessage.RTR=CAN_RTR_DATA;
	  TxMessage.DLC=pduInfo->length;

	  memcpy(TxMessage.Data, pduInfo->sdu, pduInfo->length);
		
/*
	  if (hohObj->CanIdType == CAN_ID_TYPE_EXTENDED) {
		TxMessage.IDE=CAN_ID_EXT;
		TxMessage.ExtId=pduInfo->id;
	  } else {
		TxMessage.IDE=CAN_ID_STD;
		TxMessage.StdId=pduInfo->id;
	  }
		
		*/
 if(TransmissionAccess)CAN_Transmit(CAN2,&TxMessage);
	  // check for any free box
	  //if(CAN_Transmit(canHw,&TxMessage) != CAN_NO_MB) {
	    //canHwConfig = CAN_GET_CONTROLLER_CONFIG(Can_Global.channelMap[controller]);

//	    if( canHwConfig->CanTxProcessing == CAN_PROCESS_TYPE_INTERRUPT ) {
//	  	  /* Turn on the tx interrupt mailboxes */
//	    	CAN_ITConfig(canHw,CAN_IT_TME, ENABLE);
//	    }

		// Increment statistics
		//canUnit->stats.txSuccessCnt++;

	    // Store pdu handle in unit to be used by TxConfirmation
	    //canUnit->swPduHandle = pduInfo->swPduHandle;
	 //} else {
	    //rv = CAN_BUSY;
	 // }
	  //Irq_Restore(state);

	  return rv;
}




Std_ReturnType Can_SetControllerMode( uint8_t controller, Can_StateTransitionType Transition )
{
	Std_ReturnType rv = E_OK;
	CAN_HW_t *canHw;
	Can_UnitType *canUnit = CAN_GET_PRIVATE_DATA(controller);
	 switch(Transition )
	  {
	  case CAN_T_START:
						canUnit->state = CANIF_CS_STARTED;
					  CAN_OperatingModeRequest(CAN2,CAN_OperatingMode_Normal); 
		
						break;
		case CAN_T_WAKEUP:
						canUnit->state = CANIF_CS_STOPPED;
					//	CAN_WakeUp(canHw);
					CAN_OperatingModeRequest(CAN2,CAN_OperatingMode_Normal);
						break;
		
		case CAN_T_SLEEP: 
						canUnit->state = CANIF_CS_SLEEP;//CAN_OperatingMode_Sleep
						//	CAN_OperatingModeRequest(CAN2,CAN_OperatingMode_Sleep); // this is for long sleep 
						CAN_Sleep(canHw);//controller
		
						break;
		
		 case CAN_T_STOP:
						canUnit->state = CANIF_CS_STOPPED;
						CAN_OperatingModeRequest(CAN2,CAN_OperatingMode_Sleep);
					//	Can_AbortTx( canHw, canUnit ); // CANIF282
						break;	
		
	}
		
	Can_Global.canUnit->state = canUnit->state;
		return rv;

	
}


Std_ReturnType Can_SetBaudrate( uint8_t Controller, uint16_t BaudRateConfigID )
{
  if(Can_Global.canUnit->state == CANIF_CS_STOPPED)
	{
		BaudRate_Defined = 0x01;
		switch(BaudRateConfigID )
	  {
			case CAN_BR_1MBPS:
						BR_SJW = 0x00;
		        BR_BS1 = 13;
						BR_BS2 = 5;
						BR = 1000;
					break;
			case CAN_BR_500KBPS:
						BR_SJW = 0x00;
		        BR_BS1 = 12;
						BR_BS2 = 6;
						BR = 500;
			break;
		}
	}
	return E_OK;
}

void Can_SetTransmissionAccess(uint8_t accesstype){
	TransmissionAccess = accesstype;
}
Std_ReturnType Can_CheckWakeup( uint8_t Controller )
{
	if((CAN2->MSR & CAN_MSR_RX)!=0x00)
	{
		Can_SetControllerMode(CAN_CTRL_2,CAN_T_START);
		CAN_WakeUp(CAN2);
		return E_OK;
	}
	else
		return E_NOT_OK;
	
}
void Can_MainFunction_Write( void )
{
	if((CAN2->TSR & CAN_TSR_RQCP1)&&(CAN2->TSR & CAN_TSR_TXOK1)&& (CAN2->TSR & CAN_TSR_TME))
	{
		
	}
	
	
}

void Can_MainFunction_Read( void )
{
	
}

void Can_MainFunction_BusOff( void )
{
	
}

void Can_MainFunction_Wakeup( void )
{
	
}

void Can_MainFunction_Mode( void )
{
	
}

