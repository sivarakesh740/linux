/************************************************************
 * PROJECT: ESS_IP_UDS_Implementation_Project
 *
 * FILE NAME : Tim_api.h
 *
 * TARGET PLATFORM : STM32f107
 *
 * BUILD ENVIRONMENT : RealView MDK-ARM  Version: 4.20 
 *
 * DISCRIPTION : Header for Timer API
 *
 * VERSION : v1.0
 *
 * PLATFORM DEPENDANT [yes/no] : yes
 *
 * TO BE CHANGED BY THE USER [yes/no] : no
 *	
 * CREATED BY: Chirag Juneja
 *
 * LICENSE: ARIPL SOFTWARE LICENSE
 ************************************************************/
 


#ifndef TIM_API_H
#define TIM_API_H

/*---------------------------------------- Includes ----------------------------------------*/

#include "stm32f4xx.h"
#include "stm32f4xx_tim.h"
#include "stm32f4xx_rcc.h"

/*---------------------------------------- Data Types ----------------------------------------*/

typedef struct {

	TIM_TypeDef* TIM_Type;
	uint8_t IRQHandler;
	uint32_t Clock;
	volatile FlagStatus ITFlag;
	TIM_TimeBaseInitTypeDef TIM_Setup;

}Timer;

/*---------------------------------------- Function Prototypes ----------------------------------------*/

void TIM_Init(Timer* TIM_x);
void TIM_delayms(Timer* TIM_x,uint16_t Nms);
void TIM_delayus(Timer* TIM_x,uint16_t Nus);
void TIM_counterms(Timer* TIM_x,uint16_t Nms);

#endif

/*---------------------------------------- End Of File ----------------------------------------*/







