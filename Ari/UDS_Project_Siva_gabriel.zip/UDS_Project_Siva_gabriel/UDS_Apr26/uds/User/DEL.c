/************************************************************
 * PROJECT: ESS_IP_UDS_Implementation_Project
 *
 * FILE NAME : DEL.c
 *
 * TARGET PLATFORM : STM32f107
 *
 * BUILD ENVIRONMENT : RealView MDK-ARM  Version: 4.20 
 *
 * DISCRIPTION : EEPROM Data Extraction Layer for UDS 
 *
 * VERSION : v1.0
 *
 * PLATFORM DEPENDANT [yes/no] : no
 *
 * TO BE CHANGED BY THE USER [yes/no] : no
 *	
 * CREATED BY: Chirag Juneja
 *
 * LICENSE: ARIPL SOFTWARE LICENSE
 ************************************************************/
 
/*---------------------------------------- Includes ----------------------------------------*/

#include "DEL.h"

/*---------------------------------------- Global Variables ----------------------------------------*/

static IdentifierMap IdentifierLookup[12]; 
static uint8_t dataBuffer[32];
static uint8_t readBuffer[32];
static uint8_t memory[32];
//static uint8_t* readBufferPtr = readBuffer;
//static uint8_t* dataBufferPtr = dataBuffer;
static uint8_t identifierCount;
static uint8_t fetchBuffer[32];

/*---------------------------------------- Function Definations ----------------------------------------*/
#ifndef EEP_H_

uint32_t Eep_Read(uint32_t memoryAddress,uint8_t Length,uint8_t *DataBufferPtr){
	int counter;
	if ((memoryAddress+Length)>32)
			return FAILED;
	for(counter=memoryAddress;counter<(memoryAddress+Length);counter++){
		DataBufferPtr[counter-memoryAddress]=memory[counter];
	}
	return SUCCESS;
}

uint32_t Eep_Write(uint32_t memoryAddress,uint8_t Length,uint8_t *DataBufferPtr){
	int counter;
	if ((memoryAddress+Length)>32)
			return FAILED;
	for(counter=memoryAddress;counter<(memoryAddress+Length);counter++)
		memory[counter]=DataBufferPtr[counter-memoryAddress];
	return SUCCESS;
}


#endif
/**************************************************************************
 * Function 							: DEL_identifierInit
 * Description 						: Initialize Identifier Lookup Table
 * Parameters 						: None
 * Parameter Description 	: None
 * Return Type 						: void 
 * Return Parameter 			: None 
 * Global Variables Used 	: IdentifierLookup, identifierCount
 * Function Invoked 			: None 
 **************************************************************************/

void DEL_identifierInit(void){
	IdentifierLookup[0].id = ECU_SERIAL_NUMBER_DATA_ID;
	IdentifierLookup[0].size = 4;
	IdentifierLookup[0].address = 0x00;
	IdentifierLookup[1].id = ENGINE_PARAMETERS_DATA_ID;
	IdentifierLookup[1].size = 17;
	IdentifierLookup[1].address = 0x6;
	IdentifierLookup[2].id = ECU_SOFTWARE_VERSION_DATA_ID; 
	IdentifierLookup[2].size = 2;
	IdentifierLookup[2].address = 0x04;
	IdentifierLookup[3].id = ENGINE_INJECTION_DATA_ID;
	IdentifierLookup[3].size = 8;
	IdentifierLookup[3].address = 0x0F;
	identifierCount = 4;
}

uint8_t*  DEL_fetchIdentifierData(uint8_t address, uint8_t size, uint8_t* fetchPointer){
	uint8_t counter;
	if(Eep_Read(address,size,fetchPointer)){
		for(counter=0;counter<size;counter++)fetchPointer[size-counter]=fetchPointer[size-counter-1];
		fetchPointer[0]=size;
	}
	else fetchPointer = null;
	return fetchPointer;
}

uint8_t* DEL_ReadDataById(uint16_t dataId,uint8_t* fetchPointer){
	uint8_t counter;
	uint8_t request = FAILED;
	static uint8_t dataBuffer[32]={0};
	fetchPointer = dataBuffer;
	for(counter=0;counter<identifierCount;counter++){
		if(IdentifierLookup[counter].id==dataId){
			fetchPointer = DEL_fetchIdentifierData(IdentifierLookup[counter].address,IdentifierLookup[counter].size,fetchPointer);
			request = SUCCESS;
		}	
	}
	if(!request)fetchPointer=null;
	return fetchPointer;
}

/*---------------------------------------- Write Data By ID ----------------------------------------*/

uint8_t DEL_setIdentifierData(uint8_t address, uint8_t size, uint8_t* dataBufferPointer){
	if(Eep_Write(address,size,dataBufferPointer))return 0x00;
	else return NRC_GENERAL_PROGRAMMING_FALIURE;
}

uint8_t DEL_WriteDataById(uint16_t dataId, uint8_t dataLength, uint8_t* dataBufferPointer){
	uint8_t NRC = NRC_REQUEST_OUT_OF_RANGE;
	uint8_t counter;
	for(counter=0;counter<identifierCount;counter++){
		if(IdentifierLookup[counter].id==dataId){
			if(IdentifierLookup[counter].size==dataLength){
			NRC=DEL_setIdentifierData(IdentifierLookup[counter].address,IdentifierLookup[counter].size,dataBufferPointer);
			}else NRC = NRC_INVALID_FORMAT;	
		}
	}
	return NRC;
}
/*---------------------------------------- Read Memory By Address ----------------------------------------*/

void DEL_MemoryInit(void){
	
	/*
	Address Map for ECU Parameters
	ECUSerialNo = 0x00;
	ECUSofwareVersion = 0x04;
	EngineSpeed = 0x06; 
	EngineTemp = 0x08;	
	EngineTorque = 0x0A;	
	EngineValvePos = 0xC;	
	EnginePressure = 0xD; 
	EngineFuelInjection1 = 0x0F; 
	EngineFuelInjection2 = 0x13; 
	*/
	/*
	Engine ECM Parameter Values 
	ECUSerialNo = 0xF5689A07u;
	ECUSofwareVersion = 0x0357u;
	EngineSpeed = 0x4F58; 
	EngineTemp = 0x0987;	
	EngineTorque = 0x0583;	
	EngineValvePos = 0xB0;	
	EnginePressure = 0xF592; 
	EngineFuelInjection1 = 0x0C65F8A9; 
	EngineFuelInjection2 = 0x0C65E5D5; 
	*/
	dataBuffer[0] = 0xF5;
	dataBuffer[1] = 0x68;
	dataBuffer[2] = 0x9A;
	dataBuffer[3] = 0x07;
	dataBuffer[4] = 0x03;
	dataBuffer[5] = 0x57;
	dataBuffer[6] = 0x4F;
	dataBuffer[7] = 0x58;
	dataBuffer[8] = 0x09;
	dataBuffer[9] = 0x87;
	dataBuffer[10] = 0x05;
	dataBuffer[11] = 0x83;
	dataBuffer[12] = 0xB0;
	dataBuffer[13] = 0xF5;
	dataBuffer[14] = 0x92;
	dataBuffer[15] = 0x0C;
	dataBuffer[16] = 0x65;
	dataBuffer[17] = 0xF8;
	dataBuffer[18] = 0xA9;
	dataBuffer[19] = 0x0C;
	dataBuffer[20] = 0x65;
	dataBuffer[21] = 0xE5;
	dataBuffer[22] = 0xD5;
	Eep_Write(0X00,23,dataBuffer);
	Eep_Read(0X00,23,readBuffer);
	if(readBuffer[0]!=dataBuffer[0]){
	while(1);
	}
}

void DEL_ReadMemoryByAddress(uint16_t address,uint8_t size,uint8_t* fetchPointer){
	static uint8_t fetchBuffer[32]={0};
	fetchPointer = fetchBuffer;

		if(!Eep_Read(address,size,fetchPointer))fetchPointer =null;
}

/*---------------------------------------- Write Memory By Address ----------------------------------------*/
uint8_t DEL_WriteMemoryByAddress(uint16_t address, uint8_t size, uint8_t* dataPointer){
	
		if(Eep_Write(address,size,dataPointer))return SUCCESS;
		else return FAILED;
}
