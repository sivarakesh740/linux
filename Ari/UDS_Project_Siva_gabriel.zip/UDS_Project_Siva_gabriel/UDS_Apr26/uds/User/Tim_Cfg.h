/************************************************************
 * PROJECT: ESS_IP_UDS_Implementation_Project
 *
 * FILE NAME : Tim_Cfg.h
 *
 * TARGET PLATFORM : STM32f107
 *
 * BUILD ENVIRONMENT : RealView MDK-ARM  Version: 4.20 
 *
 * DISCRIPTION : Header file for Timer configuration file
 *
 * VERSION : v1.0
 *
 * PLATFORM DEPENDANT [yes/no] : yes
 *
 * TO BE CHANGED BY THE USER [yes/no] : no
 *	
 * CREATED BY: Chirag Juneja
 *
 * LICENSE: ARIPL SOFTWARE LICENSE
 ************************************************************/
 
#ifndef TIM_Cfg_h
#define TIM_Cfg_h


/*---------------------------------------- Includes ----------------------------------------*/

#include "stm32f4xx.h"
#include "Tim_api.h"

/*---------------------------------------- Macros ----------------------------------------*/


#define TIM_MS_PRESCALER 10 // prescalar for microsecond precision
#define TIM_MS_PERIOD 1000	// period of 1000 microsecond 
#define TIM_US_PRESCALER 1
#define TIM_US_PERIOD 10 //
#define TIM_MS_REPITITION_COUNT 0 // repitition count for millisecond counter

/*---------------------------------------- Global Variables ----------------------------------------*/

extern Timer* TIM_2;
extern Timer* TIM_3;
extern Timer* TIM_4;
extern Timer* TIM_5;
extern Timer* TIM_6;
extern Timer* TIM_7;


#endif
