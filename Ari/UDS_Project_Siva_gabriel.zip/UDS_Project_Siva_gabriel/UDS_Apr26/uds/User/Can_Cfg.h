#include "stm32f4xx.h"
#include "can.h"
extern Can_ConfigType CntrConfig1;
extern Can_ConfigType CntrConfig2;
extern Can_ConfigType Trans;
extern Can_PduType Can_buf;
//extern str;

