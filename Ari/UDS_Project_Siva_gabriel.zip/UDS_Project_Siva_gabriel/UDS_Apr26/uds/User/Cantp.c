#include <stdlib.h>
#include <stdint.h>
#include <stdio.h>
#include "Cantp.h"
#include "Can_Cfg.h"
#include "CANTP_Timer.h"

static Can_PduType CanTp_Canbuf;
static uint8_t multiframeTxLength;
static uint8_t multiframeRxLength;
static uint8_t Tp_MultiframeRxBuffer[64];
static uint8_t Tp_MultiframeTxBuffer[8][8];
static uint8_t page=0;
static uint32_t CanTp_TimeFactor;
static uint8_t CanTp_Timer=0;
static uint8_t finalFrameTxLength=0;
static uint8_t index;
static CanTxMsg TxControlFlow;
static uint16_t frameNumber;
static uint16_t blockSize = 0;
static uint32_t STMin_ms = 127;
static uint8_t Tp_Uds_MultiframeRxBuffer[64];

void CanTp_TimerInit(){
	
	/* initialize the counter */
	CanTp_TimeFactor = STMin_ms; 
	TIM_TIxExternalClockConfig(TIM4, TIM_TIxExternalCLK1Source_TI1, TIM_ICPolarity_Rising, 0x2);
	TIM_ITConfig(TIM4,TIM_IT_CC1,1);
	
	/* set session timer */
	//TIM_SetAutoreload(TIM3,CanTp_TimeFactor*1000);			
	TIM_SetCounter(TIM4, 0);		// clear current count
	TIM_Cmd(TIM4, 1);		// start the timer
}

void CanTp_TimerUpdate(){
	
	if(CanTp_Timer==4){
		TIM_ITConfig(TIM4, TIM_IT_CC1,0);
		CanTp_Timer=0;
		
		CanTp_Tx(Tp_Uds_MultiframeRxBuffer);	
	}
	
	else{
		TIM_SetAutoreload(TIM4,CanTp_TimeFactor*1000);
		TIM_SetCounter(TIM4, 0);
		TIM_Cmd(TIM4, 1);	
		CanTp_Timer++;
	}
}
void CanTp_Timer_Handler(void){
		
		CanTp_TimerUpdate();
}


void CanTp_controlFlowFrameHandler(CanRxMsg* RxMessagePtr){
	CanTp_TimerInit();
	for(index=1;index<=page;index++){
		if(index==page)CanTp_Canbuf.length=finalFrameTxLength+2;
		else CanTp_Canbuf.length=8;
		CanTp_Canbuf.sdu = Tp_MultiframeTxBuffer[index];
		//	CanTp_delay_us(STMin_ms*1000);
		Can_Write(0x0FF,&CanTp_Canbuf);
	}
}

void CanTp_multiFrameTxHandler(uint8_t* ResponseBufferPtr){
	multiframeTxLength = ResponseBufferPtr[0]+1;

	for(index=0;index<multiframeTxLength;index++)
	{
		page=index/7;
		finalFrameTxLength=index%7;
		Tp_MultiframeTxBuffer[page][finalFrameTxLength+1] = ResponseBufferPtr[index];
	}
	for(index=1;index<8;index++)Tp_MultiframeTxBuffer[index][0]=0x20u+index;
	
	Tp_MultiframeTxBuffer[0][0]=0x10u;
	CanTp_Canbuf.length=8;
	CanTp_Canbuf.sdu = Tp_MultiframeTxBuffer[0];
	Can_Write(0x0FF,&CanTp_Canbuf);
}

void CanTp_Tx(uint8_t* ResponseBufferPtr)
	{
		CanTp_Canbuf.id = UDS_TX_ID;
		if(ResponseBufferPtr[0]<7)
			{
			CanTp_Canbuf.length = ResponseBufferPtr[0]+1;
			CanTp_Canbuf.sdu = ResponseBufferPtr;
			Can_Write(0x0FF,&CanTp_Canbuf);
		  }
		else CanTp_multiFrameTxHandler(ResponseBufferPtr);
}

void CanTp_TxInvalidFormat(CanRxMsg* RxMessagePtr)
{
		CanTp_Canbuf.id = UDS_TX_ID;
		CanTp_Canbuf.length = (RxMessagePtr->Data[0]&0x0F)+0x01;
		CanTp_Canbuf.sdu = RxMessagePtr->Data;
		CanTp_Canbuf.sdu[(RxMessagePtr->Data[0]&0x0F)]=NRC_INVALID_FORMAT; 
		Can_Write(0x0FF,&CanTp_Canbuf);
}


void CanTp_Rx(CanRxMsg* RxMessagePtr)
{
	switch(RxMessagePtr->Data[0] & 0xF0)
	{
		case SINGLE_FRAME   : CanTp_singleFrameHandler(RxMessagePtr);break;
		case FIRST_FRAME    : CanTp_firstFrameRxHandler(RxMessagePtr);break;
		case FLOW_CONTROL_FRAME : CanTp_controlFlowFrameHandler(RxMessagePtr);break;
		case CONSECUTIVE_FRAME  : CanTp_consecutiveFrameHandler(RxMessagePtr);break;
	}
}

void  CanTp_singleFrameHandler(CanRxMsg* RxMessagePtr)
{
		UDS_ServiceRequest(RxMessagePtr->Data);
}

void CanTp_firstFrameRxHandler(CanRxMsg* RxMessagePtr)
{
	uint8_t counter;
	for(counter=0;counter<6;counter++)Tp_MultiframeRxBuffer[counter] = RxMessagePtr->Data[counter+1];
	multiframeRxLength = (RxMessagePtr->Data[0]&0x0F)+RxMessagePtr->Data[1];
	CanTp_TxControlFlow();
	frameNumber = 0;
	multiframeRxLength -= 6;
}

void CanTp_TxControlFlow(void)
{
	CanTp_Canbuf.id = UDS_TX_ID;
	CanTp_Canbuf.length = 0x03;
	CanTp_Canbuf.sdu[0] = 0x30;
	CanTp_Canbuf.sdu[1] = blockSize;
	CanTp_Canbuf.sdu[2] = 0; //STMin_ms;
	Can_Write(0x0FF,&CanTp_Canbuf);
}

void CanTp_consecutiveFrameHandler(CanRxMsg* RxMessagePtr)
{
	uint8_t counter;
	frameNumber++;
	if(multiframeRxLength>0)
		{
	for(counter=0;counter<7;counter++)
			{
					Tp_MultiframeRxBuffer[frameNumber*7+counter] = RxMessagePtr->Data[counter+1];
    	}
		multiframeRxLength -= 7;
	 }
	if(multiframeRxLength <=0)UDS_ServiceRequest(Tp_MultiframeRxBuffer);
}
	



