/************************************************************
 * PROJECT: ESS_IP_UDS_Implementation_Project
 *
 * FILE NAME : Uds.c
 *
 * TARGET PLATFORM : STM32f107
 *
 * BUILD ENVIRONMENT : RealView MDK-ARM  Version: 4.20 
 *
 * DISCRIPTION : To implement Universal Diagnostic Services 
 *
 * VERSION : v1.0
 *
 * PLATFORM DEPENDANT [yes/no] : no
 *
 * TO BE CHANGED BY THE USER [yes/no] : no
 *	
 * CREATED BY: M Kumar Yadav
 *
 * LAST MODIFIED BY : Chirag Juneja
 *
 * LICENSE: ARIPL SOFTWARE LICENSE
 ************************************************************/
 
/** @tagSettings DEFAULT_ARCHITECTURE=PPC|STM32f107  */
/** @reqSettings DEFAULT_SPECIFICATION_REVISION=4.1.2 */
/* REQUIREMENTS
 * - EEP060
 *   Only EEP_WRITE_CYCLE_REDUCTION = STD_OFF is supported
 *
 * - EEP075
 *   MEMIF_COMPARE_UNEQUAL does not exist in the MemIf specification 1.2.1(rel 3.0 )
 *   So, it's not supported. It returns MEMIF_JOB_FAILED instead.
 *
 * - EEP084
 *   EepJobCallCycle not used
 *   We are not using interrupts so EEP_USE_INTERRUPTS must be STD_OFF
 */
 
/*************************************************************************************
**                      Revision History                                     				**
**************************************************************************************
** Revision  Date           Changed By             Description               				**
**************************************************************************************
** 1.0.0     20-July-2018   M Kumar Yadav       Initial version               			 *
** 2.0.0		 08-Sept-2018		Poornima						Modified read/write data at Address	 *
** 3.0.0		 09-Sept-2018		Chirag Juneja				Modified for UDS Implemenation			 *
**************************************************************************************/


/******************************************************************************
**                      Include Section                                      **
******************************************************************************/
#include "MemIfTypes.h"
#include "Eep.h"
#include "Eep_ConfigTypes.h"
#include "stm32f10x.h"
#include "stm32f10x_gpio.h"
#include "stm32f10x_i2c.h"
#include "24C02.h"
#include "Std_Types.h"
#include <stdlib.h>
#include <string.h>
#include "Eep_Types.h"

/******************************************************************************

**                      Global Variable Declarations                          *

*******************************************************************************/
  uint32_t  Eep_GddModuleState;
  uint32_t  Eep_GddJobResult;
  uint32_t	Eep_GusJobStage;
  uint16_t  Eep_GusLddErr;
  uint32_t  Eep_GddMode;
  uint32_t  Eep_GddCancelCmdReceive;
	uint8_t 	readDataBufferPtr[32];
	uint8_t 	DataBufferPtr[128]={0};
	uint8_t 	byte_cnt;
	uint8_t 	buf[5]={0x55,0x23,0x23,0x45,0x46};
	uint8_t 	addr;
	uint8_t 	*ptr=&addr;

/******************************************************************************

**                      Global Type Definitions                               *

******************************************************************************/
 Eep_GlobalType Eep_JobsOP;
 Eep_GlobalType  Eep_PageSetupJob;
 Eep_GlobalType  EepInitConfiguration;
 
/******************************************************************************/
/*                      Function Definitions                                  */
/*******************************************************************************/
/******************************************************************************
** Function Name                : Eep_Init
**
** Service ID                   : 0x00
**
** Description                  : Service for EEPROM initialization
**                         
** Sync/Async                   : Synchronous
**
** Re-entrancy                  : Non Reentrant
**
** Input Parameters             : ConfigPtr
**
** Parameter Description        : Config Structure type pointer
**
** InOut Parameters             : None
**
** Output Parameters            : None
**
** Return parameter             : None
**
** Preconditions                : None
**
** Global Variables             : Eep_GddModuleState,EepInitConfiguration,
**                                Eep_GddJobResult
**
** Functions invoked            : I2C_Configuration( ), Eep_SetMode( )
**
** Registers Used               : None
**
******************************************************************************/

void Eep_Init(const Eep_ConfigType  *ConfigPtr)
		{

				EepInitConfiguration.config = ConfigPtr;
				/* initialize Module State */
				Eep_GddModuleState=MEMIF_BUSY_INTERNAL;
				/* Initializing i2c Module*/
				I2C_Configuration();
				/* after completing i2c intialization, initialize Module State as IDLE */
				Eep_GddModuleState = MEMIF_IDLE;
				/* initialize Job result */
				Eep_GddJobResult=MEMIF_JOB_OK;
				/*setting slow mode as default eeprom mode*/
				Eep_SetMode(MEMIF_MODE_SLOW);
				/*making the execution state of eep main function as idle*/
				Eep_GusJobStage = EEP_JOB_IDLE;
				//Eep_Write(0X00,128,DataBufferPtr);
		}

/******************************************************************************
** Function Name                 : Eep_SetMode
**
** Service ID                    : 0x01
**
** Description                   : Sets the mode
**                         
**
** Sync/Async                    : Synchronous
**
** Re-entrancy                   : Non Reentrant
**
** Input Parameters              : Mode
**
** Parameter Description         : Enum type parameter
**
** InOut Parameters              : None
**
** Output Parameters             : None
**
** Return parameter              : None
**
** Preconditions                 : None
**
** Global Variables              : Eep_GddMode,Eep_GddModuleState
**
** Functions invoked             : None
**
** Registers Used                : None
**
******************************************************************************/

void Eep_SetMode (MemIf_ModeType Mode )
{   

				if(MEMIF_UNINIT == Eep_GddModuleState)
					{

					#if (EEP_DEV_ERROR_DETECT == STD_ON)

					/* Report to DET */
					(void)Det_ReportError(EEP_MODULE_ID, EEP_INSTANCE_ID, EEP_SETMODE_SID, EEP_E_UNINIT);
					#endif
						

					} 
				else
					{
					/* Check if the module is Busy with some other request */
					if(MEMIF_BUSY == Eep_GddModuleState)
					{
					#if (EEP_DEV_ERROR_DETECT == STD_ON)

					/* Report to DET */
					(void)Det_ReportError(EEP_MODULE_ID, EEP_INSTANCE_ID, EEP_SETMODE_SID,EEP_E_BUSY);
					#endif

					}
				else if(MEMIF_BUSY_INTERNAL == Eep_GddModuleState)
					{
					/*Do nothing*/

					}
				/* set mode of eeprom when state is IDLE */
				else if(MEMIF_IDLE == Eep_GddModuleState) 
					{
					/*set the mode of EEPROM*/
					Eep_GddMode=Mode;
					}
				}

}

/******************************************************************************
** Function Name             : Eep_Read
**
** Service ID                : 0x02
**
** Description               : Reads from EEPROM
**                         
**
** Sync/Async                : Asynchronous
**
** Re-entrancy               : Non Reentrant
**
** Input Parameters          : EepromAddress ,Length,DataBufferPtr
**
** Parameter Description     : EepromAddress is of unsigned 32-bit variable,DataBufferPtr is of const buffer,Length is of unsigned 32-bit variable 
**
** InOut Parameters          : None
**
** Output Parameters         : DataBufferPtr
**
** Return parameter          : Std_ReturnType
**
** Preconditions             : None
**
** Global Variables          : Eep_GddModuleState,Eep_GddJobResult
**                        
** Functions invoked         : I2C_Read.
**
** Registers Used            : None
**
******************************************************************************/
uint32_t Eep_Read(uint32_t memoryAddress,uint8_t dataLength,uint8_t *DataBufferPtr)
  {
					
					uint16_t LddReturnVal;
					LddReturnVal = E_OK;
		
					/* Check if the Eep module is initialized */
					if(MEMIF_UNINIT == Eep_GddModuleState)
						{
						#if (EEP_DEV_ERROR_DETECT == STD_ON)
						/* Report to DET */
						(void)Det_ReportError(EEP_MODULE_ID, EEP_INSTANCE_ID, EEP_READ_SID,EEP_E_UNINIT);
						#endif

						/* Set the Return value to not OK */
						LddReturnVal = E_NOT_OK;

					} /* if(Eep_GddModuleState == MEMIF_UNINIT) */
					else
						{
						/* Check if the module is Busy with some other request */
						if(MEMIF_BUSY == Eep_GddModuleState)
						{
						#if (EEP_DEV_ERROR_DETECT == STD_ON)	
						/* Report to DET */
						(void)Det_ReportError(EEP_MODULE_ID, EEP_INSTANCE_ID, EEP_READ_SID, EEP_E_BUSY);
						#endif
						/* Set the Return value to not OK */
						LddReturnVal = E_NOT_OK;
						}/* if(Eep_GddModuleState == MEMIF_BUSY) */
					/* if(Eep_GddModuleState == MEMIF_BUSY_INTERNAL) */
						
					else if(MEMIF_BUSY_INTERNAL == Eep_GddModuleState)
						{
						/* Set the Return value to E_OK */
						LddReturnVal = E_OK;
						}
						else
						{
						/* Do Nothing */
						}
					/* Check if NULL Pointer is passed */
					if(NULL == DataBufferPtr)
						{
						#if (EEP_DEV_ERROR_DETECT == STD_ON)
						/* Report to DET */
						(void)Det_ReportError(EEP_MODULE_ID, EEP_INSTANCE_ID, EEP_READ_SID,EEP_E_PARAM_DATA);
						#endif
						/* Set the Return value to not OK */
						LddReturnVal = E_NOT_OK;
					  } /* if(DataBufferPtr == NULL_PTR) */

					/* check for Return value to E_OK */
					if(E_NOT_OK != LddReturnVal)
						{

						/* Check if address is in range */
					if( dataLength <= (EEPROM_SIZE - memoryAddress) ){
						{
							//Eep_GddModuleState = MEMIF_BUSY;
							//Eep_GddJobResult = MEMIF_JOB_PENDING;
							I2C_Read(I2C1,0XA0,memoryAddress,DataBufferPtr,dataLength);
             }
						  LddReturnVal= E_NOT_OK;
						}
					  else
					 {
						#if (EEP_DEV_ERROR_DETECT == STD_ON)
						/* Report to DET */
						(void)Det_ReportError(EEP_MODULE_ID,EEP_INSTANCE_ID,EEP_READ_SID,EEP_E_PARAM_LENGTH);
						#endif
						LddReturnVal = E_NOT_OK;
					}	
					}
					else
					{   
						#if (EEP_DEV_ERROR_DETECT == STD_ON)
						/* Report to DET */
						(void)Det_ReportError(EEP_MODULE_ID, EEP_INSTANCE_ID, EEP_READ_SID,EEP_E_PARAM_ADDRESS);
						#endif 
						/* Set the Return value to not OK */
						LddReturnVal = E_NOT_OK;
					}
					}/*if(E_NOT_OK != LddReturnVal)*/
					return LddReturnVal;
}
	


/******************************************************************************
** Function Name                 : Eep_Write
**
** Service ID                    : 0x03
**
** Description                   : Writes to EEPROM
**                         
** Sync/Async                    : Asynchronous
**
** Re-entrancy                   : Non Reentrant
**
** Input Parameters              : EepromAddress ,Length ,DataBufferPtr
**
** Parameter Description         : EepromAddress is of unsigned 32-bit variable,DataBufferPtr is of const buffer,Length is of unsigned 32-bit variable 
**
** InOut Parameters              : None
**
** Output Parameters             : None
**
** Return parameter              : Std_ReturnType
**
** Preconditions                 : None
**
** Global Variables              : Eep_GddModuleState,Eep_GddJobResult,
**                        
** Functions invoked             : I2C_Write().
**
** Registers Used                : None
**
******************************************************************************/

uint32_t Eep_Write (uint8_t memoryAddress,uint8_t dataLength,const uint8_t *DataBufferPtr)
{
	uint8_t counter;
	uint16_t LddReturnVal;
	LddReturnVal = E_OK;
	if(MEMIF_UNINIT == Eep_GddModuleState)
						{
						#if (EEP_DEV_ERROR_DETECT == STD_ON)
						/* Report to DET */
						(void)Det_ReportError(EEP_MODULE_ID, EEP_INSTANCE_ID, EEP_READ_SID,EEP_E_UNINIT);
						#endif

						/* Set the Return value to not OK */
						LddReturnVal = E_NOT_OK;

					} /* if(Eep_GddModuleState == MEMIF_UNINIT) */
					else
						{
						/* Check if the module is Busy with some other request */
						if(MEMIF_BUSY == Eep_GddModuleState)
						{
						#if (EEP_DEV_ERROR_DETECT == STD_ON)	
						/* Report to DET */
						(void)Det_ReportError(EEP_MODULE_ID, EEP_INSTANCE_ID, EEP_READ_SID, EEP_E_BUSY);
						#endif
						/* Set the Return value to not OK */
						LddReturnVal = E_NOT_OK;
						}/* if(Eep_GddModuleState == MEMIF_BUSY) */
					/* if(Eep_GddModuleState == MEMIF_BUSY_INTERNAL) */
						
					else if(MEMIF_BUSY_INTERNAL == Eep_GddModuleState)
						{
						/* Set the Return value to E_OK */
						LddReturnVal = E_OK;
						}
						else
						{
						/* Do Nothing */
						}
					/* Check if NULL Pointer is passed */
					if(NULL == DataBufferPtr)
						{
						#if (EEP_DEV_ERROR_DETECT == STD_ON)
						/* Report to DET */
						(void)Det_ReportError(EEP_MODULE_ID, EEP_INSTANCE_ID, EEP_READ_SID,EEP_E_PARAM_DATA);
						#endif
						/* Set the Return value to not OK */
						LddReturnVal = E_NOT_OK;
					  } /* if(DataBufferPtr == NULL_PTR) */

					/* check for Return value to E_OK */
					if(E_NOT_OK != LddReturnVal)
						{
	if( dataLength <= (EEPROM_SIZE - memoryAddress) ){
	
		//Eep_GddModuleState = MEMIF_BUSY;
		//Eep_GddJobResult = MEMIF_JOB_PENDING;
		I2C_Write( I2C1,0XA0,memoryAddress,(uint8_t*)DataBufferPtr,dataLength);
	}else LddReturnVal = E_NOT_OK;							
	return LddReturnVal;
}
						}
					}


/******************************************************************************
** Function Name         : Eep_GetStatus
**
** Service ID            : 0x07
**
** Description           : Returns the EEPROM status
**                         
**
** Sync/Async            : Synchronous
**
** Re-entrancy           : Reentrant
**
** Input Parameters      : None
**
** InOut Parameters      : None
**
** Output Parameters     : None
**
** Return parameter      : MemIf_StatusType
**
** Preconditions         : None
**
** Global Variables      : Eep_GddModuleState
**
** Functions invoked     : None
**
** Registers Used        : None
**
******************************************************************************/
MemIf_StatusType Eep_GetStatus (void )
  {	
		/*local variable for returning module status*/
		MemIf_StatusType LddReturnValue;
		/*assign the global state variable to the local variable */
		LddReturnValue = Eep_GddModuleState;
		return (LddReturnValue);

  }

/******************************************************************************
** Function Name            : Eep_GetVersionInfo
**
** Service ID               : 0x0a
**
** Description              : Service to get the version information of 
**                           this module
     
** Sync/Async              : Synchronous
**
** Re-entrancy             : Reentrant
**
** Input Parameters        : versioninfo 
**
** Parameter Description   : Structure Type pointer
**
** InOut Parameters        : None
**
** Output Parameters       : None
**
** Return parameter        : None
**
** Preconditions           : None
**
** Global Variables        : versioninfo
**
** Functions invoked       : None
**
** Registers Used          : None
**
******************************************************************************/
/* enabling or disabling the version info API dependepending upon the
 preconfigured MACRO */
	
void Eep_GetVersionInfo (Std_VersionInfoType *versioninfo)
{	 
	if(NULL== versioninfo)
	{
		#if (EEP_DEV_ERROR_DETECT == STD_ON) 
		/* Report to DET */
		(void)Det_ReportError(EEP_MODULE_ID, EEP_INSTANCE_ID,EEP_GETVERSIONINFO_SID,EEP_E_PARAM_POINTER);
		#endif	

	}
	else
	{
			/* Copy the vendor Id */
			// versioninfo->vendorID = (uint16_t)EEP_VENDOR_ID;
			/* Copy the module Id */
			versioninfo->moduleID = (uint16_t)EEP_MODULE_ID;
			/* Copy Software Major Version */
			versioninfo->sw_major_version = EEP_SW_MAJOR_VERSION;
			/* Copy Software Minor Version */
			versioninfo->sw_minor_version = EEP_SW_MINOR_VERSION;
			/* Copy Software Patch Version */
			versioninfo->sw_patch_version = EEP_SW_PATCH_VERSION;
	}

}





/******************************************************************************
** Function Name         : Eep_MainFunction
**
** Service ID            : 0x09
**
** Description           : function to complete  read/write jobs of Eep driver
**
** Sync/Async            : Synchronous
**
** Re-entrancy           : Reentrant
**
** Input Parameters      : None
**
** InOut Parameters      : None
**
** Output Parameters     : None
**
** Return parameter      : None
**
** Preconditions         : None
**
** Global Variables      : Eep_GusLddErr 
**							            
**                           
** Functions invoked     :  Eep_Write(), Eep_Read(),Eep_Erase,Eep_Compare
**
** Registers Used        : None
**
******************************************************************************/

void Eep_MainFunction(void)
{
		switch( Eep_JobsOP.jobType)
		{
			/*Curent job operation is write*/
			case EEP_WRITE_OP:
			{
				/*for(byte_cnt=0;byte_cnt<128;byte_cnt++)
				{
					DataBufferPtr[byte_cnt]=0x23;
				}*/
				Eep_GusLddErr =  Eep_Write(0X06,9,DataBufferPtr);	
				break;
			}
			/*Curent job operation is read*/
			case EEP_READ_OP:
			{
				Eep_GusLddErr = 	Eep_Read(0X06,9,readDataBufferPtr);
				break;
			}
			/*Curent job operation is read*/
			case EEP_ERASE_OP:
			{
				//Eep_GusLddErr = Eep_Erase(0xA0,21);
				break;
			}
			case  EEP_COMPARE_OP:
			{
				//Eep_GusLddErr=Eep_Compare(0XA0,buf,5);
				break;
			}
			/*Curent job operation is job notification*/
			default:
			{
			}
		}
}

