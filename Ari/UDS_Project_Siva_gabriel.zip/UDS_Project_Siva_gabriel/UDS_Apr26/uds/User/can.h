#ifndef _Can_h_
#define _Can_h_
#include "stm32f4xx.h"
#include "Std_Types.h"
/* ##############################  MACROs  ############################## */
#define CAN_E_PARAM_POINTER     0x01
#define CAN_E_PARAM_HANDLE      0x02
#define CAN_E_PARAM_DLC     	0x03
#define CAN_E_PARAM_CONTROLLER  0x04
/* API service used without initialization */
#define CAN_E_UNINIT            0x05
/* Init transition for current mode */
#define CAN_E_TRANSITION        0x06

#define CAN_E_DATALOST          0x07    
#define NULL 0 
//#define CAN_MODULE_ID			    MODULE_ID_CAN
typedef uint32_t Can_IdType;


#define CAN_GET_PRIVATE_DATA(_controller) \
									&Can_Global.canUnit[_controller]

#define CAN_VENDOR_ID_VALUE        (0x27u)
#define CAN_MODULE_ID_VALUE	 	     (0x5Au)
#define CAN_INSTANCE_ID_VALUE      (0x01u)
#define CAN_SW_MAJOR_VERSION_VALUE (0x01u)
#define CAN_SW_MINOR_VERSION_VALUE (0x00u)
#define CAN_SW_PATCH_VERSION_VALUE (0x00u)

#define CAN_VENDOR_ID              CAN_VENDOR_ID_VALUE
#define CAN_MODULE_ID              CAN_MODULE_ID_VALUE
#define CAN_SW_MAJOR_VERSION       CAN_SW_MAJOR_VERSION_VALUE
#define CAN_SW_MINOR_VERSION       CAN_SW_MINOR_VERSION_VALUE
#define CAN_SW_PATCH_VERSION       CAN_SW_PATCH_VERSION_VALUE




typedef struct Std_VersionInfoType_s {
	
	uint16_t 	vendorID;
	uint16_t 	moduleID;
	uint16_t 	sw_major_version;
	uint16_t 	sw_minor_version;
	uint16_t 	sw_patch_version;
	
} Std_VersionInfoType;

typedef struct Can_PduType_s {
	/* the CAN ID, 29 or 11-bit  */
	Can_IdType 	id;
	/* Length, max 8 bytes  */
	uint8_t		length;
	/* data ptr  */
	uint8_t 		*sdu;
	/* private data for CanIf,just save and use for callback */
	//PduIdType   swPduHandle;
} Can_PduType;

/*
Represents the Identifier of an L-PDU. For extended IDs the most significant bit is set.
 */
typedef uint32_t Can_IdType;

/*
Range:
	Standard  0..0x0FF
	Extended  0..0xFFFF
Represents the hardware object handles of a CAN hardware unit. For CAN
hardware units with more than 255 HW objects use extended range.
 */
typedef uint16_t Can_HwHandleType;
typedef struct
{
	uint8_t idmr[8]; /* Identifier Mask Register, 1 = ignore corresponding acceptance code register bit*/
	uint8_t idar[8]; /* Identifier Acceptance Register*/
	//Can_IDAMType idam;
} Can_FilterMaskType;

typedef enum {
	CAN_CTRL_1 = 0,
	CAN_CTRL_2 = 1,
	CAN_CONTROLLER_CNT = 2
}Can_ControllerIdType;

typedef enum {
	CAN_ERRORSTATE_ACTIVE = 0,
	CAN_ERRORSTATE_PASSIVE = 1,
	CAN_ERRORSTATE_BUSOFF = 2
}Can_ErrorStateType;

typedef struct {
	uint32_t txSuccessCnt;
	uint32_t rxSuccessCnt;
	uint32_t txErrorCnt;
	uint32_t rxErrorCnt;
	uint32_t boffCnt;
	uint32_t fifoOverflow;
	uint32_t fifoWarning;
} Can_StatisticsType;

typedef enum {
	CANIF_CS_UNINIT,
	CANIF_CS_STARTED,
	CANIF_CS_STOPPED,
	CANIF_CS_SLEEP
} Can_ControllerStateType;

typedef struct {
  Can_ControllerStateType state;
  uint16_t		lock_cnt;

  /* Statistics */
  Can_StatisticsType stats;

  /* Data stored for Txconfirmation callbacks to CanIf */
  //PduIdType swPduHandle;
} Can_UnitType;

/* Type for holding information about each controller */
typedef enum {
	CAN_OBJECT_TYPE_RECEIVE,
	CAN_OBJECT_TYPE_TRANSMIT
} Can_ObjectTypeType;

typedef enum
{
	/** All the CANIDs are of type extended only (29 bit).*/
	CAN_ID_TYPE_EXTENDED = 0x1,
	/** All the CANIDs are of type standard only (11bit). */
	CAN_ID_TYPE_STANDARD = 0x2,
	/** The type of CANIDs can be both Standard or Extended.*/
	CAN_ID_TYPE_MIXED    = 0x3
}Can_IdTypeType;

typedef enum 
{
  CAN_ARC_HANDLE_TYPE_BASIC,
  CAN_ARC_HANDLE_TYPE_FULL
} Can_Arc_HohType;

typedef struct Can_HardwareObjectStruct {
	
	/** Specifies the value which is used to pad unspecified data in CAN FD frames > 8 bytes 
	for transmission. This is necessary due to the discrete possible values of the DLC if > 8 bytes.
    If the length of a PDU which was requested to be sent does not match the allowed DLC values, 
    the remaining bytes up to the next possible value shall be padded with this value.*/
	uint8_t CanFdPaddingValue;
	
	/** Specifies the type (Full-CAN or Basic-CAN) of a hardware object.*/
	Can_Arc_HohType CanHandleType;
	
	/** Enables polling of this hardware object. */
	uint8_t CanHardwareObjectUsesPolling;
	
	/**Number of hardware objects used to implement one HOH. In case of a HRH 
	this parameter defines the number of elements in the hardware FIFO or the 
	number of shadow buffers, in case of a HTH it defines the number of hardware 
	objects used for multiplexed transmission or for a hardware FIFO used by a FullCAN HTH. */
	uint32_t CanHwObjectCount;

	/** Specifies whether the IdValue is of type - standard identifier - extended
	identifier - mixed mode ImplementationType: Can_IdType*/
	Can_IdTypeType CanIdType;

	/**	Specifies (together with the filter mask) the identifiers range that passes
	the hardware filter.*/
	uint32_t CanIdValue;

	/**	Holds the handle ID of HRH or HTH. The value of this parameter is unique
	in a given CAN Driver, and it should start with 0 and continue without any
	gaps. The HRH and HTH Ids are defined under two different name-spaces.
	Example: HRH0-0, HRH1-1, HTH0-2, HTH1-3.*/
	uint16_t CanObjectId;

	/** Specifies if the HardwareObject is used as Transmit or as Receive object*/
	Can_ObjectTypeType CanObjectType;

	/** Reference to the filter mask that is used for hardware filtering togerther
	with the CAN_ID_VALUE*/
	const Can_FilterMaskType *CanFilterMaskRef;

	/** A "1" in this mask tells the driver that that HW Message Box should be
	occupied by this Hoh. A "1" in bit 31(ppc) occupies Mb 0 in HW.*/
	uint32_t Can_MbMask;

	/** End Of List. Set to TRUE is this is the last object in the list.*/
	uint8_t Can_EOL;
} Can_HardwareObjectType;
typedef enum
{
	CAN_PROCESS_TYPE_INTERRUPT,
	CAN_PROCESS_TYPE_POLLING
}Can_ProcessType;

typedef enum
{
	E_OK,
	E_NOT_OK
}Std_ReturnType;

typedef enum {
	CAN_T_START,
	CAN_T_STOP,
	CAN_T_SLEEP,
	CAN_T_WAKEUP
} Can_StateTransitionType;



#define CAN_BR_1MBPS  (uint16_t)1
#define CAN_BR_500KBPS (uint16_t)2


typedef struct
{
	/** Enables / disables API Can_MainFunction_BusOff() for
	handling busoff events in polling mode. */
	Can_ProcessType CanBusoffProcessing;
	/** Defines if a CAN controller is used in the configuration. */
	uint8_t         CanControllerActivation;
	/** This parameter provides the controller ID which is unique in a
	given CAN Driver. The value for this parameter starts with 0 and
	continue without any gaps. */
	Can_ControllerIdType  CanControllerId;
	/** Enables / disables API Can_MainFunction_Read() for
	handling PDU reception events in polling mode. */
	Can_ProcessType CanRxProcessing;
	/** Enables / disables API Can_MainFunction_Write() for
	handling PDU transmission events in polling mode.  */
	Can_ProcessType CanTxProcessing;
	/** Enables / disables API Can_MainFunction_Wakeup() for
	handling wakeup events in polling mode. */
	Can_ProcessType CanWakeupProcessing;
	Can_ProcessType CanBusOffProcessing;
	/** CAN driver support for wakeup over CAN Bus. */
	uint8_t         CanWakeupSupport;
	/**	Reference to the CPU clock configuration, which is set in the MCU driver
	configuration.*/
	uint32_t CanCpuClockRef;
	/** This parameter contains a reference to the Wakeup Source for this
	ontroller as defined in the ECU State Manager. Implementation Type:
	reference to EcuM_WakeupSourceType.*/
	uint32_t/* ref to EcuMWakeupSource */ CanWakeupSourceRef;
	/** Specifies the baudrate of the controller in kbps. */
	uint16_t          CanControllerBaudRate;
	/** Specifies propagation delay in time quantas(1..8).*/
	uint16_t          CanControllerPropSeg;
	/** Specifies phase segment 1 in time quantas(1..16).*/
	uint16_t          CanControllerSeg1;
	/** Specifies phase segment 2 in time quantas(1..8).*/
	uint16_t          CanControllerSeg2;
	/**	Specifies the synchronization jump width(1..4) for the controller in
	time quantas.*/
	//uint16          CanControllerSyncJumpWidth;
	/** List of Hoh id's that belong to this controller */
	const Can_HardwareObjectType  *Can_Hoh;
	uint8_t Can_Loopback;
}Can_ConfigType;

//typedef struct {
//	const Can_ControllerConfigType *CanController;
//} Can_ConfigSetType;

/*
	This is  the type of the external data structure containing the overall initialization
	data for the CAN driver and SFR settings affecting all controllers. Furthermore it
	contains pointers to controller configuration structures. The contents of the
	initialization data structure are CAN hardware specific.
*/
//typedef struct
//{
//	/** This is the multiple configuration set container for CAN Driver
//	 Multiplicity 1..*  */
//	const Can_ConfigSetType	 *CanConfigSet;
//}Can_ConfigType;

typedef enum
{
    CAN_UNINIT = 0,
    CAN_READY
} Can_DriverStateType;

typedef struct{
	Can_DriverStateType driverState;
	const Can_ConfigType* config;
	Can_UnitType canUnit[CAN_CONTROLLER_CNT];
}Can_GlobalType;

void Can_Init( const Can_ConfigType* config );
void Can_Init_1( const Can_ConfigType* config );
Std_ReturnType Can_Write( Can_HwHandleType Hth, const Can_PduType* pduInfo );
void GPIO_Configuration(void);
void Can_SetTransmissionAccess(uint8_t accesstype);

#endif

