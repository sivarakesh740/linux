/************************************************************
 * PROJECT: ESS_IP_UDS_Implementation_Project
 *
 * FILE NAME : Uds_types.h
 *
 * TARGET PLATFORM : STM32f107
 *
 * BUILD ENVIRONMENT : RealView MDK-ARM  Version: 4.20 
 *
 * DISCRIPTION : Header file for types used in implemenation of UDS
 *
 * VERSION : v1.0
 *
 * PLATFORM DEPENDANT [yes/no] : no
 *
 * TO BE CHANGED BY THE USER [yes/no] : no
 *	
 * CREATED BY: Chirag Juneja
 *
 * LICENSE: ARIPL SOFTWARE LICENSE
 ************************************************************/
 
#ifndef Uds_types_h
#define Uds_types_h

/*---------------------------------------- Includes ----------------------------------------*/

#include "Std_Types.h"

/*---------------------------------------- Macros ----------------------------------------*/
/*------------------------------ CAN IDs for UDS ------------------------------*/

#define UDS_RX_ID 0x64
#define UDS_TX_ID 0x58

/*------------------------------ Response Id ------------------------------*/

#define UDS_POSITIVE_RESPONSE_MASK  0x40u
#define UDS_NEGATIVE_RESPONSE_ID    0x7Fu

/*------------------------------ UDS Session IDs ------------------------------*/
#define UDS_SID_DIAGNOSTIC_SESSION_CONTROL  0x10u
#define UDS_SID_ECU_RESET                   0x11u
#define UDS_SID_CLEAR_DIAGNOSTIC_INFO       0x14u
#define UDS_SID_READ_DTC_INFO               0x19u
#define UDS_SID_READ_DATA_BY_ID             0x22u
#define UDS_SID_READ_MEMORY_BY_ADDRESS      0x23u
#define UDS_SID_SECURITY_ACCESS             0x27u
#define UDS_SID_COMMUNICATION_CONTROL       0x28u
#define UDS_SID_READ_DATA_BY_PERIODIC_ID 		0x2Au
#define UDS_SID_DYNAMICALLY_DEFINED_DATA_ID 0x2C
#define UDS_SID_WRITE_DATA_BY_ID 						0x2Eu
#define UDS_SID_WRITE_MEMORY_BY_ADDRESS 		0x3Du
#define UDS_SID_TESTER_PRESENT						  0x3Eu
#define UDS_SID_ACCESS_TIMING_PARAMETER 		0x83u
#define UDS_SID_CONTROL_DTC_SETTING 				0x85u
#define UDS_SID_RESPONSE_ON_EVENT 					0x86u
#define UDS_SID_ROUTINE_CONTROL							0x31u
#define UDS_SID_REQUEST_DOWNLOAD            0X34u
#define UDS_SID_REQUEST_UPLOAD              0X35u
#define UDS_SID_TRANSFER_DATA               0x36u
#define UDS_SID_REQUEST_TRANSFER_EXIT       0x37u

/*------------------------------ SUB-FUNCTION PARAMETER ------------------------------*/

#define DEFAULT_SESSION 										0x01u
#define PROGRAMMING_SESSION 								0x02u
#define EXTENDED_DIAGNOSTIC_SESSION 				0x03u
#define SAFTEY_SYSTEM_DIAGNOSTIC_SESSION 		0x04u

#define HARD_RESET 													0x01u

#define ZERO_SUB_FUNCTION 									0x00u

#define REQUEST_SEED 												0x01u
#define SEND_KEY 														0x02u

#define ENABLE_RX_AND_TX									  0x00u
#define ENABLE_RX_AND_DISABLE_TX            0x01

#define NORMAL_COMMUNICAITON                0x01u

#define NODTC_STATUS                       0x01u
#define DTC_STATUS           	             0x02u
/*------------------------------ ROUTINE (SUB-FUNCTION)-------------------------------*/
#define START_ROUTINE												0x01u
#define STOP_ROUTINE												0x02u
#define REQUEST_FOR_RESULTS									0x03u
/*----------------------------ROUTINE_ID(RID)-----------------------------------------*/
#define RID1																	0x02u
#define RID2																	0x03u
/*---------------------------------------DOWNLOAD_UPLOAD (DID)-------------------------*/
#define DID1																		0x01
#define DID2																		0x02

/*------------------------------ NEGATIVE REPONSE CODES ------------------------------*/

#define NRC_SERVICE_NOT_SUPPORTED 					0x11u
#define NRC_SUB_FUNCTION_NOT_SUPPORTED      0x12u
#define NRC_INVALID_FORMAT 									0x13u
#define NRC_CONDITIONS_NOT_CORRECT 					0x22u
#define NRC_REQUEST_SEQUENCE_ERROR 					0x24u
#define NRC_REQUEST_OUT_OF_RANGE 						0x31u
#define NRC_SECURITY_ACCESS_DENIED			    0x33u
#define NRC_INVALID_KEY 										0x35u
#define NRC_GENERAL_PROGRAMMING_FALIURE 		0x72u
#define UPLOAD_DOWNLOAD_NOT_ACCEPTED				0x70u
#define WRONG_BLOCK_SEQUENCE_COUNTER        0x73u

/*------------------------------ UDS ESSENTIAL PARAMETERS ------------------------------*/

#define ECU_POWER_DOWN_TIME 0x00


/*------------------------------ BOOLEANS ------------------------------*/

#define SUCCESS  0x01u
#define FAILED   0x00u

#define TRUE  0x1u
#define FALSE 0x0u

#define LOCKED   0x00u
#define UNLOCKED 0x01u

#define POSITIVE 0x1u
#define NEGATIVE 0x0u

#define ENABLE  0x01u
#define DISABLE 0x00u

#define null 0x00u
//#define NULL 0x00u

/*---------------------------------------- Typedef ----------------------------------------*/

/**************************************************************************
 * DataType : Uds_DiagnosticSession
 * Description : Holds the status of the services in a diagnostic session(Supported/Not Supported)
 * Elements Type: uint8_t
 * Elements Discription: Various Engine Parameters
 **************************************************************************/
typedef struct {
	uint8_t currentSession;
	uint8_t diagnosticSessionControl;
	uint8_t ecuReset;
	uint8_t securityAccess;
	uint8_t communicationControl;
	uint8_t testerPreset;
	uint8_t accessTimingParameters;
	uint8_t controlDTCSettings;
	uint8_t responseOnEvent;
	uint8_t readDataByIdentifier;
	uint8_t readMemoryByAddress;
	uint8_t readDataByIdentifierPeriodic;
	uint8_t dynamicallyDefineDataIdentifier;
	uint8_t writeDataByIdentifier;
	uint8_t writeMemoryByAddress;
	uint8_t clearDiagnosticInformation;
	uint8_t readDTCInformation;
}Uds_DiagnosticSession;

#endif
